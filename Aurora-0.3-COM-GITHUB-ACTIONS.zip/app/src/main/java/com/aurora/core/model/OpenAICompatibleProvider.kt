package com.aurora.core.model

import com.aurora.core.perf.PerfTrace
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Cliente de endpoint compatível com a API de chat da OpenAI (OpenAI, llama-server, Ollama, etc.).
 * [endpoint] é a URL base incluindo /v1 (ex.: https://host/v1); o app acrescenta /chat/completions.
 * [apiKey] é opcional (servidores locais não exigem).
 *
 * STATUS: implementado (streaming SSE + fallback para resposta JSON completa), AINDA NÃO TESTADO contra
 * um servidor real. "Ready" significa apenas "configurado": a conexão só é exercitada ao gerar.
 */
class OpenAICompatibleProvider(
    private val endpoint: String,
    private val model: String,
    private val apiKey: String?
) : ModelProvider {

    override val id = "openai-compatible"
    /** Modelo efetivo: se o campo ficar vazio usa o padrão (o Worker, quando tem MODEL, ignora este valor). */
    private val effectiveModel = model.trim().ifBlank { DEFAULT_MODEL }
    override val label = "Nuvem ($effectiveModel)"

    private val configured = endpoint.isNotBlank()
    private val idleState: ModelState =
        if (configured) ModelState.Ready(label)
        else ModelState.NotConfigured("Endpoint remoto não configurado.")

    private val _state = MutableStateFlow(idleState)
    override val state: StateFlow<ModelState> = _state.asStateFlow()

    @Volatile private var cancelled = false
    @Volatile private var connection: HttpURLConnection? = null

    override suspend fun load() { /* nada a carregar; a configuração já define o estado */ }

    override fun generate(request: GenerationRequest): Flow<String> = flow {
        check(configured) { "Endpoint remoto não configurado." }
        cancelled = false
        _state.value = ModelState.Generating
        try {
            val trace: PerfTrace = request.trace
            val startNet = System.nanoTime()
            val conn = openConnection(request)
            val code = conn.responseCode
            trace.ms("remote_headers", (System.nanoTime() - startNet) / 1_000_000) // conexão + prefill no servidor até o 1º byte
            if (code !in 200..299) {
                val err = conn.errorStream?.bufferedReader()?.use { it.readText() }?.take(500).orEmpty()
                val dica = when (code) {
                    401, 403 -> "A chave/token foi recusada. Confira a chave em Configurações."
                    404 -> "Endereço não encontrado. Confira o endpoint (normalmente termina em /v1) e o nome do modelo."
                    429 -> "Limite de uso da API atingido. Espere alguns minutos e tente de novo."
                    in 500..599 -> "O servidor do modelo está com problema. Tente de novo em instantes."
                    else -> ""
                }
                throw IOException("HTTP $code" + (if (dica.isNotBlank()) " — $dica" else "") + (if (err.isNotBlank()) " [$err]" else ""))
            }
            var emitted = false
            var deltas = 0
            val nonSse = StringBuilder()
            conn.inputStream.bufferedReader().use { reader ->
                while (true) {
                    val line = reader.readLine() ?: break
                    if (!line.startsWith("data:")) {
                        if (nonSse.length < MAX_NON_SSE_CHARS) nonSse.append(line).append('\n')
                        continue
                    }
                    val payload = line.removePrefix("data:").trim()
                    if (payload == "[DONE]") break
                    val piece = parseDelta(payload)
                    if (piece.isNotEmpty()) {
                        if (!emitted) trace.ms("remote_first_delta", (System.nanoTime() - startNet) / 1_000_000)
                        emitted = true
                        deltas++
                        emit(piece)
                    }
                    // Alguns gateways mandam finish_reason mas esquecem o [DONE].
                    if (isTerminalSse(payload)) break
                }
            }
            // Cada delta SSE costuma ser ~1 token (depende do servidor): contagem aproximada, não do tokenizador.
            if (emitted) {
                val totalMs = (System.nanoTime() - startNet) / 1_000_000
                trace.note("remote_sse_deltas", deltas)
                if (totalMs > 0) trace.note("remote_deltas_per_s", "%.1f".format(java.util.Locale.US, deltas * 1000.0 / totalMs))
            }
            if (!emitted && !cancelled) {
                // Alguns servidores ignoram stream=true e devolvem o JSON completo.
                val full = parseFullMessage(nonSse.toString())
                if (full.isNotEmpty()) emit(full)
                else if (nonSse.isNotBlank()) {
                    throw IOException("Resposta inesperada do servidor: " + nonSse.toString().trim().take(200))
                }
            }
        } catch (e: IOException) {
            if (!cancelled) throw e
        } finally {
            connection?.disconnect()
            connection = null
            _state.value = idleState
        }
    }.flowOn(Dispatchers.IO)


    /** Uma chamada de ferramenta pedida pelo modelo. [args] é o JSON cru dos argumentos. */
    data class ToolCall(val id: String, val name: String, val args: String)

    /** Resposta de uma rodada sem streaming: texto final OU chamadas de ferramenta. [raw] é a mensagem do assistente como veio. */
    data class ToolTurn(val text: String, val calls: List<ToolCall>, val raw: JSONObject?)

    /**
     * Uma rodada com function calling (sem streaming). Usada só quando o pedido parece exigir agir no celular.
     * [messages] segue o formato OpenAI (role/content, assistant com tool_calls, tool com tool_call_id).
     */
    suspend fun chatOnce(messages: JSONArray, tools: JSONArray, maxTokens: Int, temperature: Double): ToolTurn = withContext(Dispatchers.IO) {
        check(configured) { "Endpoint remoto não configurado." }
        cancelled = false
        val conn = URL(chatUrl()).openConnection() as HttpURLConnection
        connection = conn
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15_000
            conn.readTimeout = 90_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            if (!apiKey.isNullOrBlank()) conn.setRequestProperty("Authorization", "Bearer ${apiKey.trim()}")
            val body = JSONObject()
                .put("model", effectiveModel)
                .put("messages", messages)
                .put("stream", false)
                .put("temperature", temperature)
                .put("max_tokens", maxTokens)
            if (tools.length() > 0) body.put("tools", tools).put("tool_choice", "auto")
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            if (code !in 200..299) {
                val err = conn.errorStream?.bufferedReader()?.use { it.readText() }?.take(500).orEmpty()
                val dica = when (code) {
                    401, 403 -> "A chave/token foi recusada. Confira a chave em Configurações."
                    404 -> "Endereço não encontrado. Confira o endpoint (normalmente termina em /v1) e o nome do modelo."
                    429 -> "Limite de uso da API atingido. Espere alguns minutos e tente de novo."
                    in 500..599 -> "O servidor do modelo está com problema. Tente de novo em instantes."
                    else -> ""
                }
                throw IOException("HTTP $code" + (if (dica.isNotBlank()) " — $dica" else "") + (if (err.isNotBlank()) " [$err]" else ""))
            }
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            val msg = JSONObject(text).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")
                ?: throw IOException("Resposta inesperada do servidor: " + text.take(200))
            val calls = mutableListOf<ToolCall>()
            val arr = msg.optJSONArray("tool_calls")
            if (arr != null) for (i in 0 until arr.length()) {
                val c = arr.optJSONObject(i) ?: continue
                val fn = c.optJSONObject("function") ?: continue
                calls += ToolCall(c.optString("id").ifBlank { "call_$i" }, fn.optString("name"), fn.optString("arguments").ifBlank { "{}" })
            }
            ToolTurn(if (msg.isNull("content")) "" else msg.optString("content"), calls, msg)
        } finally {
            conn.disconnect()
            if (connection === conn) connection = null
        }
    }


    /**
     * Uma rodada com function calling EM STREAMING: o texto chega aos poucos em [onText] e as chamadas de ferramenta
     * são montadas a partir dos pedaços. Se o servidor responder sem SSE, lê a resposta inteira.
     */
    suspend fun chatStream(
        messages: JSONArray, tools: JSONArray, maxTokens: Int, temperature: Double, onText: suspend (String) -> Unit
    ): ToolTurn = withContext(Dispatchers.IO) {
        check(configured) { "Endpoint remoto não configurado." }
        cancelled = false
        val conn = URL(chatUrl()).openConnection() as HttpURLConnection
        connection = conn
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15_000
            conn.readTimeout = 120_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("Accept", "text/event-stream")
            if (!apiKey.isNullOrBlank()) conn.setRequestProperty("Authorization", "Bearer ${apiKey.trim()}")
            val body = JSONObject()
                .put("model", effectiveModel)
                .put("messages", messages)
                .put("stream", true)
                .put("temperature", temperature)
                .put("max_tokens", maxTokens)
            if (tools.length() > 0) body.put("tools", tools).put("tool_choice", "auto")
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            if (code !in 200..299) {
                val err = conn.errorStream?.bufferedReader()?.use { it.readText() }?.take(500).orEmpty()
                val dica = when (code) {
                    401, 403 -> "A chave/token foi recusada. Confira a chave em Ajustes → Nuvem."
                    404 -> "Endereço não encontrado. Confira o endpoint e o nome do modelo."
                    429 -> "Limite de uso da API atingido. Espere alguns minutos e tente de novo."
                    in 500..599 -> "O servidor do modelo está com problema. Tente de novo em instantes."
                    else -> ""
                }
                throw IOException("HTTP $code" + (if (dica.isNotBlank()) " — $dica" else "") + (if (err.isNotBlank()) " [$err]" else ""))
            }
            class Acc(var id: String = "", var name: String = "", val args: StringBuilder = StringBuilder(), var extra: JSONObject? = null)
            val accs = java.util.TreeMap<Int, Acc>()
            val text = StringBuilder()
            val other = StringBuilder()
            var sawData = false
            conn.inputStream.bufferedReader(Charsets.UTF_8).use { reader ->
                while (true) {
                    if (cancelled) break
                    val line = reader.readLine() ?: break
                    val l = line.trim()
                    if (!l.startsWith("data:")) {
                        if (l.isNotEmpty() && other.length < MAX_NON_SSE_CHARS) other.append(l)
                        continue
                    }
                    val payload = l.removePrefix("data:").trim()
                    if (payload == "[DONE]") break
                    val choice = try {
                        JSONObject(payload).optJSONArray("choices")?.optJSONObject(0)
                    } catch (e: Exception) {
                        null
                    } ?: continue
                    val delta = choice.optJSONObject("delta")
                    if (delta == null) {
                        if (isTerminalSse(payload)) { sawData = true; break }
                        continue
                    }
                    sawData = true
                    if (!delta.isNull("content")) {
                        val c = delta.optString("content")
                        if (c.isNotEmpty()) { text.append(c); onText(c) }
                    }
                    val tcs = delta.optJSONArray("tool_calls")
                    if (tcs != null) for (i in 0 until tcs.length()) {
                        val tc = tcs.optJSONObject(i) ?: continue
                        val id = if (tc.isNull("id")) "" else tc.optString("id")
                        val idx = when {
                            tc.has("index") && !tc.isNull("index") -> tc.optInt("index")
                            id.isNotBlank() -> accs.size            // chamada nova (alguns servidores omitem o index)
                            else -> maxOf(accs.size - 1, 0)          // continuação da última
                        }
                        val acc = accs.getOrPut(idx) { Acc() }
                        if (id.isNotBlank()) acc.id = id
                        tc.optJSONObject("function")?.let { f ->
                            if (!f.isNull("name") && f.optString("name").isNotBlank()) acc.name = f.optString("name")
                            if (!f.isNull("arguments")) acc.args.append(f.optString("arguments"))
                        }
                        tc.optJSONObject("extra_content")?.let { acc.extra = it }
                    }
                    if (isTerminalSse(payload)) break
                }
            }
            if (!sawData && other.isNotBlank()) {
                // Servidor respondeu JSON inteiro em vez de SSE.
                val msg = runCatching { JSONObject(other.toString()).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message") }.getOrNull()
                if (msg != null) {
                    if (!msg.isNull("content")) { val c = msg.optString("content"); if (c.isNotEmpty()) { text.append(c); onText(c) } }
                    val arr = msg.optJSONArray("tool_calls")
                    if (arr != null) for (i in 0 until arr.length()) {
                        val c = arr.optJSONObject(i) ?: continue
                        val f = c.optJSONObject("function") ?: continue
                        accs[i] = Acc(c.optString("id"), f.optString("name"), StringBuilder(f.optString("arguments")), c.optJSONObject("extra_content"))
                    }
                }
            }
            val calls = mutableListOf<ToolCall>()
            val rawCalls = JSONArray()
            for ((idx, a) in accs) {
                if (a.name.isBlank()) continue
                val id = a.id.ifBlank { "call_$idx" }
                val args = a.args.toString().ifBlank { "{}" }
                calls += ToolCall(id, a.name, args)
                val o = JSONObject().put("id", id).put("type", "function")
                    .put("function", JSONObject().put("name", a.name).put("arguments", args))
                a.extra?.let { o.put("extra_content", it) }
                rawCalls.put(o)
            }
            val raw = JSONObject().put("role", "assistant").put("content", if (text.isEmpty()) JSONObject.NULL else text.toString())
            if (rawCalls.length() > 0) raw.put("tool_calls", rawCalls)
            ToolTurn(text.toString(), calls, raw)
        } finally {
            conn.disconnect()
            if (connection === conn) connection = null
        }
    }

    override fun cancel() {
        cancelled = true
        connection?.disconnect()
    }

    override fun release() = cancel()

    private fun chatUrl(): String = CloudUrls.chat(endpoint)

    /**
     * Teste de conexão de verdade: faz uma pergunta mínima e devolve um diagnóstico legível.
     * Nunca lança exceção; o texto diz exatamente o que falhou.
     */
    suspend fun test(): String = withContext(Dispatchers.IO) {
        if (!configured) return@withContext "❌ Endpoint não configurado."
        val t0 = System.nanoTime()
        val conn = runCatching { URL(chatUrl()).openConnection() as HttpURLConnection }.getOrElse {
            return@withContext "❌ Endereço inválido: ${it.message}"
        }
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15_000
            conn.readTimeout = 60_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            if (!apiKey.isNullOrBlank()) conn.setRequestProperty("Authorization", "Bearer ${apiKey.trim()}")
            val msgs = JSONArray().put(JSONObject().put("role", "user").put("content", "Responda apenas com a palavra: ok"))
            val body = JSONObject().put("model", effectiveModel).put("messages", msgs).put("stream", false).put("max_tokens", 256)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val ms = (System.nanoTime() - t0) / 1_000_000
            if (code !in 200..299) {
                val err = conn.errorStream?.bufferedReader()?.use { it.readText() }?.take(400).orEmpty()
                val dica = when (code) {
                    401, 403 -> "O token (APP_TOKEN) foi recusado. Confira se o token no app é exatamente o mesmo do Cloudflare."
                    404 -> "Endereço não encontrado. Use o endereço do Worker terminando em /v1 e confira o nome do modelo."
                    400 -> "O servidor recusou o pedido. Confira o nome do modelo (ex.: gemini-3.8-flash)."
                    429 -> "Limite de uso da API atingido. Espere alguns minutos."
                    500 -> "O Worker não está configurado (falta GEMINI_API_KEY ou APP_TOKEN no Cloudflare) ou deu erro interno."
                    502, 503 -> "O Gemini ou o Worker está fora do ar agora."
                    else -> ""
                }
                return@withContext "❌ HTTP $code em $ms ms. $dica\n$err".trim()
            }
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            val msg = JSONObject(text).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")
            val answer = if (msg == null || msg.isNull("content")) "" else msg.optString("content").trim()
            if (answer.isBlank()) "⚠️ Conectou (HTTP $code, $ms ms), mas o modelo respondeu vazio. Troque o modelo ou aumente MAX_TOKENS no Worker. Resposta crua: ${text.take(300)}"
            else "✅ Conectado em $ms ms. Modelo respondeu: ${answer.take(80)}"
        } catch (e: java.net.UnknownHostException) {
            "❌ Esse endereço não existe (${e.message}). Confira o endpoint, sem espaços."
        } catch (e: java.net.SocketTimeoutException) {
            "❌ Tempo esgotado. Sem internet ou o servidor não respondeu."
        } catch (e: javax.net.ssl.SSLException) {
            "❌ Falha de segurança (HTTPS): ${e.message}. O endereço precisa começar com https://."
        } catch (e: Exception) {
            "❌ ${e.javaClass.simpleName}: ${e.message}"
        } finally {
            conn.disconnect()
        }
    }

    private fun openConnection(request: GenerationRequest): HttpURLConnection {
        val conn = URL(chatUrl()).openConnection() as HttpURLConnection
        connection = conn
        conn.requestMethod = "POST"
        conn.connectTimeout = 15_000
        conn.readTimeout = 120_000
        conn.doOutput = true
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("Accept", "text/event-stream")
        if (!apiKey.isNullOrBlank()) conn.setRequestProperty("Authorization", "Bearer ${apiKey.trim()}")

        val msgs = JSONArray()
        request.messages.forEach { msgs.put(ChatJson.message(it.role, it.content, it.images)) }
        val body = JSONObject()
            .put("model", effectiveModel)
            .put("messages", msgs)
            .put("stream", true)
            .put("temperature", request.temperature.toDouble())
            .put("max_tokens", request.maxTokens)
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        return conn
    }

    private fun isTerminalSse(payload: String): Boolean = try {
        val choice = JSONObject(payload).optJSONArray("choices")?.optJSONObject(0)
        choice != null && !choice.isNull("finish_reason") && choice.optString("finish_reason").isNotBlank()
    } catch (_: Exception) {
        false
    }

    private fun parseDelta(payload: String): String = try {
        val delta = JSONObject(payload)
            .optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("delta")
        if (delta != null && !delta.isNull("content")) delta.getString("content") else ""
    } catch (e: Exception) {
        ""
    }

    private fun parseFullMessage(raw: String): String = try {
        val msg = JSONObject(raw.trim())
            .optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")
        if (msg != null && !msg.isNull("content")) msg.getString("content") else ""
    } catch (e: Exception) {
        ""
    }

    private companion object {
        const val MAX_NON_SSE_CHARS = 20_000
    }
}

const val DEFAULT_MODEL = "gemini-3.8-flash"

/** Mensagem no formato OpenAI; com imagens vira conteúdo multimodal (texto + image_url em base64). */
object ChatJson {
    fun message(role: String, content: String, images: List<String>): JSONObject {
        if (images.isEmpty()) return JSONObject().put("role", role).put("content", content)
        val parts = JSONArray().put(JSONObject().put("type", "text").put("text", content))
        images.forEach {
            parts.put(
                JSONObject().put("type", "image_url")
                    .put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$it"))
            )
        }
        return JSONObject().put("role", role).put("content", parts)
    }
}

/** Normalização de endereços da nuvem (aceita como o usuário cola: sem https://, só o domínio, com /chat/completions…). */
object CloudUrls {
    fun base(endpoint: String): String {
        var base = endpoint.trim().trimEnd('/')
        if (!base.startsWith("http://") && !base.startsWith("https://")) base = "https://$base"
        base = base.removeSuffix("/chat/completions").removeSuffix("/tts").removeSuffix("/image").trimEnd('/')
        val path = runCatching { java.net.URI(base).path.orEmpty() }.getOrDefault("")
        if (path.isEmpty() || path == "/") base += "/v1"
        return base
    }
    fun chat(endpoint: String): String = base(endpoint) + "/chat/completions"
    fun tts(endpoint: String): String = base(endpoint) + "/tts"
    fun image(endpoint: String): String = base(endpoint) + "/image"
}
