# Latência e medição (rodada 9.2.2)

Nenhuma otimização desta ou da rodada anterior foi medida: o ambiente de revisão não tinha Android SDK nem aparelho.
Nada foi compilado nem executado. Tudo abaixo é "justificado pelo código", não "comprovado".

## Hipóteses — situação

| # | Hipótese | Situação |
|---|----------|----------|
| 1 | `/no_think` desliga o raciocínio do Qwen3 | **NÃO confirmada.** É só texto acrescentado ao `systemPrompt` (LocalGgufProvider.formatPrompt). Não se sabe se o AAR aplica template de chat. Medir: `think_tag_in_raw` |
| 2 | Existe stop sequence | **Não existe.** Nenhuma sequência é enviada ao motor. `sanitize()` corta o texto depois. Medir o desperdício: `post_cut_chars` |
| 3 | Parar interrompe a inferência | **Não interrompe.** Só libera a UI; a chamada nativa continua e a próxima mensagem espera (`queue_wait`) |
| 4 | Pré-carga tira o custo da 1ª mensagem | **Provável, não medido.** Carga em `ModelManager.refresh` na inicialização. Se o AAR usar mmap, parte do custo pode aparecer na 1ª inferência |
| 5 | Memória semântica saiu do caminho crítico | **Em parte.** Carga do BGE-M3 e espera por mutex saíram. Com o modelo quente ainda há 1 `Llama.embed` da pergunta antes da geração (`memory_embed_query`) |
| 6 | Contexto 3072 corresponde ao runtime | **Não confirmado.** Ver abaixo |

### Fatos confirmados pelo código
- **Sem streaming real no motor local.** `Llama.complete` devolve tudo no fim; o Flow emite uma vez. Nada simula chegada gradual. Só o provider remoto (SSE) faz streaming de verdade.
- **Parar**: `stop()` → `agent.cancel()` marca o ticket da requisição como cancelado e `generationJob.cancel()` cancela a coleta. O `Llama.complete` em andamento termina em segundo plano e o resultado é descartado. Enquanto roda, o estado fica "Generating" (pílula "GERANDO", envio desabilitado). No provider remoto, Parar fecha a conexão HTTP (interrupção real).
- **Pré-carga**: `AppContainer.startup` → `ModelManager.refresh()` → `LocalGgufProvider.load()` → `ensureLoaded()`. `ensureLoaded` é idempotente, então não há segunda carga.

### Contexto (ponto 6)
- Subi `contextSize` de 2048 para 3072 na rodada anterior. Isso **aumenta a RAM do cache KV** (estimativa para Qwen3-1.7B com KV f16: ~224 MiB → ~336 MiB; premissas, não medido).
- Não sei se o AAR respeita `contextSize`. O `api_probe` lista os campos de `LlamaConfig`.
- O orçamento de prompt usa 3 chars/token (estimativa). Consequência do orçamento local: ~3200 caracteres de histórico (antes 6000) e 24 mensagens (antes 40). **A Aurora "esquece" turnos antigos mais cedo.** Isso é um custo de qualidade, não de graça.
- Persona grande (limite do editor: 24 mil chars) ou anexo grande não são cortados silenciosamente: o log marca `ctx_overflow_risk=true`.

## Correções de regressão desta rodada
- `sanitize` podia apagar a resposta inteira se ela começasse com "Usuário:" → agora só corta turnos falsos que não estejam no início.
- Flag `cancelled` era global; uma geração nova podia "reviver" a anterior → agora um ticket por requisição.
- `release()` podia liberar o modelo no meio de `Llama.complete` (use-after-free nativo) → agora espera o mutex.
- `ModelManager.refresh()` recarregava o GGUF inteiro ao salvar/limpar só o endpoint remoto → o provider local é reaproveitado se o arquivo for o mesmo.
- `refresh()` liberava os providers antes de ler seus estados, mascarando o erro real do GGUF → ordem corrigida.
- `SemanticMemory.relevant` podia esperar um mutex ocupado por indexação → `tryLock`. O aquecimento deixou de disputar CPU com a inferência: agora ocorre na inicialização e depois de cada resposta.

## Como medir no aparelho
Use um build **debug** (ou release com `PerfLog.ENABLED = true`, que é o padrão).
```
adb logcat -c
adb logcat -s AURORA_PERF
```
Envie 5 mensagens curtas e 2 longas. Descarte a #1 para ver o regime quente; compare a #1 com a #2.

Campos (cada mensagem tem `req=N`; tempos em ms desde o toque em enviar quando terminam em `_at`):
- `job_started_at`: atraso entre o toque e o início do processamento.
- `db_create_conversation`, `db_history`, `db_save_user_message`: etapas de banco antes do agente.
- `thinking_bubble_published_at` e `ui_thinking_bubble`: quando a bolha "Pensando…" foi publicada e quando foi desenhada (≈ ±16ms).
- `memory_db`, `memory_semantic`, `memory_embed_query`, `memory_vectors_db`, `memory_lexical`, `memory_path`, `memory`: recuperação de memória.
- `tools`, `prompt_assemble`, `prompt_total`, `prompt_chars`, `prompt_est_tokens`: preparação do prompt.
- `queue_wait`: >0 significa que uma chamada nativa anterior (ex.: Parar) ainda estava rodando.
- `model_load`, `model_resident`: ~0 e `true` se a pré-carga funcionou. `model_preload`, `model_load_native` na inicialização.
- `prompt_format`, `inference`, `native_result`, `postprocess`: o miolo local.
- `raw_out_chars`, `est_out_tokens`, `est_tok_per_s`, `est_hit_max_tokens`, `think_tag_in_raw`, `post_cut_chars`.
- `first_piece_at`: **tempo até a primeira resposta disponível**. No motor local é a resposta completa.
- `ui_first_text`, `ui_final_text`: publicação → texto desenhado.
- `generation_done_at`, `db_save_assistant_message`, `total_at`: fechamento.
- Remoto: `remote_headers`, `remote_first_delta`, `remote_sse_deltas`, `remote_deltas_per_s`.
- TTS (separado, só ao tocar em falar): `tts_request`, `tts_first_audio`, `tts_total`.
- Whisper: `stt_model_load`, `stt_transcribe`.
- Uma vez por processo: `api_probe` lista métodos e campos de `Llama`/`LlamaConfig`. Procure por stream/stop/tokenize/cancel.

### Tokens por segundo
O AAR não confirmou nenhuma contagem de tokens. `est_tok_per_s` = (chars/3)/inferência, **estimativa, inclui o prefill**.
Para um número honesto: veja `native_result` (se o resultado expõe tokens ou tempos) e `api_probe`. Se houver `tokenize`, ligue-o em `reportThroughput`.
Alternativa independente: o mesmo GGUF no `llama-bench` do llama.cpp, no mesmo aparelho.

### Ordem de leitura sugerida
1. `est_hit_max_tokens=true` e `post_cut_chars` grande: o modelo roda até o limite (sem EOS/stop) e o app corta depois. Esse é o candidato nº 1 a causar demora, e só um stop real ou um template de chat resolve.
2. `think_tag_in_raw=true`: o `/no_think` não funcionou.
3. `inference` vs `prompt_total`: o tempo está no motor ou no app?
4. `model_load` da 1ª mensagem vs `model_preload`.
5. `ui_*`: a UI está atrasada em relação à publicação?

### Testes A/B sem recompilar
Crie `files/aurora-config/perf.cfg` (apenas builds debug):
```
adb shell run-as com.aurora.v9 sh -c 'printf "threads=4\nno_think=0\n" > files/aurora-config/perf.cfg'
```
`threads=N` vale no próximo carregamento do modelo (reinicie o app). `no_think=0` vale na próxima mensagem. Apague o arquivo para voltar ao padrão.

## Para streaming real no futuro
`ModelProvider.generate` já é um `Flow<String>` e o ViewModel já consome pedaços (publicação limitada a ~20/s). Um novo provider (JNI próprio ou outro runtime com callback de token e cancelamento) entra sem mudar ViewModel nem UI. Ele deveria expor também stop sequences, cancelamento nativo e contagem real de tokens.

## Remover a instrumentação
Apague `core/perf/`, o campo `trace` de `GenerationRequest` e as linhas que usam `trace.`/`PerfLog.`/`PerfOverrides.`/`PerfTrace`. Ou ponha `PerfLog.ENABLED = false`.

## Permanece
- Não compilado. Gradle/Compose BOM/KSP/Lottie não foram validados por build.
- Sem serviço em primeiro plano: o Android pode limitar a CPU da inferência com o app em segundo plano.
- Whisper recarrega o modelo a cada transcrição (apenas medido, não alterado).
- Imagens de tema 1024×1536 são decodificadas na composição (UI thread) ao trocar de tema; não alterado, para preservar a identidade visual.
- Heurística de threads (núcleos ≥70% da frequência máxima) não validada; sysfs pode ser ilegível (fallback metade dos núcleos).
