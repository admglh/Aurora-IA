# Checklist Aurora 0.1

## Interface
- [x] Preto absoluto
- [x] Azul royal
- [x] Dourado tecnológico
- [x] Aurora central
- [x] Binários discretos
- [x] Pulsação
- [x] Avatar circular com animação facial
- [x] Palavra do Dia
- [x] Conversa, ferramentas, memória e configurações separados
- [x] Guarda-roupa

## IA e recursos
- [x] GGUF local
- [x] Biblioteca local de múltiplos modelos
- [x] Pesquisa online de GGUF no Hugging Face
- [x] Whisper
- [x] sherpa-onnx preparado
- [x] MediaPipe preparado
- [x] Importação universal
- [x] Manifesto de plugin
- [x] GitHub API
- [x] GitHub MCP preparado
- [x] droid-mcp integrado pela API oficial
- [x] Root/Shizuku opt-in
- [x] MCP HTTP autenticado

## Segurança e armazenamento
- [x] Dados privados no armazenamento do app
- [x] ZIP com proteção contra path traversal
- [x] Memórias com confirmação antes de apagar
- [x] Modelo ativo protegido contra exclusão
- [x] Arquivo original pode ser apagado depois da importação
- [x] Backup/versões antigas não fazem parte da estrutura oficial

## Validação externa obrigatória
- [ ] Build no Termux do usuário
- [ ] Instalação no Android
- [ ] Execução real das permissões
- [ ] Execução real dos modelos
- [ ] Execução real das 151 capacidades disponíveis conforme permissões
- [ ] Execução real de GitHub MCP
- [ ] Execução real de visão/voz

Esses itens finais não são falsamente marcados como verdes porque dependem do aparelho real.
