# Aurora 0.1 — Correções desta rodada

## Corrigido na fonte
- [x] droid-mcp deixou de usar reflexão/`INSTANCE` incorreto.
- [x] droid-mcp usa `DroidMcp.builder()` e `addTools(...)` da API oficial.
- [x] HTTP MCP usa `enableHttpServer(context = ..., requireAuth = true)`.
- [x] Root/Shizuku foram adicionados como módulos opt-in.
- [x] Permissões runtime podem ser solicitadas pela tela Celular.
- [x] O runtime pode ser reconstruído depois que permissões mudam.
- [x] GitHub público: repositórios, issues e releases.
- [x] Pesquisa web.
- [x] Palavra do Dia NVI-PT com cache.
- [x] Catálogo inicial de modelos.
- [x] Pesquisa online de modelos GGUF no Hugging Face.
- [x] Download/resume de modelos grandes.
- [x] Instalador universal de recursos.
- [x] Manifesto `aurora-extension.json` para pacotes de extensão.
- [x] ZIP com proteção contra path traversal.
- [x] Arquivos temporários de extensões remotas são apagados depois da instalação.
- [x] GitHub MCP Server preparado para compilação no Termux.
- [x] MCP Node preparado no Termux.
- [x] llama.cpp compilado no Termux.
- [x] sherpa-onnx Android + Whisper/VAD/Kokoro preparados no Termux.
- [x] Bubble usa contador sequencial persistente em vez do ID do banco.
- [x] Guarda-roupa e identidade visual preservados.
- [x] Interface mantém detalhes avançados escondidos por níveis.
- [x] Documentação antiga de versões 9.x removida da estrutura oficial 0.1.
- [x] Auditoria automática não chama mais “OK” só por encontrar strings.

## Validação que depende do aparelho real
- [ ] Compilação final no Termux do usuário.
- [ ] Execução das ferramentas após concessão de permissões.
- [ ] Shizuku/root, caso o usuário os configure.
- [ ] GitHub MCP Server realmente executado no Termux.
- [ ] Modelos reais carregados no aparelho.
- [ ] Visão/voz executadas com modelos reais.
- [ ] Palavra do Dia confirmada contra resposta ao vivo do serviço.
