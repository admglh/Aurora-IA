package com.aurora.core.resources

import android.os.Environment
import java.io.File

data class AuroraResource(
    val file: File,
    val type: Type
) {
    enum class Type {
        CHAT_MODEL,
        VISION_MODEL,
        PROJECTOR,
        EMBEDDING,
        RERANKER,
        ASR,
        VAD,
        TTS,
        OCR,
        EXTENSION,
        UNKNOWN
    }
}

object AuroraResourceScanner {

    fun root(): File =
        File(
            Environment.getExternalStorageDirectory(),
            "Download/Aurora"
        )

    fun scan(): List<AuroraResource> {
        val base = root()
        if (!base.exists()) return emptyList()

        return base.walkTopDown()
            .filter { it.isFile }
            .map { file ->
                val n = file.name.lowercase()

                val type = when {
                    n.endsWith(".gguf") && n.contains("mmproj") ->
                        AuroraResource.Type.PROJECTOR

                    n.endsWith(".gguf") && (
                        n.contains("qwen2.5-vl") ||
                        n.contains("vision") ||
                        n.contains("vl-")
                    ) ->
                        AuroraResource.Type.VISION_MODEL

                    n.endsWith(".gguf") && n.contains("rerank") ->
                        AuroraResource.Type.RERANKER

                    n.endsWith(".gguf") && (
                        n.contains("bge") ||
                        n.contains("embed")
                    ) ->
                        AuroraResource.Type.EMBEDDING

                    n.endsWith(".gguf") ->
                        AuroraResource.Type.CHAT_MODEL

                    n.endsWith(".onnx") && (
                        n.contains("vad") ||
                        n.contains("silero")
                    ) ->
                        AuroraResource.Type.VAD

                    n.endsWith(".onnx") && (
                        n.contains("ocr") ||
                        n.contains("pp-")
                    ) ->
                        AuroraResource.Type.OCR

                    n.endsWith(".bin") && (
                        n.contains("whisper") ||
                        n.contains("ggml")
                    ) ->
                        AuroraResource.Type.ASR

                    n.endsWith(".onnx") &&
                        (n.contains("kokoro") ||
                         file.parentFile?.name?.contains("kokoro", true) == true) ->
                        AuroraResource.Type.TTS

                    n.endsWith(".zip") &&
                        (n.contains("extension") || n.contains("plugin")) ->
                        AuroraResource.Type.EXTENSION

                    else -> AuroraResource.Type.UNKNOWN
                }

                AuroraResource(file, type)
            }
            .toList()
    }

    fun chatModels(): List<File> =
        scan()
            .filter { it.type == AuroraResource.Type.CHAT_MODEL }
            .map { it.file }

    fun visionModels(): List<File> =
        scan()
            .filter { it.type == AuroraResource.Type.VISION_MODEL }
            .map { it.file }
}
