import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.aurora"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.aurora"
        minSdk = 29
        targetSdk = 36
        versionCode = 10003
        versionName = "0.3"
        ndk { abiFilters += listOf("arm64-v8a") }
    }
    buildTypes {
        release {
            // Release otimizado (R8 + remoção de recursos não usados). O build debug é bem mais lento e pesado;
            // para o uso diário gere com: ./gradlew :app:assembleRelease
            isMinifyEnabled = false
            isShrinkResources = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // Mesma chave do build debug: instala por cima do app atual sem perder conversas e memórias.
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    buildFeatures { compose = true; buildConfig = true }
    packaging { jniLibs.useLegacyPackaging = false; resources.excludes += setOf("/META-INF/{AL2.0,LGPL2.1}", "META-INF/INDEX.LIST", "META-INF/io.netty.versions.properties", "META-INF/LICENSE.md", "META-INF/NOTICE.md", "META-INF/license/**", "META-INF/versions/9/OSGI-INF/MANIFEST.MF") }
}

kotlin {
    compilerOptions { jvmTarget.set(JvmTarget.JVM_17) }
}

// Exporta o schema do Room (app/schemas/) para validar migrações futuras.
ksp {
    arg("room.schemaLocation", "$projectDir/schemas")
}

dependencies {
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.activity:activity-compose:1.11.0")
    implementation(platform("androidx.compose:compose-bom:2026.06.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    debugImplementation("androidx.compose.ui:ui-tooling")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.9.4")
    implementation("androidx.lifecycle:lifecycle-process:2.9.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.9.4")
    implementation("androidx.room:room-runtime:2.8.2")
    implementation("androidx.room:room-ktx:2.8.2")
    ksp("androidx.room:room-compiler:2.8.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
    // Runtime local GGUF: llama.cpp pré-compilado para Android arm64-v8a.
    implementation("dev.ffmpegkit-maintained:llama-android:0.1.1")
    // STT opcional e local: usado apenas quando um modelo Whisper for importado.
    implementation("dev.ffmpegkit-maintained:whisper-android:1.0.0")
    // Android tool layer: droid-mcp exposes the phone as structured tools for the local agent.
    implementation("com.github.stixez.droid-mcp:droid-mcp-core:0.11.0")
    implementation("com.github.stixez.droid-mcp:droid-mcp-all:0.11.0")
    // Shell extensions are opt-in in droid-mcp-all; Aurora keeps both available so the
    // same 17 shell capabilities can use Shizuku when available and root when available.
    implementation("com.github.stixez.droid-mcp:droid-mcp-shizuku:0.11.0")
    implementation("com.github.stixez.droid-mcp:droid-mcp-root:0.11.0")
}
