# Regras R8 da Aurora. Bibliotecas nativas (JNI) e SDKs por reflexão não podem ser renomeados/removidos.
-keep class com.aurora.** { *; }
-keep class dev.ffmpegkit.** { *; }
-keepclasseswithmembernames class * { native <methods>; }
-keep class io.droidmcp.** { *; }
-keep class rikka.shizuku.** { *; }
-keep class * extends androidx.room.RoomDatabase
-dontwarn **
