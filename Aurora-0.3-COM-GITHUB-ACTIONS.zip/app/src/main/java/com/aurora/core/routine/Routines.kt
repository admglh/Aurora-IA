package com.aurora.core.routine

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.CalendarContract
import androidx.core.app.NotificationCompat
import com.aurora.AuroraApplication
import com.aurora.MainActivity
import com.aurora.R
import com.aurora.core.model.OpenAICompatibleProvider
import com.aurora.core.settings.AuroraSettings
import com.aurora.core.settings.SecretStore
import com.aurora.core.tools.WebData
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONObject as J
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class Reminder(val id: Int, val at: Long, val text: String)

/** Lembretes com notificação e resumo matinal diário. Agendado pelo AlarmManager (sobrevive a reinício via receiver de boot). */
object Routines {
    const val ACTION_BRIEF = "com.aurora.action.BRIEF"
    const val ACTION_REMIND = "com.aurora.action.REMIND"
    private const val CHANNEL = "aurora_routines"
    private const val BRIEF_CODE = 7001
    private const val BRIEF_NOTIF = 7002

    // ---------- lembretes ----------
    fun reminders(settings: AuroraSettings): List<Reminder> = runCatching {
        val arr = JSONArray(settings.remindersJson)
        (0 until arr.length()).map { i -> arr.getJSONObject(i).let { Reminder(it.getInt("id"), it.getLong("at"), it.getString("text")) } }
    }.getOrDefault(emptyList())

    private fun save(settings: AuroraSettings, list: List<Reminder>) {
        val arr = JSONArray()
        list.forEach { arr.put(J().put("id", it.id).put("at", it.at).put("text", it.text)) }
        settings.remindersJson = arr.toString()
    }

    fun addReminder(context: Context, settings: AuroraSettings, atMillis: Long, text: String): Reminder {
        val existing = reminders(settings)
        val id = (existing.maxOfOrNull { it.id } ?: 100) + 1
        val r = Reminder(id, atMillis, text.trim().take(200))
        save(settings, existing + r)
        scheduleReminder(context, r)
        return r
    }

    fun cancelReminder(context: Context, settings: AuroraSettings, id: Int) {
        val am = context.getSystemService(AlarmManager::class.java)
        am.cancel(reminderIntent(context, Reminder(id, 0, "")))
        save(settings, reminders(settings).filter { it.id != id })
    }

    fun removeFired(settings: AuroraSettings, id: Int) = save(settings, reminders(settings).filter { it.id != id })

    private fun reminderIntent(context: Context, r: Reminder): PendingIntent =
        PendingIntent.getBroadcast(
            context, r.id,
            Intent(context, AuroraAlarmReceiver::class.java).setAction(ACTION_REMIND).putExtra("id", r.id).putExtra("text", r.text),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    private fun scheduleReminder(context: Context, r: Reminder) = scheduleAt(context, r.at, reminderIntent(context, r))

    private fun scheduleAt(context: Context, at: Long, pi: PendingIntent) {
        val am = context.getSystemService(AlarmManager::class.java)
        val exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
        runCatching {
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }.onFailure { runCatching { am.set(AlarmManager.RTC_WAKEUP, at, pi) } }
    }

    // ---------- resumo matinal ----------
    private fun briefIntent(context: Context): PendingIntent =
        PendingIntent.getBroadcast(
            context, BRIEF_CODE, Intent(context, AuroraAlarmReceiver::class.java).setAction(ACTION_BRIEF),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    fun nextBriefTime(settings: AuroraSettings, now: Long = System.currentTimeMillis()): Long {
        val c = Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.HOUR_OF_DAY, settings.briefHour); set(Calendar.MINUTE, settings.briefMinute)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        if (c.timeInMillis <= now + 30_000) c.add(Calendar.DAY_OF_YEAR, 1)
        return c.timeInMillis
    }

    /** Liga/desliga conforme as configurações. Chame ao mudar a configuração, ao abrir o app e no boot. */
    fun applyBrief(context: Context, settings: AuroraSettings) {
        val am = context.getSystemService(AlarmManager::class.java)
        am.cancel(briefIntent(context))
        if (settings.briefEnabled) scheduleAt(context, nextBriefTime(settings), briefIntent(context))
    }

    fun rescheduleAll(context: Context, settings: AuroraSettings) {
        applyBrief(context, settings)
        val now = System.currentTimeMillis()
        val keep = reminders(settings).filter { it.at > now - 60_000 }
        save(settings, keep)
        keep.forEach { scheduleReminder(context, if (it.at <= now) it.copy(at = now + 5_000) else it) }
    }

    // ---------- notificações ----------
    private fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL, "Aurora · lembretes e resumo", NotificationManager.IMPORTANCE_HIGH)
            )
        }
    }

    fun notify(context: Context, id: Int, title: String, text: String) {
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        ensureChannel(context)
        val open = PendingIntent.getActivity(
            context, id, Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_aurora)
            .setContentTitle(title)
            .setContentText(text.lineSequence().firstOrNull().orEmpty().take(120))
            .setStyle(NotificationCompat.BigTextStyle().bigText(text.take(1800)))
            .setContentIntent(open)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        runCatching { context.getSystemService(NotificationManager::class.java).notify(id, n) }
    }

    /** Eventos de hoje da agenda (só se a permissão de agenda já foi concedida). */
    private fun todayEvents(context: Context): String {
        if (context.checkSelfPermission(Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) return ""
        val start = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }.timeInMillis
        val end = start + 24L * 3600 * 1000
        val uri = CalendarContract.Instances.CONTENT_URI.buildUpon().also {
            android.content.ContentUris.appendId(it, start); android.content.ContentUris.appendId(it, end)
        }.build()
        val fmt = SimpleDateFormat("HH:mm", Locale("pt", "BR"))
        val lines = mutableListOf<String>()
        runCatching {
            context.contentResolver.query(uri, arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN, CalendarContract.Instances.ALL_DAY),
                null, null, "${CalendarContract.Instances.BEGIN} ASC")?.use { c ->
                while (c.moveToNext() && lines.size < 8) {
                    val title = c.getString(0).orEmpty().ifBlank { "(sem título)" }
                    lines += if (c.getInt(2) == 1) "• $title (dia todo)" else "• ${fmt.format(Date(c.getLong(1)))} $title"
                }
            }
        }
        return if (lines.isEmpty()) "" else "Agenda de hoje:\n" + lines.joinToString("\n")
    }

    /** Monta o resumo: dados reais primeiro; o modelo só resume (e se falhar/demorar, entrega os dados crus). */
    suspend fun buildBrief(context: Context): String {
        val container = (context.applicationContext as AuroraApplication).container
        val settings = container.settings
        val data = listOf(todayEvents(context), WebData.plainBrief(settings.briefCity, settings.briefTopics)).filter { it.isNotBlank() }.joinToString("\n\n")
        if (data.isBlank()) return "Bom dia! Configure sua cidade e assuntos em Ajustes → Rotinas para eu montar seu resumo."
        if (settings.remoteEndpoint.isBlank()) return data
        val provider = OpenAICompatibleProvider(settings.remoteEndpoint, settings.remoteModel, container.secrets.get(SecretStore.KEY_REMOTE_API))
        val msgs = JSONArray()
            .put(J().put("role", "system").put("content", "Você é a Aurora, assistente pessoal (voz feminina). Escreva em português do Brasil, caloroso e direto."))
            .put(J().put("role", "user").put("content", "Faça meu resumo matinal em no máximo 6 linhas curtas, sem markdown, usando SÓ estes dados reais. Cumprimente e dê uma dica prática (ex.: levar guarda-chuva).\n\n$data"))
        val answer = withTimeoutOrNull(25_000) {
            runCatching { provider.chatOnce(msgs, JSONArray(), 1024, 0.6).text.trim() }.getOrNull()
        }
        return if (answer.isNullOrBlank()) data else answer
    }

    fun fireBrief(context: Context, onDone: () -> Unit) {
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                val text = buildBrief(context)
                notify(context, BRIEF_NOTIF, "Aurora · seu resumo de hoje", text)
            } finally {
                val settings = (context.applicationContext as AuroraApplication).container.settings
                applyBrief(context, settings) // agenda o próximo dia
                onDone()
            }
        }
    }
}

class AuroraAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext as AuroraApplication
        when (intent.action) {
            Routines.ACTION_REMIND -> {
                val id = intent.getIntExtra("id", 0)
                val text = intent.getStringExtra("text").orEmpty().ifBlank { "Lembrete" }
                Routines.notify(context, 8000 + id, "Aurora · lembrete", text)
                Routines.removeFired(app.container.settings, id)
            }
            Routines.ACTION_BRIEF -> {
                val pending = goAsync()
                Routines.fireBrief(context) { runCatching { pending.finish() } }
            }
            Intent.ACTION_BOOT_COMPLETED, "android.intent.action.MY_PACKAGE_REPLACED" -> Routines.rescheduleAll(context, app.container.settings)
        }
    }
}
