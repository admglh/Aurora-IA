# Compilar a Aurora pela nuvem (sem Termux)

Este repositório inclui o workflow `.github/workflows/aurora-android.yml`.

## Como usar

1. Envie o conteúdo deste projeto para a branch `main` do repositório `Aurora-IA` (esta etapa é necessária uma única vez para registrar o workflow e a versão 0.3 no GitHub).
2. No GitHub, abra **Actions → Aurora Android APK**.
3. Toque em **Run workflow** para iniciar manualmente. Também será executado em novos pushes de código na `main`.
4. Abra a execução concluída e baixe o artefato `Aurora-debug-apk-...`.
5. Extraia `app-debug.apk` do ZIP baixado e instale no Android.

O artefato de relatório registra o commit exato, a referência e a versão declarada nos arquivos do build. Assim fica possível diferenciar a Aurora 0.3 deste projeto da versão antiga que já estava no GitHub.

## Limites importantes

- Este workflow compila o APK debug; não publica automaticamente código no repositório nem altera Worker, Cloudflare ou credenciais.
- O APK debug é assinado com a chave de depuração do Android. Uma instalação existente assinada com outra chave pode não aceitar atualização por cima. Não desinstale a versão existente sem confirmar como preservar os dados.
- Para enviar código à nuvem a partir do aplicativo, será necessário implementar uma integração autenticada e segura com GitHub. Não coloque um token pessoal dentro do APK; ele pode ser extraído. Prefira um fluxo de autorização revogável e permissões mínimas.
- O sucesso da compilação confirma que o APK foi gerado, não que todos os recursos do aplicativo estejam funcionando. Esses recursos precisam ser testados separadamente no dispositivo.
