#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT"
if ! command -v java >/dev/null 2>&1; then
  echo "JDK ausente. Instale OpenJDK 17+ no Termux antes do build."
  exit 1
fi
if [ -z "${ANDROID_HOME:-}" ] && [ -z "${ANDROID_SDK_ROOT:-}" ]; then
  echo "ANDROID_HOME/ANDROID_SDK_ROOT não está configurado."
  exit 2
fi
bash "$ROOT/tools/build_apk.sh"
