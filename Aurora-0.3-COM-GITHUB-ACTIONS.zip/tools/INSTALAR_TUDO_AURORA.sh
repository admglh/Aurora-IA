#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
SRC="$(cd "$(dirname "$0")/.." && pwd)"
TARGET="${AURORA_HOME:-$HOME/Aurora Nova}"
ASSETS="${AURORA_ASSET_ROOT:-/storage/emulated/0/Download/Aurora}"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_ROOT="$HOME/Aurora-Backups/$STAMP"
log(){ printf '\n[AURORA] %s\n' "$*"; }

[ -d "$SRC/app" ] || { echo "Projeto Aurora não encontrado."; exit 2; }
mkdir -p "$BACKUP_ROOT"
for old in "$TARGET" "$HOME/Aurora Projeto" "$HOME/Nova-Aurora" "$HOME/aurora_nova" "$HOME/minha_ia"; do
  if [ -e "$old" ]; then
    name="$(basename "$old")"
    mv "$old" "$BACKUP_ROOT/$name"
    log "Backup: $old -> $BACKUP_ROOT/$name"
  fi
done

rm -rf "$TARGET"
mkdir -p "$TARGET"
cp -a "$SRC/." "$TARGET/"
chmod +x "$TARGET"/tools/*.sh "$TARGET"/gradlew "$TARGET"/termux/*.sh 2>/dev/null || true

export AURORA_ASSET_ROOT="$ASSETS"
mkdir -p "$ASSETS"
"$TARGET/tools/ORGANIZAR_RECURSOS_AURORA.sh"

cat > "$TARGET/aurora-env.sh" <<ENV
export AURORA_HOME="$TARGET"
export AURORA_ASSET_ROOT="$ASSETS"
export ANDROID_HOME="\${ANDROID_HOME:-$HOME/android-sdk}"
export ANDROID_SDK_ROOT="\${ANDROID_SDK_ROOT:-$HOME/android-sdk}"
export PATH="\$ANDROID_HOME/platform-tools:\$PATH"
ENV

cat > "$TARGET/INSTALACAO_REALIZADA.txt" <<TXT
Aurora Nova instalada: $(date -Iseconds)
Projeto: $TARGET
Recursos: $ASSETS
Backup: $BACKUP_ROOT
TXT

log "Instalação limpa concluída."
log "Recurso compartilhado preservado em: $ASSETS"
log "Diagnóstico: $TARGET/tools/DIAGNOSTICO_FINAL.sh"
log "Termux chat: $TARGET/termux/iniciar.sh"
log "Build APK: $TARGET/tools/build_apk.sh"
