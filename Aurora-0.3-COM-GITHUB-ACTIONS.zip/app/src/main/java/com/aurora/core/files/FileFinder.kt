package com.aurora.core.files

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import com.aurora.core.settings.AuroraSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

data class FoundFile(val name: String, val uri: Uri, val mime: String, val size: Long, val modified: Long, val folder: String)

/**
 * Busca de arquivos nas pastas que o usuário liberou (Storage Access Framework): sem permissão especial de
 * "todos os arquivos", e a Aurora só enxerga o que foi escolhido. Somente leitura.
 */
class FileFinder(private val context: Context, private val settings: AuroraSettings) {

    fun folders(): List<Uri> = settings.fileFolders.mapNotNull { runCatching { Uri.parse(it) }.getOrNull() }

    fun folderLabel(tree: Uri): String =
        runCatching { DocumentsContract.getTreeDocumentId(tree).substringAfter(':').ifBlank { "Armazenamento" } }.getOrDefault("Pasta")

    fun addFolder(tree: Uri) {
        runCatching {
            context.contentResolver.takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        settings.fileFolders = settings.fileFolders + tree.toString()
    }

    fun removeFolder(tree: Uri) {
        runCatching { context.contentResolver.releasePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        settings.fileFolders = settings.fileFolders - tree.toString()
    }

    /** Procura por nome (todas as palavras) e/ou tipo ("pdf", "docx", "imagem", "texto"). */
    suspend fun search(query: String, type: String = "", limit: Int = 15): List<FoundFile> = withContext(Dispatchers.IO) {
        val words = query.lowercase(Locale.ROOT).split(Regex("\\s+")).filter { it.length >= 2 }
        val t = type.lowercase(Locale.ROOT).trim()
        val results = mutableListOf<FoundFile>()
        var visited = 0
        for (tree in folders()) {
            val rootId = runCatching { DocumentsContract.getTreeDocumentId(tree) }.getOrNull() ?: continue
            val stack = ArrayDeque<String>()
            stack.addLast(rootId)
            while (stack.isNotEmpty() && visited < MAX_VISIT && results.size < limit * 4) {
                val parent = stack.removeLast()
                val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parent)
                runCatching {
                    context.contentResolver.query(
                        children,
                        arrayOf(
                            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                            DocumentsContract.Document.COLUMN_MIME_TYPE,
                            DocumentsContract.Document.COLUMN_SIZE,
                            DocumentsContract.Document.COLUMN_LAST_MODIFIED
                        ), null, null, null
                    )?.use { c ->
                        while (c.moveToNext() && visited < MAX_VISIT) {
                            visited++
                            val id = c.getString(0) ?: continue
                            val name = c.getString(1) ?: continue
                            val mime = c.getString(2) ?: ""
                            if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                                if (!name.startsWith(".")) stack.addLast(id)
                                continue
                            }
                            val lower = name.lowercase(Locale.ROOT)
                            if (words.isNotEmpty() && !words.all { lower.contains(it) }) continue
                            if (t.isNotEmpty() && !matchesType(lower, mime, t)) continue
                            results += FoundFile(
                                name, DocumentsContract.buildDocumentUriUsingTree(tree, id), mime,
                                if (c.isNull(3)) -1 else c.getLong(3), if (c.isNull(4)) 0 else c.getLong(4), folderLabel(tree)
                            )
                        }
                    }
                }
            }
        }
        results.sortedByDescending { it.modified }.take(limit)
    }

    private fun matchesType(lowerName: String, mime: String, t: String): Boolean = when (t) {
        "pdf" -> lowerName.endsWith(".pdf")
        "docx", "word", "documento" -> lowerName.endsWith(".docx")
        "imagem", "foto", "image" -> mime.startsWith("image/")
        "texto", "text" -> mime.startsWith("text/") || lowerName.substringAfterLast('.', "") in setOf("txt", "md", "csv", "json")
        else -> lowerName.endsWith(".${t.removePrefix(".")}")
    }

    private companion object { const val MAX_VISIT = 8000 }
}
