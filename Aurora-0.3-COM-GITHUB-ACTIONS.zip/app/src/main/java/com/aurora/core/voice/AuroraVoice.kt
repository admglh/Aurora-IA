package com.aurora.core.voice

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Base64
import android.util.Log
import com.aurora.core.model.CloudUrls
import com.aurora.core.settings.AuroraSettings
import com.aurora.core.settings.SecretStore
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

data class VoiceInfo(val name: String, val label: String)

/**
 * Voz da Aurora.
 *
 * Dois motores, os dois passam pelo MESMO player (para que graves, agudos e volume valham para ambos):
 *  - "cloud": voz natural feminina do Gemini TTS, pedida ao seu Worker (/v1/tts). Se falhar, cai sozinho para a voz do aparelho.
 *  - "device": voz instalada no aparelho (TextToSpeech), preferindo voz feminina pt-BR.
 *
 * Ajustes (Configurações → Voz): tom, velocidade, graves, agudos, reforço de graves e volume.
 * Graves/agudos usam o equalizador do Android; se o aparelho não suportar, a fala continua normal.
 */
class AuroraVoice(
    context: Context,
    private val settings: AuroraSettings,
    private val secrets: SecretStore
) : TextToSpeech.OnInitListener {

    private val app = context.applicationContext
    private val tts = TextToSpeech(app, this)
    @Volatile private var ready = false
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val cacheDir = File(app.cacheDir, "tts").apply { mkdirs() }
    private val pending = ConcurrentHashMap<String, CompletableDeferred<Boolean>>()

    private var job: Job? = null
    @Volatile private var player: MediaPlayer? = null
    @Volatile private var cloudBackoffUntil = 0L
    @Volatile var lastNote: String = ""
        private set

    /** Chamado quando a fala termina normalmente (não quando é interrompida). Usado pelo modo conversa. */
    @Volatile var onFinished: (() -> Unit)? = null

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
        if (!ready) { lastNote = "O mecanismo de voz do Android não iniciou."; return }
        runCatching { tts.language = Locale("pt", "BR") }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { utteranceId?.let { pending[it]?.complete(true) } }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { utteranceId?.let { pending[it]?.complete(false) } }
            override fun onError(utteranceId: String?, errorCode: Int) { utteranceId?.let { pending[it]?.complete(false) } }
        })
    }

    /** Mantido por compatibilidade: os valores agora são lidos das configurações a cada fala. */
    fun configure(pitch: Float, rate: Float) { /* lido de [settings] em cada fala */ }

    fun voiceName(): String = settings.voiceDeviceName

    /** Vozes pt do aparelho, as mais prováveis de serem femininas/naturais primeiro. */
    fun deviceVoices(): List<VoiceInfo> {
        if (!ready) return emptyList()
        return runCatching {
            tts.voices.orEmpty()
                .filter { it.locale.language == "pt" }
                .sortedByDescending { score(it) }
                .map { VoiceInfo(it.name, "${it.name} · ${it.locale.country.ifBlank { "pt" }} · ${if (it.isNetworkConnectionRequired) "online" else "offline"}") }
        }.getOrDefault(emptyList())
    }

    fun speak(text: String) {
        val cleaned = clean(text)
        if (cleaned.isBlank()) return
        stop()
        job = scope.launch {
            val cloud = settings.voiceEngine == "cloud"
            val chunks = chunk(cleaned, if (cloud) CLOUD_CHUNK else DEVICE_CHUNK)
            val files = Channel<File>(2)
            val producer = launch {
                try {
                    for (part in chunks) {
                        val f = synth(part, cloud)
                        if (f != null) files.send(f)
                    }
                } finally {
                    files.close()
                }
            }
            try {
                for (f in files) {
                    try { play(f) } finally { f.delete() }
                }
            } finally {
                producer.cancel()
            }
            if (isActive) onFinished?.invoke()
        }
    }

    fun stop() {
        job?.cancel()
        job = null
        runCatching { tts.stop() }
        runCatching { player?.stop() }
        pending.values.forEach { it.complete(false) }
        pending.clear()
    }

    fun shutdown() {
        stop()
        scope.cancel()
        runCatching { tts.shutdown() }
    }

    // ---------------- síntese ----------------

    private suspend fun synth(part: String, cloud: Boolean): File? {
        if (cloud && System.currentTimeMillis() >= cloudBackoffUntil) {
            val f = runCatching { synthCloud(part) }
                .onFailure { lastNote = "Voz da nuvem indisponível (${it.message ?: it.javaClass.simpleName}); usando a voz do aparelho." }
                .getOrNull()
            if (f != null) return f
            // Evita esperar um erro a cada trecho (o plano grátis do Gemini TTS tem limite baixo).
            cloudBackoffUntil = System.currentTimeMillis() + 60_000
        }
        return synthDevice(part)
    }

    private fun synthCloud(part: String): File? {
        val endpoint = settings.remoteEndpoint
        if (endpoint.isBlank()) return null
        val conn = URL(CloudUrls.tts(endpoint)).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15_000
            conn.readTimeout = 45_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            secrets.get(SecretStore.KEY_REMOTE_API)?.trim()?.takeIf { it.isNotBlank() }?.let {
                conn.setRequestProperty("Authorization", "Bearer $it")
            }
            val body = JSONObject().put("text", part).put("voice", settings.voiceCloudName)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            if (code !in 200..299) {
                val err = conn.errorStream?.bufferedReader()?.use { it.readText() }?.take(200).orEmpty()
                error("HTTP $code $err".trim())
            }
            val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            val pcm = Base64.decode(json.getString("pcm"), Base64.DEFAULT)
            if (pcm.size < 200) error("áudio vazio")
            val rate = json.optInt("rate", 24_000)
            val f = File(cacheDir, "c-${System.nanoTime()}.wav")
            f.writeBytes(wav(pcm, rate))
            return f
        } finally {
            conn.disconnect()
        }
    }

    private suspend fun synthDevice(part: String): File? {
        if (!ready) return null
        applyDeviceVoice()
        val f = File(cacheDir, "d-${System.nanoTime()}.wav")
        val id = "u-${System.nanoTime()}"
        val done = CompletableDeferred<Boolean>()
        pending[id] = done
        val r = tts.synthesizeToFile(part, Bundle(), f, id)
        if (r != TextToSpeech.SUCCESS) { pending.remove(id); f.delete(); return null }
        val ok = withTimeoutOrNull(30_000) { done.await() } ?: false
        pending.remove(id)
        return if (ok && f.length() > 100) f else { f.delete(); null }
    }

    private fun applyDeviceVoice() {
        runCatching {
            tts.setPitch(settings.voicePitch)
            tts.setSpeechRate(settings.voiceRate)
            val voices = tts.voices.orEmpty().filter { it.locale.language == "pt" }
            val wanted = settings.voiceDeviceName
            val chosen = voices.firstOrNull { wanted.isNotBlank() && it.name == wanted } ?: voices.maxByOrNull { score(it) }
            if (chosen != null) tts.voice = chosen
        }
    }

    // ---------------- reprodução ----------------

    private suspend fun play(file: File) {
        val done = CompletableDeferred<Unit>()
        val mp = MediaPlayer()
        var eq: Equalizer? = null
        var boost: BassBoost? = null
        try {
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            mp.setDataSource(file.absolutePath)
            // Voz da nuvem: tom e velocidade aplicados aqui (a voz do aparelho já recebeu os dois no próprio TTS).
            if (file.name.startsWith("c-")) {
                runCatching { mp.playbackParams = PlaybackParams().setSpeed(settings.voiceRate).setPitch(settings.voicePitch) }
            }
            mp.prepare()
            val session = mp.audioSessionId
            eq = runCatching { buildEqualizer(session) }.getOrNull()
            boost = runCatching { buildBoost(session) }.getOrNull()
            val g = settings.voiceGain
            mp.setVolume(g, g)
            mp.setOnCompletionListener { done.complete(Unit) }
            mp.setOnErrorListener { _, what, extra ->
                Log.w(TAG, "MediaPlayer erro $what/$extra")
                done.complete(Unit)
                true
            }
            player = mp
            mp.start()
            done.await()
        } finally {
            player = null
            runCatching { eq?.release() }
            runCatching { boost?.release() }
            runCatching { mp.release() }
        }
    }

    /** Graves nas bandas baixas, agudos nas altas; o meio fica neutro. */
    private fun buildEqualizer(session: Int): Equalizer {
        val eq = Equalizer(0, session)
        val min = eq.bandLevelRange[0].toInt()
        val max = eq.bandLevelRange[1].toInt()
        val n = eq.numberOfBands.toInt()
        for (b in 0 until n) {
            val pos = if (n == 1) 0.5f else b.toFloat() / (n - 1)
            val bassW = (1f - pos * 2f).coerceAtLeast(0f)
            val trebW = (pos * 2f - 1f).coerceAtLeast(0f)
            val g = settings.voiceBass * bassW + settings.voiceTreble * trebW
            val level = (if (g >= 0f) g * max else g * -min).toInt().coerceIn(min, max)
            eq.setBandLevel(b.toShort(), level.toShort())
        }
        eq.enabled = true
        return eq
    }

    private fun buildBoost(session: Int): BassBoost? {
        val strength = settings.voiceBoost
        if (strength <= 0f) return null
        val bb = BassBoost(0, session)
        if (!bb.strengthSupported) { bb.release(); return null }
        bb.setStrength((strength * 1000).toInt().coerceIn(0, 1000).toShort())
        bb.enabled = true
        return bb
    }

    // ---------------- utilidades ----------------

    private fun wav(pcm: ByteArray, sampleRate: Int): ByteArray {
        val out = ByteArrayOutputStream(pcm.size + 44)
        fun le32(v: Int) { out.write(v and 0xFF); out.write((v shr 8) and 0xFF); out.write((v shr 16) and 0xFF); out.write((v shr 24) and 0xFF) }
        fun le16(v: Int) { out.write(v and 0xFF); out.write((v shr 8) and 0xFF) }
        out.write("RIFF".toByteArray()); le32(36 + pcm.size)
        out.write("WAVE".toByteArray())
        out.write("fmt ".toByteArray()); le32(16); le16(1); le16(1); le32(sampleRate); le32(sampleRate * 2); le16(2); le16(16)
        out.write("data".toByteArray()); le32(pcm.size)
        out.write(pcm)
        return out.toByteArray()
    }

    private fun clean(text: String): String = text
        .replace(Regex("\\[\\[img:[^\\]]*\\]\\]"), " ")
        .replace(Regex("```[\\s\\S]*?```"), " ")
        .replace(Regex("https?://\\S+"), " ")
        .replace(Regex("[*_#>`~]+"), "")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun chunk(text: String, max: Int): List<String> {
        val limit = max.coerceAtLeast(200)
        val sentences = text.split(Regex("(?<=[.!?…])\\s+"))
        val out = mutableListOf<String>()
        val cur = StringBuilder()
        fun flush() { if (cur.isNotBlank()) out += cur.toString().trim(); cur.clear() }
        for (sentence in sentences) {
            if (sentence.length > limit) {
                flush()
                sentence.chunked(limit).forEach { out += it }
            } else {
                if (cur.length + sentence.length + 1 > limit) flush()
                if (cur.isNotEmpty()) cur.append(' ')
                cur.append(sentence)
            }
        }
        flush()
        return out
    }

    /** Heurística: vozes pt-BR do Google com id "afs" são femininas; nomes com termos femininos também pontuam. */
    private fun score(voice: Voice): Int {
        val name = voice.name.lowercase(Locale.ROOT)
        var s = 0
        if (voice.locale.country == "BR") s += 50
        if (!voice.isNetworkConnectionRequired) s += 20
        if (name.contains("afs")) s += 80
        if (listOf("female", "femin", "mulher", "maria", "francisca", "camila", "helena", "ana", "vitoria", "thalita").any(name::contains)) s += 60
        if (name.contains("natural") || name.contains("neural")) s += 10
        return s
    }

    companion object {
        private const val TAG = "AuroraVoice"
        private const val DEVICE_CHUNK = 400
        private const val CLOUD_CHUNK = 700

        /** Vozes FEMININAS do Gemini TTS (nome técnico, característica). */
        val CLOUD_VOICES = listOf(
            "Kore" to "firme e clara",
            "Aoede" to "leve e arejada",
            "Leda" to "jovem",
            "Zephyr" to "brilhante",
            "Callirrhoe" to "descontraída",
            "Despina" to "suave",
            "Sulafat" to "calorosa",
            "Vindemiatrix" to "gentil"
        )
    }
}
