package com.aurora.core.agent

import com.aurora.core.database.MemoryDao
import com.aurora.core.database.MemoryEntity
import com.aurora.core.perf.PerfTrace
import java.text.Normalizer

/**
 * Recuperação de memórias por sobreposição léxica (sem embeddings, sem rede).
 *
 *  - memórias de tipo "perfil" são sempre elegíveis (são poucas e definem quem é o usuário);
 *  - as demais entram só se compartilham palavras com a mensagem atual;
 *  - respeita limites de itens e de caracteres para caber no contexto do modelo.
 *
 * A busca semântica nunca bloqueia: se o modelo de embeddings ainda não está aquecido, usa o lexical agora.
 *
 * LIMITAÇÃO CONHECIDA: é correspondência por palavras/prefixos. Quando BGE-M3 está instalado, a busca semântica local é priorizada; caso contrário, permanece o fallback lexical.
 */
class MemoryRetriever(private val dao: MemoryDao, private val semantic: SemanticMemory? = null) {

    suspend fun relevant(query: String, maxItems: Int = 8, maxChars: Int = 1200, trace: PerfTrace = PerfTrace.NONE): List<MemoryEntity> {
        val allMemories = trace.measureSuspend("memory_db") { dao.all() }
        trace.note("memory_total", allMemories.size)
        semantic?.let { engine ->
            val hit = trace.measureSuspend("memory_semantic") {
                runCatching { engine.relevant(query, allMemories, maxItems, maxChars, trace) }.getOrNull()
            }?.takeIf { it.isNotEmpty() }
            if (hit != null) { trace.note("memory_path", "semantic items=${hit.size}"); return hit }
        }
        return trace.measure("memory_lexical") { lexical(query, allMemories, maxItems, maxChars) }
            .also { trace.note("memory_path", "lexical items=${it.size}") }
    }

    private fun lexical(query: String, allMemories: List<MemoryEntity>, maxItems: Int, maxChars: Int): List<MemoryEntity> {
        val queryTokens = tokens(query)
        val scored = allMemories.mapNotNull { memory ->
            val isProfile = memory.kind.equals("perfil", ignoreCase = true)
            val isManual = memory.kind.equals("manual", ignoreCase = true)
            val overlap = overlap(queryTokens, tokens(memory.content))
            if (!isProfile && !isManual && overlap == 0) null
            else Triple(memory, overlap, if (isProfile || isManual) 1 else 0)
        }.sortedWith(
            compareByDescending<Triple<MemoryEntity, Int, Int>> { it.second }
                .thenByDescending { it.third }
                .thenByDescending { it.first.updatedAt }
        )

        val result = mutableListOf<MemoryEntity>()
        var used = 0
        for ((memory, _, _) in scored) {
            if (result.size >= maxItems) break
            if (used + memory.content.length > maxChars) continue
            result += memory
            used += memory.content.length
        }
        return result
    }

    private fun overlap(query: Set<String>, content: Set<String>): Int =
        query.count { q ->
            val stem = if (q.length > 5) q.take(5) else q
            content.any { it == q || (stem.length >= 5 && it.startsWith(stem)) }
        }

    private fun tokens(text: String): Set<String> =
        normalize(text)
            .split(Regex("[^a-z0-9]+"))
            .filter { it.length >= 3 && it !in STOPWORDS }
            .toSet()

    private fun normalize(text: String): String =
        Normalizer.normalize(text.lowercase(), Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")

    private companion object {
        val STOPWORDS = setOf(
            "que", "para", "com", "uma", "uns", "umas", "por", "mais", "como", "mas", "dos", "das",
            "nos", "nas", "seu", "sua", "seus", "suas", "ele", "ela", "eles", "elas", "voce", "voces",
            "isso", "esse", "essa", "este", "esta", "aqui", "tem", "ter", "foi", "sao", "ser", "esta",
            "sobre", "quando", "onde", "qual", "quais", "pode", "posso", "preciso", "quero", "aurora",
            "ola", "oi", "meu", "minha", "meus", "minhas", "mim", "algo", "tudo", "bem"
        )
    }
}
