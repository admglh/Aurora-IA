package com.aurora.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.content.pm.ServiceInfo
import android.graphics.BitmapFactory
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import android.widget.ImageView
import com.aurora.MainActivity
import com.aurora.R

class AuroraBubbleService : Service() {

    companion object {
        private const val CHANNEL_ID = "aurora_bubble_service"
        private const val NOTIFICATION_ID = 4202
    }

    private var windowManager: WindowManager? = null
    private var bubble: ImageView? = null

    override fun onCreate() {
        super.onCreate()

        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        createNotificationChannel()
        val openApp = PendingIntent.getActivity(
            this,
            NOTIFICATION_ID,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_aurora)
            .setLargeIcon(BitmapFactory.decodeResource(resources, R.drawable.aurora_notification_avatar))
            .setContentTitle("Aurora está disponível")
            .setContentText("A bolha flutuante está ativa. Toque para abrir a Aurora.")
            .setContentIntent(openApp)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val image = ImageView(this).apply {
            setImageResource(R.drawable.aurora_notification_avatar)
            setPadding(10, 10, 10, 10)
            setOnClickListener {
                val intent = Intent(this@AuroraBubbleService, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_SINGLE_TOP or
                            Intent.FLAG_ACTIVITY_CLEAR_TOP
                }
                startActivity(intent)
            }
        }

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            64.dp,
            64.dp,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 18.dp
            y = 180.dp
        }

        image.setOnTouchListener(object : View.OnTouchListener {
            var downX = 0f
            var downY = 0f
            var startX = 0
            var startY = 0

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = event.rawX
                        downY = event.rawY
                        startX = params.x
                        startY = params.y
                        return true
                    }

                    MotionEvent.ACTION_MOVE -> {
                        params.x = startX - (event.rawX - downX).toInt()
                        params.y = startY + (event.rawY - downY).toInt()
                        windowManager?.updateViewLayout(image, params)
                        return true
                    }

                    MotionEvent.ACTION_UP -> {
                        val moved = kotlin.math.abs(event.rawX - downX) +
                                kotlin.math.abs(event.rawY - downY)

                        if (moved < 20) {
                            image.performClick()
                        }
                        return true
                    }
                }
                return false
            }
        })

        windowManager?.addView(image, params)
        bubble = image
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    "Aurora · bolha flutuante",
                    NotificationManager.IMPORTANCE_LOW
                ).apply { description = "Mantém a bolha da Aurora disponível enquanto estiver ativada." }
            )
        }
    }

    override fun onDestroy() {
        bubble?.let { view ->
            runCatching { windowManager?.removeView(view) }
        }
        bubble = null
        windowManager = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private val Int.dp: Int
        get() = (this * resources.displayMetrics.density).toInt()
}
