# Aurora · arquitetura corrigida

## O que mudou
- Descoberta automática de GGUF em `Download/Aurora` via MediaStore + fallback de caminho público.
- Provisionamento automático do melhor cérebro local compatível quando o arquivo interno não existe.
- Nuvem continua prioritária quando configurada.
- Se a nuvem falhar durante uma geração, a Aurora tenta um cérebro local válido automaticamente.
- Configuração de endpoint/modelo/token passou a existir na tela `Configurações > CÉREBRO`.
- Removido backup `.pre_import_fix` do código-fonte.

## Limite importante
O APK não pode inventar uma API de nuvem nem possuir uma chave privada do usuário. Para nuvem real é necessário configurar um endpoint compatível (por exemplo, o Worker incluído em `servidor-nuvem/`) e seu token. Depois disso a Aurora usa a nuvem primeiro e o local como fallback.

## Resultado esperado
Instalação limpa + GGUF em `Download/Aurora` -> Aurora encontra o GGUF, importa para armazenamento privado, seleciona e usa.
Nuvem configurada -> Aurora tenta nuvem primeiro; se o servidor falhar, tenta o local automaticamente.
