# Aurora Nova FINAL • Controle real

## Unificação realizada
- O pacote Termux básico anterior foi incorporado ao projeto principal em `termux/`.
- Não há ZIP dentro de ZIP.
- O backend usa `llama-cli --single-turn --simple-io`.
- O frontend local usa `/api/chat`.
- O instalador único é `tools/INSTALAR_TUDO_AURORA.sh`.

## Já presente na fonte
- Android/Compose
- Room e migrações
- agente/persona
- memória semântica
- GGUF local
- gerenciador/catálogo de modelos
- busca online de GGUF no Hugging Face, até 500 resultados por pesquisa
- download/resume de modelos
- extensões e manifesto
- Web/GitHub
- droid-mcp 0.11.0 com módulos e root/Shizuku opt-in
- MCP HTTP autenticado
- Whisper
- sherpa-onnx preparado
- MediaPipe Vision preparado
- identidade visual, animações e temas
- scripts de build, migração, diagnóstico e instalação
- runtime Termux local

## Recursos já baixados no aparelho
São consumidos de `/storage/emulated/0/Download/Aurora` e não são duplicados no ZIP:
- Qwen3
- Qwen2.5-VL + mmproj
- BGE-M3
- BGE reranker
- Whisper
- Silero VAD
- Kokoro
- OCR

## Ainda depende do aparelho
Estes itens precisam ser executados no Termux/Android para serem considerados validados:
- build final
- instalação do APK
- permissões Android
- carregamento real dos modelos
- execução de visão/voz
- execução real das ferramentas droid-mcp disponíveis
- Shizuku/root, se configurados
- execução de servidores MCP externos

Isso é deliberado: presença de código ou dependência não é tratada como teste real.
