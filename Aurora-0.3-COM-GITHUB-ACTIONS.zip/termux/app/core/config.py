from pathlib import Path
import json, os
ROOT = Path(__file__).resolve().parents[2]
CFG = ROOT / "config" / "aurora.json"
def load():
    return json.loads(CFG.read_text(encoding="utf-8"))
def asset_root():
    return Path(os.environ.get("AURORA_ASSET_ROOT", load()["asset_root"]))
def asset(rel):
    return asset_root() / rel
