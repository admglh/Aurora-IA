package com.aurora.core.theme

import android.content.Context
import java.time.LocalDate
import java.time.ZoneId

/** Persiste apenas o override temporário informado pelo usuário. */
class AuroraThemeStore(context: Context) {
    private val prefs = context.getSharedPreferences("aurora_theme", Context.MODE_PRIVATE)

    fun selection(now: LocalDate = LocalDate.now()): AuroraThemeSelection {
        val key = prefs.getString(KEY_OVERRIDE, null)
        val expires = prefs.getLong(KEY_EXPIRES, 0L)
        if (!key.isNullOrBlank() && expires > System.currentTimeMillis()) {
            AuroraTheme.entries.firstOrNull { it.key == key }?.let {
                return AuroraThemeSelection(it, "Escolha temporária do usuário", true)
            }
        } else if (!key.isNullOrBlank()) {
            clear()
        }
        return AuroraThemeResolver.automatic(now)
    }

    fun applyIntent(text: String): AuroraTheme? {
        val theme = AuroraThemeResolver.intent(text) ?: return null
        if (theme == AuroraTheme.BASE && text.lowercase().contains("normal")) {
            clear()
            return theme
        }
        val endOfDay = LocalDate.now().plusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
        prefs.edit().putString(KEY_OVERRIDE, theme.key).putLong(KEY_EXPIRES, endOfDay).apply()
        return theme
    }

    fun set(theme: AuroraTheme) {
        val endOfDay = LocalDate.now().plusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
        prefs.edit().putString(KEY_OVERRIDE, theme.key).putLong(KEY_EXPIRES, endOfDay).apply()
    }

    fun clear() { prefs.edit().remove(KEY_OVERRIDE).remove(KEY_EXPIRES).apply() }

    companion object {
        private const val KEY_OVERRIDE = "override"
        private const val KEY_EXPIRES = "override_expires"
    }
}
