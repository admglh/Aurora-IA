# Aurora na nuvem (grátis, feito pelo celular)

O app fica leve e o "cérebro" roda no Gemini. A chave do Gemini fica num mini-servidor seu, não dentro do APK.

## 1. Chave do Gemini
1. Abra aistudio.google.com e entre com sua conta Google.
2. Toque em **Get API key** e crie uma chave. Copie e guarde.

## 2. Criar o servidor (Cloudflare Workers, plano grátis)
1. Crie conta em dash.cloudflare.com.
2. Vá em **Workers & Pages** > **Create** > comece com **Hello World** > dê o nome `aurora` > **Deploy**.
3. Toque em **Edit code**, apague tudo, cole o conteúdo de `worker.js` e toque em **Deploy**.
4. Em **Settings > Variables and Secrets**, adicione:
   - `GEMINI_API_KEY` (tipo Secret): a chave do passo 1.
   - `APP_TOKEN` (tipo Secret): uma senha longa que você inventa (ex.: 30 letras e números).
   - `MODEL` (tipo Texto, opcional): nome do modelo. Confira os nomes atuais em ai.google.dev; `gemini-2.5-flash` é um bom ponto de partida.
5. Anote o endereço, parecido com `https://aurora.SEUNOME.workers.dev`.

Teste no navegador: abrir o endereço deve mostrar `{"ok":true,...}`.

## 3. Configurar no app (Configurações > modelo remoto)
- **Endpoint:** `https://aurora.SEUNOME.workers.dev/v1`
- **Modelo:** o mesmo nome do `MODEL` (se você definiu `MODEL` no servidor, ele manda).
- **Chave:** o `APP_TOKEN`.

Com isso configurado, a versão corrigida do app usa a nuvem e nem carrega o modelo local.

## Cuidados
- **Privacidade:** o app envia suas mensagens e memórias no prompt. No plano grátis da API do Google, os dados podem ser usados para melhorar produtos; confira os termos atuais antes de usar. Plano pago costuma ter regras diferentes.
- **Limites:** o plano grátis tem limite de pedidos por minuto e por dia. Se estourar, o app mostra o erro HTTP 429.
- Se alguém descobrir o `APP_TOKEN`, troque-o no painel e no app. A chave do Gemini continua segura.

## Atualização (function calling)
O `worker.js` desta versão repassa também as ferramentas (`tools`) para o Gemini, o que permite pedidos como
"me acorda amanhã às 6" ou "o que tenho na agenda?". Se você já criou o servidor antes, abra **Edit code**, cole o
novo `worker.js` e toque em **Deploy** (as variáveis continuam as mesmas).

Segurança: leituras e ações de baixo risco (alarme, timer, lanterna, volume…) o app executa direto; enviar mensagem,
apagar evento, bloquear tela e similares pedem seu "sim"; qualquer outra ferramenta (shell, instalar/desinstalar, cliques
na tela) é bloqueada no app, mesmo que o modelo peça.
