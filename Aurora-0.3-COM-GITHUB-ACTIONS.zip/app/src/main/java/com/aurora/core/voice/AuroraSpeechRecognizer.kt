package com.aurora.core.voice

import android.app.Activity
import android.content.Intent
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.cancel

/** Voz híbrida: Whisper local quando um modelo offline foi instalado; Android SpeechRecognizer como fallback. */
class AuroraSpeechRecognizer(
    private val activity: Activity,
    private val offline: OfflineWhisper?,
    private val onText: (String) -> Unit,
    private val onListeningChanged: (Boolean) -> Unit,
    private val onError: (String) -> Unit,
    /** Texto FINAL (sem parciais). Usado pelo modo conversa para enviar sozinho. */
    private val onFinal: ((String) -> Unit)? = null,
    /** Chamado quando a escuta terminou sem texto (silêncio/erro). */
    private val onMiss: (() -> Unit)? = null
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var recognizer: SpeechRecognizer? = null
    private var offlineRecording = false
    private var transcriptionJob: Job? = null

    fun start() {
        val localOffline = offline
        if (localOffline?.isAvailable() == true) {
            runCatching {
                localOffline.start()
                offlineRecording = true
                onListeningChanged(true)
            }.onFailure { onError(it.message ?: "Não foi possível iniciar o microfone.") }
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(activity)) {
            onError("Nenhum reconhecimento de voz está disponível neste aparelho.")
            return
        }
        stopAndroidRecognizer()
        recognizer = SpeechRecognizer.createSpeechRecognizer(activity).also { sr ->
            sr.setRecognitionListener(listener)
            sr.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "pt-BR")
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            })
        }
        onListeningChanged(true)
    }

    fun stop() {
        if (offlineRecording) {
            offlineRecording = false
            onListeningChanged(false)
            transcriptionJob?.cancel()
            transcriptionJob = scope.launch(Dispatchers.IO) {
                try {
                    val text = offline?.stopAndTranscribe().orEmpty()
                    if (text.isNotBlank()) withContext(Dispatchers.Main.immediate) { onText(text); onFinal?.invoke(text) }
                    else withContext(Dispatchers.Main.immediate) { onMiss?.invoke() }
                } catch (t: Throwable) {
                    withContext(Dispatchers.Main.immediate) { onError(t.message ?: "Falha no reconhecimento offline.") }
                }
            }
            return
        }
        stopAndroidRecognizer()
        onListeningChanged(false)
    }

    fun shutdown() {
        runCatching { offline?.cancel() }
        stopAndroidRecognizer()
        transcriptionJob?.cancel()
        scope.cancel()
    }

    private fun stopAndroidRecognizer() {
        recognizer?.cancel()
        recognizer?.destroy()
        recognizer = null
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: android.os.Bundle?) = Unit
        override fun onBeginningOfSpeech() = Unit
        override fun onRmsChanged(rmsdB: Float) = Unit
        override fun onBufferReceived(buffer: ByteArray?) = Unit
        override fun onEndOfSpeech() { onListeningChanged(false) }
        override fun onEvent(eventType: Int, params: android.os.Bundle?) = Unit

        override fun onPartialResults(results: android.os.Bundle?) {
            results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let(onText)
        }

        override fun onResults(results: android.os.Bundle?) {
            onListeningChanged(false)
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!text.isNullOrBlank()) { onText(text); onFinal?.invoke(text) } else onMiss?.invoke()
        }

        override fun onError(error: Int) {
            onListeningChanged(false)
            val quiet = error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
            if (onMiss != null && (quiet || error == SpeechRecognizer.ERROR_CLIENT)) { onMiss.invoke(); return }
            if (error != SpeechRecognizer.ERROR_CLIENT && error != SpeechRecognizer.ERROR_RECOGNIZER_BUSY) onError(errorMessage(error))
        }
    }

    private fun errorMessage(error: Int): String = when (error) {
        SpeechRecognizer.ERROR_AUDIO -> "Não foi possível acessar o microfone."
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "A engine Android não conseguiu concluir o reconhecimento. Instale um modelo Whisper para reconhecimento totalmente local."
        SpeechRecognizer.ERROR_NO_MATCH -> "Não consegui entender a fala."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "O reconhecimento de voz já está ocupado."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Permissão do microfone não concedida."
        else -> "Falha no reconhecimento de voz (código $error)."
    }
}
