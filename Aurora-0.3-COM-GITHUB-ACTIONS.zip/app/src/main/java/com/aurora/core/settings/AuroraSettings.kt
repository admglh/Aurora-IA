package com.aurora.core.settings

import android.content.Context

/**
 * Configurações NÃO secretas (SharedPreferences privado; o app tem allowBackup=false).
 * Segredos (chaves de API) ficam em [SecretStore], nunca aqui.
 */
class AuroraSettings(context: Context) {
    private val prefs = context.getSharedPreferences("aurora_settings", Context.MODE_PRIVATE)

    var remoteEndpoint: String
        get() = prefs.getString(K_ENDPOINT, "") ?: ""
        set(v) { prefs.edit().putString(K_ENDPOINT, v.trim()).apply() }

    var remoteModel: String
        get() = prefs.getString(K_MODEL, "") ?: ""
        set(v) { prefs.edit().putString(K_MODEL, v.trim()).apply() }

    /** Nome do arquivo Whisper dentro de filesDir/models/. */
    var speechModelFileName: String
        get() = prefs.getString(K_SPEECH_MODEL, "") ?: ""
        set(v) { prefs.edit().putString(K_SPEECH_MODEL, v.trim()).apply() }

    /** GGUF usado somente para embeddings/memória semântica. */
    var embeddingModelFileName: String
        get() = prefs.getString(K_EMBEDDING_MODEL, "") ?: ""
        set(v) { prefs.edit().putString(K_EMBEDDING_MODEL, v.trim()).apply() }

    var localModelFileName: String
        get() = prefs.getString(K_LOCAL_FILE, DEFAULT_LOCAL_MODEL_FILE) ?: DEFAULT_LOCAL_MODEL_FILE
        set(v) { prefs.edit().putString(K_LOCAL_FILE, v.trim()).apply() }

    /** Última conversa aberta (-1 = nenhuma). */
    var lastConversationId: Long
        get() = prefs.getLong(K_LAST_CONV, -1L)
        set(v) { prefs.edit().putLong(K_LAST_CONV, v).apply() }

    /** Exibe a presença animada na tela inicial. Desligada por padrão para uma interface mais discreta. */
    var animationEnabled: Boolean
        get() = prefs.getBoolean(K_ANIMATION_ENABLED, true)
        set(v) { prefs.edit().putBoolean(K_ANIMATION_ENABLED, v).apply() }

    var voiceEnabled: Boolean
        get() = prefs.getBoolean(K_VOICE_ENABLED, true)
        set(v) { prefs.edit().putBoolean(K_VOICE_ENABLED, v).apply() }

    /** Exibe a bolha flutuante da Aurora sobre outros aplicativos. */
    var bubbleEnabled: Boolean
        get() = prefs.getBoolean(K_BUBBLE_ENABLED, false)
        set(v) { prefs.edit().putBoolean(K_BUBBLE_ENABLED, v).apply() }

    /** Tom da voz (1.0 = normal). Antes o padrão era 0.72 (voz grave, parecia masculina); agora o padrão é 1.0. */
    var voicePitch: Float
        get() = prefs.getFloat(K_VOICE_PITCH2, 1.0f)
        set(v) { prefs.edit().putFloat(K_VOICE_PITCH2, v.coerceIn(0.5f, 1.8f)).apply() }

    var voiceRate: Float
        get() = prefs.getFloat(K_VOICE_RATE2, 1.0f)
        set(v) { prefs.edit().putFloat(K_VOICE_RATE2, v.coerceIn(0.5f, 1.8f)).apply() }

    /** Graves: -1.0 (cortar) .. +1.0 (reforçar). Aplicado por equalizador do Android. */
    var voiceBass: Float
        get() = prefs.getFloat(K_VOICE_BASS, 0f)
        set(v) { prefs.edit().putFloat(K_VOICE_BASS, v.coerceIn(-1f, 1f)).apply() }

    /** Agudos: -1.0 .. +1.0. */
    var voiceTreble: Float
        get() = prefs.getFloat(K_VOICE_TREBLE, 0.15f)
        set(v) { prefs.edit().putFloat(K_VOICE_TREBLE, v.coerceIn(-1f, 1f)).apply() }

    /** Reforço extra de graves (BassBoost), 0..1. */
    var voiceBoost: Float
        get() = prefs.getFloat(K_VOICE_BOOST, 0f)
        set(v) { prefs.edit().putFloat(K_VOICE_BOOST, v.coerceIn(0f, 1f)).apply() }

    /** Volume da voz da Aurora (0..1) em relação ao volume de mídia. */
    var voiceGain: Float
        get() = prefs.getFloat(K_VOICE_GAIN, 1f)
        set(v) { prefs.edit().putFloat(K_VOICE_GAIN, v.coerceIn(0f, 1f)).apply() }

    /** "cloud" = voz natural feminina do Gemini (via seu Worker); "device" = voz instalada no aparelho. */
    var voiceEngine: String
        get() = prefs.getString(K_VOICE_ENGINE, "cloud") ?: "cloud"
        set(v) { prefs.edit().putString(K_VOICE_ENGINE, if (v == "device") "device" else "cloud").apply() }

    /** Nome da voz do aparelho escolhida ("" = automática, prefere feminina pt-BR). */
    var voiceDeviceName: String
        get() = prefs.getString(K_VOICE_DEVICE, "") ?: ""
        set(v) { prefs.edit().putString(K_VOICE_DEVICE, v).apply() }

    /** Voz feminina do Gemini TTS. */
    var voiceCloudName: String
        get() = prefs.getString(K_VOICE_CLOUD, "Kore") ?: "Kore"
        set(v) { prefs.edit().putString(K_VOICE_CLOUD, v).apply() }

    /** Pastas liberadas (URIs de árvore do Storage Access Framework) onde a Aurora pode procurar arquivos. */
    var fileFolders: Set<String>
        get() = prefs.getStringSet(K_FILE_FOLDERS, emptySet())?.toSet() ?: emptySet()
        set(v) { prefs.edit().putStringSet(K_FILE_FOLDERS, v).apply() }

    /** Resumo matinal: ligado, hora, minuto, cidade (para o clima) e assuntos de notícia. */
    var briefEnabled: Boolean
        get() = prefs.getBoolean(K_BRIEF_ON, false)
        set(v) { prefs.edit().putBoolean(K_BRIEF_ON, v).apply() }
    var briefHour: Int
        get() = prefs.getInt(K_BRIEF_H, 7)
        set(v) { prefs.edit().putInt(K_BRIEF_H, v.coerceIn(0, 23)).apply() }
    var briefMinute: Int
        get() = prefs.getInt(K_BRIEF_M, 30)
        set(v) { prefs.edit().putInt(K_BRIEF_M, v.coerceIn(0, 59)).apply() }
    var briefCity: String
        get() = prefs.getString(K_BRIEF_CITY, "") ?: ""
        set(v) { prefs.edit().putString(K_BRIEF_CITY, v.trim().take(60)).apply() }
    var briefTopics: String
        get() = prefs.getString(K_BRIEF_TOPICS, "") ?: ""
        set(v) { prefs.edit().putString(K_BRIEF_TOPICS, v.trim().take(120)).apply() }

    /** Lembretes pendentes (JSON: [{id,at,text}]). Persistidos para sobreviver a reinício do aparelho. */
    var remindersJson: String
        get() = prefs.getString(K_REMINDERS, "[]") ?: "[]"
        set(v) { prefs.edit().putString(K_REMINDERS, v).apply() }

    /** Fala cada resposta automaticamente (modo Jarvis). */
    var autoSpeak: Boolean
        get() = prefs.getBoolean(K_AUTO_SPEAK, true)
        set(v) { prefs.edit().putBoolean(K_AUTO_SPEAK, v).apply() }

    /** true quando a importação da Aurora 2.0 terminou SEM erro fatal. */
    var legacyImportDone: Boolean
        get() = prefs.getBoolean(K_LEGACY_DONE, false)
        set(v) { prefs.edit().putBoolean(K_LEGACY_DONE, v).apply() }

    /** Relatório da última tentativa de importação (para a futura tela de diagnóstico). */
    var lastImportReport: String
        get() = prefs.getString(K_LEGACY_REPORT, "") ?: ""
        set(v) { prefs.edit().putString(K_LEGACY_REPORT, v).apply() }

    companion object {
        const val DEFAULT_LOCAL_MODEL_FILE = "Qwen3-1.7B-Q8_0.gguf"
        private const val K_ENDPOINT = "remote_endpoint"
        private const val K_ANIMATION_ENABLED = "animation_enabled"
        private const val K_VOICE_ENABLED = "voice_enabled"
        private const val K_BUBBLE_ENABLED = "bubble_enabled"
        private const val K_VOICE_PITCH2 = "voice_pitch_v2"
        private const val K_VOICE_RATE2 = "voice_rate_v2"
        private const val K_VOICE_BASS = "voice_bass"
        private const val K_VOICE_TREBLE = "voice_treble"
        private const val K_VOICE_BOOST = "voice_boost"
        private const val K_VOICE_GAIN = "voice_gain"
        private const val K_VOICE_ENGINE = "voice_engine"
        private const val K_VOICE_DEVICE = "voice_device_name"
        private const val K_VOICE_CLOUD = "voice_cloud_name"
        private const val K_AUTO_SPEAK = "auto_speak"
        private const val K_FILE_FOLDERS = "file_folders"
        private const val K_BRIEF_ON = "brief_on"
        private const val K_BRIEF_H = "brief_h"
        private const val K_BRIEF_M = "brief_m"
        private const val K_BRIEF_CITY = "brief_city"
        private const val K_BRIEF_TOPICS = "brief_topics"
        private const val K_REMINDERS = "reminders_json"
        private const val K_MODEL = "remote_model"
        private const val K_LOCAL_FILE = "local_model_file"
        private const val K_SPEECH_MODEL = "speech_model_file"
        private const val K_EMBEDDING_MODEL = "embedding_model_file"
        private const val K_LAST_CONV = "last_conversation_id"
        private const val K_LEGACY_DONE = "legacy_import_done"
        private const val K_LEGACY_REPORT = "legacy_import_report"
    }
}
