#!/data/data/com.termux/files/usr/bin/bash
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ASSETS="${AURORA_ASSET_ROOT:-/storage/emulated/0/Download/Aurora}"
ok(){ echo "[OK] $1"; }
bad(){ echo "[ATENÇÃO] $1"; }
[ -d "$ROOT/app" ] && ok 'Projeto Android' || bad 'Projeto Android'
[ -f "$ROOT/app/src/main/assets/models/catalog.json" ] && ok 'Catálogo local de modelos' || bad 'Catálogo local'
[ -f "$ROOT/app/src/main/assets/extensions/catalog.json" ] && ok 'Catálogo de extensões' || bad 'Catálogo de extensões'
for f in Qwen3-1.7B-Q8_0.gguf Qwen2.5-VL-3B-Instruct-Q4_K_M.gguf mmproj-Qwen2.5-VL-3B-Instruct-Q8_0.gguf bge-m3-Q4_K_M.gguf bge-reranker-v2-m3-q4_k.gguf; do find "$ASSETS" -type f -name "$f" -print -quit 2>/dev/null | grep -q . && ok "$f" || bad "$f não encontrado"; done
find "$ASSETS" -type f -name 'ggml-base-q8_0.bin' -print -quit 2>/dev/null | grep -q . && ok 'Whisper base' || bad 'Whisper base'
find "$ASSETS" -type f -name 'silero_vad.onnx' -print -quit 2>/dev/null | grep -q . && ok 'Silero VAD' || bad 'Silero VAD'
find "$ASSETS" -type f -name 'model.onnx' -path '*Kokoro*' -print -quit 2>/dev/null | grep -q . && ok 'Kokoro model.onnx' || bad 'Kokoro model.onnx'
find "$ASSETS" -type f -name 'voices.bin' -path '*Kokoro*' -print -quit 2>/dev/null | grep -q . && ok 'Kokoro voices.bin' || bad 'Kokoro voices.bin'
find "$ASSETS" -type f -name 'PP-OCRv5_server_rec_infer.onnx' -print -quit 2>/dev/null | grep -q . && ok 'OCR' || bad 'OCR'
echo
printf 'Projeto: %s\nRecursos: %s\n' "$ROOT" "$ASSETS"
