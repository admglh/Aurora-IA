package com.aurora.core.files

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.util.zip.ZipInputStream

/** Conteúdo lido de um arquivo: texto (se houver) e/ou imagens JPEG em base64 (fotos, páginas de PDF). */
data class DocContent(
    val name: String,
    val kind: String,
    val text: String = "",
    val images: List<String> = emptyList(),
    val note: String = ""
)

/**
 * Lê arquivos para a Aurora:
 *  - imagem  -> reduz e envia como imagem (o Gemini enxerga)
 *  - PDF     -> renderiza as primeiras páginas como imagens (o Gemini lê, inclusive PDFs escaneados)
 *  - DOCX    -> extrai o texto do document.xml
 *  - texto/código/CSV/JSON/MD... -> texto direto
 */
object DocReader {
    private const val MAX_TEXT = 60_000
    private const val MAX_PDF_PAGES = 8
    private const val MAX_IMAGE_SIDE = 1280

    private val TEXT_EXT = setOf(
        "txt", "md", "markdown", "csv", "tsv", "json", "xml", "html", "htm", "log", "ini", "yaml", "yml", "toml",
        "kt", "java", "py", "js", "ts", "c", "cpp", "h", "cs", "go", "rs", "sh", "sql", "css", "srt", "vtt", "rtf", "tex"
    )

    fun displayName(context: Context, uri: Uri): String {
        runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) { val n = c.getString(0); if (!n.isNullOrBlank()) return n }
            }
        }
        return uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':') ?: "arquivo"
    }

    suspend fun read(context: Context, uri: Uri, nameHint: String? = null): DocContent = withContext(Dispatchers.IO) {
        val name = nameHint ?: displayName(context, uri)
        val mime = (context.contentResolver.getType(uri) ?: "").lowercase()
        val ext = name.substringAfterLast('.', "").lowercase()
        try {
            when {
                mime.startsWith("image/") || ext in setOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "heic") -> readImage(context, uri, name)
                mime == "application/pdf" || ext == "pdf" -> readPdf(context, uri, name)
                ext == "docx" || mime.contains("wordprocessingml") -> readDocx(context, uri, name)
                mime.startsWith("text/") || ext in TEXT_EXT || mime == "application/json" || mime == "application/xml" -> readText(context, uri, name)
                else -> DocContent(name, "desconhecido", note = "Não sei ler este tipo de arquivo ($mime ${ext.ifBlank { "sem extensão" }}). Aceito: fotos, PDF, DOCX e texto.")
            }
        } catch (e: Exception) {
            DocContent(name, "erro", note = "Falha ao ler: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun readText(context: Context, uri: Uri, name: String): DocContent {
        val raw = context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
            ?: return DocContent(name, "erro", note = "Não foi possível abrir o arquivo.")
        val cut = raw.length > MAX_TEXT
        return DocContent(name, "texto", text = raw.take(MAX_TEXT), note = if (cut) "Arquivo longo: li só os primeiros $MAX_TEXT caracteres." else "")
    }

    private fun readDocx(context: Context, uri: Uri, name: String): DocContent {
        val input = context.contentResolver.openInputStream(uri) ?: return DocContent(name, "erro", note = "Não foi possível abrir o arquivo.")
        input.use { raw ->
            ZipInputStream(raw).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    if (entry.name == "word/document.xml") {
                        val xml = zip.readBytes().toString(Charsets.UTF_8)
                        val text = xml
                            .replace(Regex("</w:p>"), "\n")
                            .replace(Regex("<w:tab/>"), "\t")
                            .replace(Regex("<[^>]+>"), "")
                            .replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'")
                            .replace(Regex("\n{3,}"), "\n\n")
                            .trim()
                        val cut = text.length > MAX_TEXT
                        return DocContent(name, "documento", text = text.take(MAX_TEXT), note = if (cut) "Documento longo: li só o começo." else "")
                    }
                    entry = zip.nextEntry
                }
            }
        }
        return DocContent(name, "erro", note = "Este .docx não tem texto legível.")
    }

    private fun readPdf(context: Context, uri: Uri, name: String): DocContent {
        val pfd = context.contentResolver.openFileDescriptor(uri, "r") ?: return DocContent(name, "erro", note = "Não foi possível abrir o PDF.")
        val images = mutableListOf<String>()
        var total = 0
        val renderer = PdfRenderer(pfd)
        try {
            total = renderer.pageCount
            val pages = minOf(total, MAX_PDF_PAGES)
            for (i in 0 until pages) {
                val page = renderer.openPage(i)
                try {
                    val scale = 1100f / maxOf(page.width, 1)
                    val w = (page.width * scale).toInt().coerceAtLeast(200)
                    val h = (page.height * scale).toInt().coerceAtLeast(200)
                    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    Canvas(bmp).drawColor(Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    images += encode(bmp)
                    bmp.recycle()
                } finally {
                    page.close()
                }
            }
        } finally {
            renderer.close()
            runCatching { pfd.close() }
        }
        val note = if (total > MAX_PDF_PAGES) "PDF com $total páginas: li as primeiras $MAX_PDF_PAGES." else "PDF com $total página(s)."
        return DocContent(name, "pdf", images = images, note = note)
    }

    private fun readImage(context: Context, uri: Uri, name: String): DocContent {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > MAX_IMAGE_SIDE * 2) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: return DocContent(name, "erro", note = "Não consegui abrir a imagem.")
        val scaled = scaleDown(bmp)
        val b64 = encode(scaled)
        if (scaled !== bmp) bmp.recycle()
        scaled.recycle()
        return DocContent(name, "imagem", images = listOf(b64))
    }

    private fun scaleDown(bmp: Bitmap): Bitmap {
        val longSide = maxOf(bmp.width, bmp.height)
        if (longSide <= MAX_IMAGE_SIDE) return bmp
        val f = MAX_IMAGE_SIDE.toFloat() / longSide
        return Bitmap.createScaledBitmap(bmp, (bmp.width * f).toInt().coerceAtLeast(1), (bmp.height * f).toInt().coerceAtLeast(1), true)
    }

    private fun encode(bmp: Bitmap): String {
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 80, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }
}
