package com.aurora.core.model

import android.net.Uri

/** Provider separado para visão/geração de imagens; texto local não é tratado como gerador de imagem. */
interface ImageProvider {
    val id: String
    val label: String
    suspend fun generate(prompt: String): Result<Uri>
}

class UnavailableImageProvider : ImageProvider {
    override val id = "none"
    override val label = "Geração de imagens não configurada"
    override suspend fun generate(prompt: String): Result<Uri> =
        Result.failure(UnsupportedOperationException("Nenhum provider de imagens foi configurado."))
}

/** Provider separado para entrada visual quando um modelo multimodal estiver disponível. */
interface VisionProvider {
    val id: String
    val label: String
    suspend fun describe(image: Uri, prompt: String? = null): Result<String>
}

class UnavailableVisionProvider : VisionProvider {
    override val id = "none"
    override val label = "Visão não configurada"
    override suspend fun describe(image: Uri, prompt: String?): Result<String> =
        Result.failure(UnsupportedOperationException("Nenhum provider de visão foi configurado."))
}
