package com.aurora.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.graphics.BitmapFactory
import androidx.core.app.NotificationCompat
import com.aurora.R

class AuroraGenerationService : Service() {

    companion object {
        const val ACTION_START = "com.aurora.START_GENERATION"
        const val ACTION_STOP = "com.aurora.STOP_GENERATION"
        const val CHANNEL_ID = "aurora_generation"
        const val NOTIFICATION_ID = 4201
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Sempre promove a foreground primeiro: quem chamou startForegroundService() exige isso em poucos segundos,
        // mesmo quando o comando é de parada. Caso contrário o sistema derruba o app.
        runCatching { startForeground(NOTIFICATION_ID, notification()) }
        if (intent?.action == ACTION_STOP) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun notification(): Notification {
        val openApp = PendingIntent.getActivity(
            this,
            4201,
            Intent(this, com.aurora.MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_aurora)
            .setLargeIcon(BitmapFactory.decodeResource(resources, R.drawable.aurora_notification_avatar))
            .setContentTitle("Aurora")
            .setContentText("Aurora está trabalhando em segundo plano…")
            .setContentIntent(openApp)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(
                    NotificationChannel(
                        CHANNEL_ID,
                        "Aurora · trabalho em segundo plano",
                        NotificationManager.IMPORTANCE_LOW
                    )
                )
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
