package com.aurora.core.agent

import android.content.Context
import com.aurora.core.database.MemoryEmbeddingDao
import com.aurora.core.database.MemoryEmbeddingEntity
import com.aurora.core.database.MemoryEntity
import com.aurora.core.perf.PerfTrace
import com.aurora.core.settings.AuroraSettings
import dev.ffmpegkit.llama.Llama
import dev.ffmpegkit.llama.LlamaConfig
import dev.ffmpegkit.llama.LlamaModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sqrt

/**
 * BGE-M3 + llama.cpp embeddings para memória semântica totalmente local.
 *
 * Caminho crítico (antes da geração) — o que pode e o que NÃO pode acontecer em [relevant]:
 *  • NÃO espera carregar o modelo de embeddings: se está frio, devolve vazio (o chamador usa o léxico).
 *    O aquecimento é pedido por [warmUp] FORA do caminho crítico (na inicialização e depois de cada resposta).
 *  • NÃO espera outra operação de embeddings: usa tryLock; se ocupado (indexação/aquecimento), devolve vazio.
 *  • PODE, com o modelo quente: 1 chamada `Llama.embed` sobre a pergunta do usuário (custo real, medido como
 *    `memory_embed_query`) e, se faltar vetor no cache, 1 leitura de todos os vetores do banco (`memory_vectors_db`).
 * Depois de [IDLE_RELEASE_MS] sem uso o modelo é descarregado (e só volta via [warmUp]).
 */
class SemanticMemory(
    context: Context,
    private val settings: AuroraSettings,
    private val dao: MemoryEmbeddingDao,
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
) {
    private val appContext = context.applicationContext
    private val mutex = Mutex()
    @Volatile private var model: LlamaModel? = null
    private var idleJob: Job? = null

    /** Vetores já decodificados; evita ler/decodificar todos os blobs do banco a cada mensagem. */
    private val vectorCache = HashMap<Long, CachedVector>()
    private var cacheModel: String = ""

    private class CachedVector(val updatedAt: Long, val vector: FloatArray)

    fun isWarm(): Boolean = model != null

    /** Carrega o modelo de embeddings em segundo plano (não bloqueia quem chama). */
    fun warmUp() {
        if (!available() || model != null) return
        scope.launch { mutex.withLock { withContext(Dispatchers.Default) { ensureModel() }; touch() } }
    }

    suspend fun index(memory: MemoryEntity) {
        if (!available()) return
        mutex.withLock {
            withContext(Dispatchers.Default) {
                val vector = embedLocked(memory.content)
                if (vector != null) {
                    val name = settings.embeddingModelFileName
                    dao.upsert(MemoryEmbeddingEntity(memory.id, name, encode(vector), memory.updatedAt))
                    if (cacheModel == name) vectorCache[memory.id] = CachedVector(memory.updatedAt, vector)
                }
            }
            touch()
        }
    }

    suspend fun remove(memoryId: Long) {
        dao.delete(memoryId)
        mutex.withLock { vectorCache.remove(memoryId) }
    }

    /**
     * Memórias semanticamente próximas da consulta (acima de [MIN_SIMILARITY]). Nunca espera: ver cabeçalho da classe.
     * Retorno vazio significa "use o fallback lexical" (modelo frio, ocupado ou nada acima do limiar).
     */
    suspend fun relevant(
        query: String,
        memories: List<MemoryEntity>,
        maxItems: Int,
        maxChars: Int,
        trace: PerfTrace = PerfTrace.NONE
    ): List<MemoryEntity> {
        if (!available() || memories.isEmpty()) return emptyList()
        if (!isWarm()) { trace.note("semantic", "cold→lexical"); return emptyList() }
        if (!mutex.tryLock()) { trace.note("semantic", "busy→lexical"); return emptyList() }
        try {
            return withContext(Dispatchers.Default) {
                val queryVector = trace.measureSuspend("memory_embed_query") { embedLocked(query) }
                    ?: return@withContext emptyList<MemoryEntity>()
                val name = settings.embeddingModelFileName
                if (cacheModel != name) { vectorCache.clear(); cacheModel = name }
                val byId = memories.associateBy { it.id }
                val missing = byId.keys.any { id -> vectorCache[id]?.updatedAt != byId[id]?.updatedAt }
                trace.note("memory_vector_cache_miss", missing)
                if (missing) {
                    trace.measureSuspend("memory_vectors_db") {
                        dao.all().filter { it.modelFileName == name }.forEach {
                            vectorCache[it.memoryId] = CachedVector(it.updatedAt, decode(it.vector))
                        }
                    }
                }
                val ranked = byId.values.asSequence()
                    .mapNotNull { m -> vectorCache[m.id]?.let { m to cosine(queryVector, it.vector) } }
                    .filter { it.second >= MIN_SIMILARITY }
                    .sortedByDescending { it.second }
                    .map { it.first }
                    .toList()
                val result = mutableListOf<MemoryEntity>()
                var used = 0
                for (memory in ranked) {
                    if (result.size >= maxItems) break
                    if (used + memory.content.length > maxChars) continue
                    result += memory
                    used += memory.content.length
                }
                touch()
                result.toList()
            }
        } finally {
            mutex.unlock()
        }
    }

    fun available(): Boolean {
        val name = settings.embeddingModelFileName
        val file = File(appContext.filesDir, "models/$name")
        return name.isNotBlank() && file.exists() && file.length() > 4L * 1024L * 1024L
    }

    fun release() {
        idleJob?.cancel()
        freeModel()
    }

    private fun freeModel() {
        synchronized(this) {
            model?.let { runCatching { Llama.releaseModel(it) } }
            model = null
        }
    }

    private suspend fun ensureModel(): LlamaModel? {
        model?.let { return it }
        return try {
            Llama.loadModel(
                File(appContext.filesDir, "models/${settings.embeddingModelFileName}").absolutePath,
                LlamaConfig(contextSize = 512, threads = Runtime.getRuntime().availableProcessors().coerceIn(2, 4))
            ).also { model = it }
        } catch (_: Throwable) {
            null
        }
    }

    private suspend fun embedLocked(text: String): FloatArray? {
        val loaded = ensureModel() ?: return null
        return try { Llama.embed(loaded, text) } catch (_: Throwable) { null }
    }

    /** Reinicia o temporizador de descarregamento por inatividade. */
    private fun touch() {
        idleJob?.cancel()
        idleJob = scope.launch {
            delay(IDLE_RELEASE_MS)
            mutex.withLock { freeModel() }
        }
    }

    private fun encode(vector: FloatArray): ByteArray {
        val buffer = ByteBuffer.allocate(4 + vector.size * 4).order(ByteOrder.LITTLE_ENDIAN)
        buffer.putInt(vector.size)
        vector.forEach(buffer::putFloat)
        return buffer.array()
    }

    private fun decode(bytes: ByteArray): FloatArray {
        val buffer = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val size = buffer.int.coerceAtLeast(0).coerceAtMost((bytes.size - 4) / 4)
        return FloatArray(size) { buffer.float }
    }

    private fun cosine(a: FloatArray, b: FloatArray): Float {
        val n = minOf(a.size, b.size)
        if (n == 0) return -1f
        var dot = 0.0
        var aa = 0.0
        var bb = 0.0
        for (i in 0 until n) {
            val x = a[i].toDouble(); val y = b[i].toDouble()
            dot += x * y; aa += x * x; bb += y * y
        }
        val denom = sqrt(aa) * sqrt(bb)
        return if (denom == 0.0) -1f else (dot / denom).toFloat()
    }

    private companion object {
        const val IDLE_RELEASE_MS = 5 * 60_000L
        /** Abaixo disso a memória é considerada irrelevante e NÃO entra no prompt (menos tokens para processar). */
        const val MIN_SIMILARITY = 0.40f
    }
}
