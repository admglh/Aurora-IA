#!/data/data/com.termux/files/usr/bin/bash
BASE="$(cd "$(dirname "$0")" && pwd)"
if [ -f "$BASE/data/logs/server.pid" ]; then kill "$(cat "$BASE/data/logs/server.pid")" 2>/dev/null || true; rm -f "$BASE/data/logs/server.pid"; fi
echo "Aurora Termux parada."
