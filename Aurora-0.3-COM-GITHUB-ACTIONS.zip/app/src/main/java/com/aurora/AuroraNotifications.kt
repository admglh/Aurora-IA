package com.aurora

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.ComponentName
import android.graphics.BitmapFactory
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

object AuroraNotifications {
    private const val CHANNEL = "aurora_conversation_v2"
    private const val NOTIFICATION_ID = 4101

    /** Publica uma notificação por resposta, sem duplicar o aviso entre onStop e o fim do streaming. */
    @Synchronized
    fun notifyConversationForMessage(context: Context, messageId: Long, preview: String) {
        val prefs = context.getSharedPreferences("aurora_bubble", Context.MODE_PRIVATE)
        if (prefs.getLong("last_notified_message_id", Long.MIN_VALUE) == messageId) return
        val number = prefs.getInt("number", 0) + 1
        prefs.edit()
            .putInt("number", number)
            .putLong("last_notified_message_id", messageId)
            .apply()
        notifyConversation(context, number, preview)
    }

    fun notifyConversation(context: Context, number: Int, preview: String) {
        val manager = context.getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL, "Aurora · conversa", NotificationManager.IMPORTANCE_DEFAULT).apply {
                    description = "Mensagens da Aurora"
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) setAllowBubbles(true)
                }
            )
        }
        val intent = android.content.Intent(context, MainActivity::class.java).apply {
            flags = android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP or android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pending = PendingIntent.getActivity(
            context, 4101, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val iconCompat = androidx.core.graphics.drawable.IconCompat.createWithResource(
            context, R.drawable.aurora_notification_avatar
        )
        val hasConversationShortcut = Build.VERSION.SDK_INT >= Build.VERSION_CODES.R &&
            ensureConversationShortcut(context, intent)
        val bubbleBuilder = if (hasConversationShortcut) {
            NotificationCompat.BubbleMetadata.Builder("aurora_conversation")
        } else {
            NotificationCompat.BubbleMetadata.Builder(pending, iconCompat)
        }
        val bubble = bubbleBuilder
            .setDesiredHeight(720)
            .setAutoExpandBubble(false)
            .setSuppressNotification(false)
            .build()
        val notification = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_aurora)
            .setLargeIcon(BitmapFactory.decodeResource(context.resources, R.drawable.aurora_notification_avatar))
            .setContentTitle("Aurora · $number")
            .setContentText(preview.take(120))
            .setContentIntent(pending)
            .setAutoCancel(true)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setShortcutId(if (hasConversationShortcut) "aurora_conversation" else null)
            .addPerson(
                androidx.core.app.Person.Builder()
                    .setName("Aurora")
                    .setIcon(iconCompat)
                    .build()
            )
            .setBubbleMetadata(bubble)
            .setNumber(number)
            .build()
        if (Build.VERSION.SDK_INT < 33 || NotificationManagerCompat.from(context).areNotificationsEnabled()) {
            NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, notification)
        }
    }

    /** Android 11+ exige que a bolha esteja associada a um atalho de conversa persistente. */
    private fun ensureConversationShortcut(context: Context, intent: android.content.Intent): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return false
        return runCatching {
            val icon = Icon.createWithResource(context, R.drawable.aurora_notification_avatar)
            val person = android.app.Person.Builder()
                .setName("Aurora")
                .setIcon(icon)
                .build()
            val shortcut = ShortcutInfo.Builder(context, "aurora_conversation")
                .setShortLabel("Aurora")
                .setLongLabel("Conversa com Aurora")
                .setIcon(icon)
                .setIntent(intent)
                .setActivity(ComponentName(context, MainActivity::class.java))
                .setLongLived(true)
                .setPerson(person)
                .setCategories(setOf(ShortcutInfo.SHORTCUT_CATEGORY_CONVERSATION))
                .build()
            context.getSystemService(ShortcutManager::class.java).pushDynamicShortcut(shortcut)
            true
        }.getOrDefault(false)
    }
}
