#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
OUT="${1:-$(cd "$(dirname "$0")/.." && pwd)/app/src/main/assets/models/catalog_online.json}"
mkdir -p "$(dirname "$OUT")"
command -v curl >/dev/null || { echo 'curl não encontrado'; exit 1; }
# Catálogo real, consultado no Hugging Face. Não inventa repositórios.
URL='https://huggingface.co/api/models?pipeline_tag=text-generation&library=gguf&sort=downloads&direction=-1&limit=500'
curl -fsSL "$URL" -o "$OUT"
python - "$OUT" <<'PY'
import json,sys
p=sys.argv[1]
d=json.load(open(p))
assert isinstance(d,list) and len(d)>=1
open(p,'w').write(json.dumps(d,ensure_ascii=False,indent=2))
print(f'[AURORA] catálogo online salvo: {len(d)} modelos')
PY
