package com.aurora.ui

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.aurora.core.voice.AuroraVoice

private val GOLD = Color(0xFFD7B45A)
private val BLUE = Color(0xFF1E5EFF)
private val WHITE = Color(0xFFF2F2F2)
private val MUTED = Color(0xFF8A8A8A)
private val RED = Color(0xFFD85A5A)
private val GREEN = Color(0xFF4CAF7A)

@Composable
internal fun StudioCard(title: String, content: @Composable () -> Unit) {
    Surface(
        Modifier.fillMaxWidth().border(1.dp, BLUE.copy(alpha = .6f), RoundedCornerShape(18.dp)),
        color = Color.Transparent,
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.padding(15.dp)) {
            Text(title, color = GOLD, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
internal fun StudioButton(text: String, color: Color = BLUE, modifier: Modifier = Modifier, onClick: () -> Unit) {
    TextButton(
        onClick = onClick,
        modifier = modifier.fillMaxWidth().border(1.dp, color.copy(alpha = .6f), RoundedCornerShape(12.dp))
    ) { Text(text, color = color, fontWeight = FontWeight.Bold) }
}

@Composable
internal fun ChoiceRow(label: String, detail: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(if (selected) "●" else "○", color = GOLD)
        Spacer(Modifier.width(10.dp))
        Column {
            Text(label, color = WHITE, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
            if (detail.isNotBlank()) Text(detail, color = MUTED)
        }
    }
}

@Composable
private fun LabeledSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    format: (Float) -> String,
    onCommit: (Float) -> Unit
) {
    var local by remember(value) { mutableStateOf(value) }
    Text("$label: ${format(local)}", color = WHITE)
    Slider(value = local, onValueChange = { local = it }, onValueChangeFinished = { onCommit(local) }, valueRange = range)
}

private fun pct(v: Float) = "%+d%%".format((v * 100).toInt())

/** Estúdio de voz: motor, voz feminina, tom, velocidade, graves, agudos, reforço de graves e volume. */
@Composable
fun VoiceStudioCard(vm: AuroraViewModel) {
    val cfg by vm.voiceConfig.collectAsState()
    var tick by remember { mutableIntStateOf(0) }
    val deviceVoices = remember(cfg.engine, tick) { vm.deviceVoices() }

    StudioCard("VOZ DA AURORA") {
        Text("Voz feminina, do seu jeito. Mexa nos controles e toque em TESTAR.", color = MUTED)
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Falar as respostas automaticamente", color = WHITE, modifier = Modifier.weight(1f))
            Switch(checked = cfg.autoSpeak, onCheckedChange = { vm.updateVoice(cfg.copy(autoSpeak = it)) })
        }
        Spacer(Modifier.height(10.dp))
        Text("MOTOR", color = GOLD, fontWeight = FontWeight.Bold)
        ChoiceRow("Natural (nuvem)", "Voz feminina do Gemini via seu Worker. Se falhar, usa a do aparelho sozinha.", cfg.engine == "cloud") {
            vm.updateVoice(cfg.copy(engine = "cloud"))
        }
        ChoiceRow("Do aparelho", "Voz instalada no Android (offline, instantânea).", cfg.engine == "device") {
            vm.updateVoice(cfg.copy(engine = "device"))
        }
        Spacer(Modifier.height(6.dp))
        if (cfg.engine == "cloud") {
            Text("VOZ FEMININA", color = GOLD, fontWeight = FontWeight.Bold)
            AuroraVoice.CLOUD_VOICES.forEach { (name, desc) ->
                ChoiceRow(name, desc, cfg.cloudName == name) { vm.updateVoice(cfg.copy(cloudName = name)) }
            }
        } else {
            Text("VOZ DO APARELHO", color = GOLD, fontWeight = FontWeight.Bold)
            ChoiceRow("Automática", "Prefere voz feminina pt-BR instalada.", cfg.deviceName.isBlank()) {
                vm.updateVoice(cfg.copy(deviceName = ""))
            }
            deviceVoices.forEach { v ->
                ChoiceRow(v.label, "", cfg.deviceName == v.name) { vm.updateVoice(cfg.copy(deviceName = v.name)) }
            }
            if (deviceVoices.isEmpty()) Text("Nenhuma voz em português encontrada ainda. Instale/atualize o \"Reconhecimento e síntese de fala\" do Google.", color = MUTED)
            StudioButton("ATUALIZAR LISTA") { tick++ }
        }
        Spacer(Modifier.height(10.dp))
        Text("AJUSTES", color = GOLD, fontWeight = FontWeight.Bold)
        LabeledSlider("Tom", cfg.pitch, 0.5f..1.8f, { "%.2f".format(it) }) { vm.updateVoice(cfg.copy(pitch = it)) }
        LabeledSlider("Velocidade", cfg.rate, 0.5f..1.8f, { "%.2f".format(it) }) { vm.updateVoice(cfg.copy(rate = it)) }
        LabeledSlider("Graves", cfg.bass, -1f..1f, ::pct) { vm.updateVoice(cfg.copy(bass = it)) }
        LabeledSlider("Agudos", cfg.treble, -1f..1f, ::pct) { vm.updateVoice(cfg.copy(treble = it)) }
        LabeledSlider("Reforço de graves", cfg.boost, 0f..1f, { "%d%%".format((it * 100).toInt()) }) { vm.updateVoice(cfg.copy(boost = it)) }
        LabeledSlider("Volume da voz", cfg.gain, 0f..1f, { "%d%%".format((it * 100).toInt()) }) { vm.updateVoice(cfg.copy(gain = it)) }
        Spacer(Modifier.height(8.dp))
        StudioButton("TESTAR A VOZ", GOLD) { vm.testVoice() }
        Spacer(Modifier.height(6.dp))
        StudioButton("PARAR") { vm.stopVoice() }
        Spacer(Modifier.height(6.dp))
        StudioButton("VOLTAR AO PADRÃO FEMININO", RED) { vm.resetVoice() }
        val note = vm.voiceNote()
        if (note.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(note, color = MUTED)
        }
    }
}

/** Faz uma pergunta de verdade à nuvem e mostra o erro exato (ou o sucesso). */
@Composable
fun CloudTestCard(vm: AuroraViewModel) {
    val result by vm.cloudTest.collectAsState()
    Spacer(Modifier.height(12.dp))
    StudioCard("TESTAR CONEXÃO COM A NUVEM") {
        Text("Depois de tocar em USAR NUVEM, teste aqui. Se algo estiver errado, o motivo aparece escrito.", color = MUTED)
        Spacer(Modifier.height(8.dp))
        StudioButton("TESTAR AGORA", GOLD) { vm.testCloud() }
        if (result.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(result, color = if (result.startsWith("✅")) GREEN else if (result.startsWith("⚠")) GOLD else if (result.startsWith("Testando")) MUTED else RED)
        }
    }
}

private val IMG_MARKER = Regex("\\[\\[img:([^\\]]+)\\]\\]")

/** Texto de uma mensagem; marcadores [[img:CAMINHO]] viram imagens (geradas pela Aurora). */
@Composable
fun MessageText(text: String, streaming: Boolean) {
    val images = remember(text) { IMG_MARKER.findAll(text).map { it.groupValues[1] }.toList() }
    val plain = remember(text) { IMG_MARKER.replace(text, "").trim() }
    if (plain.isNotBlank() || images.isEmpty()) {
        Text(text = if (streaming && plain.isBlank()) "…" else plain, color = WHITE)
    }
    images.forEach { path -> ChatImage(path) }
}

@Composable
private fun ChatImage(path: String) {
    val bitmap = remember(path) {
        runCatching {
            val opts = BitmapFactory.Options().apply { inSampleSize = 2 }
            BitmapFactory.decodeFile(path, opts)
        }.getOrNull()
    }
    if (bitmap != null) {
        Image(
            bitmap = bitmap.asImageBitmap(),
            contentDescription = "Imagem gerada pela Aurora",
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp).clip(RoundedCornerShape(12.dp)),
            contentScale = ContentScale.FillWidth
        )
    } else {
        Text("(imagem indisponível)", color = MUTED)
    }
}
