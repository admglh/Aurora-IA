package com.aurora.core.perf

import android.content.Context
import android.util.Log
import java.io.File
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

/**
 * Instrumentação de latência (diagnóstico). Tag do logcat: AURORA_PERF.
 *
 *   adb logcat -s AURORA_PERF
 *
 * NUNCA registra texto de conversa, memórias ou persona: apenas contagens de caracteres e tempos.
 *
 * COMO REMOVER: apague o pacote `core/perf` e as linhas que usam `trace.`/`PerfLog.`/`PerfOverrides.`
 * (procure por "PerfTrace" e "PerfLog" no projeto). Para só silenciar, ponha [ENABLED] = false:
 * todas as chamadas viram no-ops.
 */
object PerfLog {
    const val ENABLED = false
    const val TAG = "AURORA_PERF"

    private val seq = AtomicInteger(0)

    fun newTrace(): PerfTrace = if (ENABLED) PerfTrace(seq.incrementAndGet(), true) else PerfTrace.NONE

    fun line(message: String) { if (ENABLED) Log.i(TAG, message) }

    /** Marca "estado publicado para a UI"; a UI fecha a medição quando o quadro correspondente é desenhado. */
    class UiMark(val reqId: Int, val label: String, val publishedAtNanos: Long)

    private val pendingUi = AtomicReference<UiMark?>(null)

    fun markUiPublished(trace: PerfTrace, label: String) {
        if (ENABLED && trace.enabled) pendingUi.set(UiMark(trace.id, label, System.nanoTime()))
    }

    fun takeUiMark(): UiMark? = if (ENABLED) pendingUi.getAndSet(null) else null

    fun uiFrameDrawn(mark: UiMark) {
        val ms = (System.nanoTime() - mark.publishedAtNanos) / 1_000_000
        line("req=${mark.reqId} ui_${mark.label}=${ms}ms (publicação→2 quadros depois; precisão ≈ ±16ms)")
    }
}

/** Medições de UMA mensagem enviada. Cada evento é logado na hora (sobrevive a crash/travamento). */
class PerfTrace internal constructor(val id: Int, val enabled: Boolean) {
    private val t0 = System.nanoTime()

    fun sinceStartMs(): Long = (System.nanoTime() - t0) / 1_000_000

    /** Duração de uma etapa. */
    fun ms(label: String, millis: Long) {
        if (enabled) Log.i(PerfLog.TAG, "req=$id $label=${millis}ms")
    }

    /** Instante (desde o toque em "enviar") em que algo aconteceu. */
    fun at(label: String) {
        if (enabled) Log.i(PerfLog.TAG, "req=$id ${label}_at=${sinceStartMs()}ms")
    }

    fun note(key: String, value: Any?) {
        if (enabled) Log.i(PerfLog.TAG, "req=$id $key=$value")
    }

    /** Mede um bloco síncrono. */
    inline fun <T> measure(label: String, block: () -> T): T {
        if (!enabled) return block()
        val start = System.nanoTime()
        try {
            return block()
        } finally {
            ms(label, (System.nanoTime() - start) / 1_000_000)
        }
    }

    /** Mede um bloco suspensivo sem bloquear a thread da coroutine. */
    suspend inline fun <T> measureSuspend(label: String, crossinline block: suspend () -> T): T {
        if (!enabled) return block()
        val start = System.nanoTime()
        try {
            return block()
        } finally {
            ms(label, (System.nanoTime() - start) / 1_000_000)
        }
    }

    companion object {
        val NONE = PerfTrace(0, false)
    }
}

/**
 * Ajustes de teste SEM recompilar. Arquivo opcional: <filesDir>/aurora-config/perf.cfg, linhas `chave=valor`.
 *   threads=4      força o nº de threads do llama.cpp (vale no próximo carregamento do modelo)
 *   no_think=0     desliga o sufixo "/no_think" (vale na próxima mensagem)
 * Sem o arquivo, nada muda. Só é lido quando [PerfLog.ENABLED] é true.
 */
object PerfOverrides {
    @Volatile private var file: File? = null

    fun init(context: Context) {
        file = File(context.applicationContext.filesDir, "aurora-config/perf.cfg")
    }

    private fun read(key: String): String? {
        if (!PerfLog.ENABLED) return null
        val f = file?.takeIf { it.isFile } ?: return null
        return runCatching {
            f.readLines().firstNotNullOfOrNull { line ->
                val i = line.indexOf('=')
                if (i > 0 && line.substring(0, i).trim() == key) line.substring(i + 1).trim() else null
            }
        }.getOrNull()
    }

    fun int(key: String): Int? = read(key)?.toIntOrNull()
    fun bool(key: String): Boolean? = read(key)?.let { it == "1" || it.equals("true", true) }
}

/**
 * Descobre, no aparelho, o que o AAR `llama-android` realmente expõe (sem depender de documentação):
 * métodos públicos de `Llama` (existe streaming? tokenize? stop?), campos de `LlamaConfig` e do resultado.
 * Só lê nomes/tipos por reflexão; nenhum valor de conteúdo.
 */
object ApiProbe {
    @Volatile private var dumped = false

    fun dumpOnce(vararg classes: Class<*>) {
        if (!PerfLog.ENABLED || dumped) return
        dumped = true
        classes.forEach { c ->
            runCatching {
                val methods = c.methods.filter { it.declaringClass != Any::class.java }
                    .joinToString(",") { m -> m.name + "(" + m.parameterTypes.joinToString("+") { it.simpleName } + ")" }
                val fields = c.declaredFields.joinToString(",") { it.name + ":" + it.type.simpleName }
                PerfLog.line("api_probe class=${c.name} fields=[$fields] methods=[$methods]")
            }
        }
    }

    /** Campos numéricos/booleanos do resultado da inferência (ex.: contagem de tokens, tempos), se existirem. */
    fun describeResult(trace: PerfTrace, result: Any) {
        if (!trace.enabled) return
        runCatching {
            val parts = result.javaClass.declaredFields.mapNotNull { f ->
                if (f.name == "text" || java.lang.reflect.Modifier.isStatic(f.modifiers)) return@mapNotNull null
                f.isAccessible = true
                val v = f.get(result)
                if (v is Number || v is Boolean || (v is String && v.length <= 24)) "${f.name}=$v" else null
            }
            trace.note("native_result", if (parts.isEmpty()) "(sem campos numéricos além do texto)" else parts.joinToString(","))
        }
    }
}
