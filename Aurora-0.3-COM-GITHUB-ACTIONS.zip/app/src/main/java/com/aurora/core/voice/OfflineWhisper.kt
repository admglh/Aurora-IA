package com.aurora.core.voice

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import com.aurora.core.perf.PerfLog
import dev.ffmpegkit.whisper.Whisper
import dev.ffmpegkit.whisper.WhisperConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream

/**
 * STT totalmente local opcional. Se não houver modelo Whisper instalado, a UI pode usar o
 * SpeechRecognizer do Android como fallback. A gravação é PCM 16 kHz mono e vira WAV.
 */
class OfflineWhisper(private val context: Context, private val modelFile: File) {
    private var recorder: AudioRecord? = null
    private var recordingThread: Thread? = null
    private var wavFile: File? = null
    @Volatile private var recording = false

    fun isAvailable(): Boolean = modelFile.isFile && modelFile.length() > 10L * 1024L * 1024L

    fun start() {
        check(!recording) { "Gravação já está ativa." }
        val min = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNELS, ENCODING)
        require(min > 0) { "O microfone não está disponível." }
        val bufferSize = (min * 2).coerceAtLeast(4096)
        val output = File(context.cacheDir, "aurora-speech-${System.currentTimeMillis()}.wav")
        wavFile = output
        val r = AudioRecord(MediaRecorder.AudioSource.MIC, SAMPLE_RATE, CHANNELS, ENCODING, bufferSize)
        recorder = r
        recording = true
        r.startRecording()
        recordingThread = Thread {
            output.outputStream().use { raw ->
                BufferedOutputStream(raw).use { out ->
                    writeWavHeader(out, 0)
                    val buffer = ShortArray(bufferSize / 2)
                    var totalSamples = 0L
                    while (recording) {
                        val count = r.read(buffer, 0, buffer.size)
                        if (count > 0) {
                            val bytes = ByteArray(count * 2)
                            for (i in 0 until count) {
                                val v = buffer[i].toInt()
                                bytes[i * 2] = (v and 0xff).toByte()
                                bytes[i * 2 + 1] = ((v ushr 8) and 0xff).toByte()
                            }
                            out.write(bytes)
                            totalSamples += count
                        }
                    }
                    out.flush()
                    patchWavHeader(output, totalSamples * 2)
                }
            }
        }.apply { start() }
    }

    suspend fun stopAndTranscribe(): String = withContext(Dispatchers.IO) {
        if (!recording) return@withContext ""
        recording = false
        recorder?.stop()
        recordingThread?.join(3000)
        recorder?.release()
        recorder = null
        recordingThread = null
        val audio = wavFile ?: return@withContext ""
        try {
            require(isAvailable()) { "Modelo Whisper offline não está instalado." }
            val loadStart = System.nanoTime()
            val model = Whisper.loadModel(context, modelFile.absolutePath) // recarregado a cada transcrição (não há cache)
            PerfLog.line("stt_model_load=${(System.nanoTime() - loadStart) / 1_000_000}ms audio_kb=${audio.length() / 1024}")
            try {
                val t = System.nanoTime()
                Whisper.transcribe(model, audio.absolutePath, WhisperConfig(language = "pt")).text.trim()
                    .also { PerfLog.line("stt_transcribe=${(System.nanoTime() - t) / 1_000_000}ms chars=${it.length}") }
            } finally {
                Whisper.releaseModel(model)
                audio.delete()
            }
        } finally {
            audio.delete()
        }
    }

    fun cancel() {
        recording = false
        runCatching { recorder?.stop() }
        runCatching { recorder?.release() }
        recorder = null
        recordingThread = null
        wavFile?.delete()
        wavFile = null
    }

    private fun writeWavHeader(out: BufferedOutputStream, dataSize: Long) {
        val header = ByteArray(44)
        header[0] = 'R'.code.toByte(); header[1] = 'I'.code.toByte(); header[2] = 'F'.code.toByte(); header[3] = 'F'.code.toByte()
        header[8] = 'W'.code.toByte(); header[9] = 'A'.code.toByte(); header[10] = 'V'.code.toByte(); header[11] = 'E'.code.toByte()
        header[12] = 'f'.code.toByte(); header[13] = 'm'.code.toByte(); header[14] = 't'.code.toByte(); header[15] = ' '.code.toByte()
        putInt(header, 16, 16); putShort(header, 20, 1); putShort(header, 22, 1); putInt(header, 24, SAMPLE_RATE)
        putInt(header, 28, SAMPLE_RATE * 2); putShort(header, 32, 2); putShort(header, 34, 16)
        header[36] = 'd'.code.toByte(); header[37] = 'a'.code.toByte(); header[38] = 't'.code.toByte(); header[39] = 'a'.code.toByte()
        putInt(header, 40, dataSize.toInt()); putInt(header, 4, (36 + dataSize).toInt())
        out.write(header)
    }

    private fun patchWavHeader(file: File, dataSize: Long) {
        java.io.RandomAccessFile(file, "rw").use { raf ->
            raf.seek(4); writeIntLE(raf, (36 + dataSize).toInt()); raf.seek(40); writeIntLE(raf, dataSize.toInt())
        }
    }

    private fun putInt(b: ByteArray, o: Int, v: Int) { b[o] = v.toByte(); b[o + 1] = (v ushr 8).toByte(); b[o + 2] = (v ushr 16).toByte(); b[o + 3] = (v ushr 24).toByte() }
    private fun putShort(b: ByteArray, o: Int, v: Int) { b[o] = v.toByte(); b[o + 1] = (v ushr 8).toByte() }
    private fun writeIntLE(r: java.io.RandomAccessFile, v: Int) { r.write(byteArrayOf(v.toByte(), (v ushr 8).toByte(), (v ushr 16).toByte(), (v ushr 24).toByte())) }

    private companion object {
        const val SAMPLE_RATE = 16_000
        const val CHANNELS = AudioFormat.CHANNEL_IN_MONO
        const val ENCODING = AudioFormat.ENCODING_PCM_16BIT
    }
}
