package com.aurora.core.database

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Insert
import androidx.room.OnConflictStrategy

@Entity(tableName = "memory_embeddings")
data class MemoryEmbeddingEntity(
    @PrimaryKey val memoryId: Long,
    val modelFileName: String,
    val vector: ByteArray,
    val updatedAt: Long
)

@Dao
interface MemoryEmbeddingDao {
    @Query("SELECT * FROM memory_embeddings")
    suspend fun all(): List<MemoryEmbeddingEntity>

    @Query("SELECT * FROM memory_embeddings WHERE memoryId = :memoryId")
    suspend fun get(memoryId: Long): MemoryEmbeddingEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: MemoryEmbeddingEntity)

    @Query("DELETE FROM memory_embeddings WHERE memoryId = :memoryId")
    suspend fun delete(memoryId: Long)

    @Query("DELETE FROM memory_embeddings")
    suspend fun deleteAll()
}
