# Implementado nesta etapa — identidade visual

## Aplicado

- Nome exibido do aplicativo: `Aurora`.
- Ícone do aplicativo: imagem oficial da caneta fornecida pelo usuário.
- Referências originais das oito roupas/estados e do ícone preservadas em resolução original.
- Tema de aniversário em 29 de março.
- Tema formal para entrevista/reunião/prova por heurística determinística de mensagem.
- Tema de calor para saída em parque/shopping/passeio quando a mensagem contém contexto de calor.
- Tema de frio para saída em parque/shopping/passeio quando a mensagem contém contexto de frio.
- Tema de Páscoa nos três dias: sexta-feira, sábado e domingo da Páscoa calculados por ano.
- Tema de 7 de setembro.
- Tema de Halloween em 31 de outubro.
- Override temporário de tema até o início do dia seguinte.
- Botão para voltar à identidade base.
- Presença da Aurora com respiração, flutuação e núcleo/halo pulsante usando Compose.
- Lottie Compose 6.7.1 adicionado como runtime preparado para a futura camada de animações.

## Deliberadamente não afirmado como implementado

- A imagem raster não foi transformada em rig facial/corporal.
- A Aurora ainda não gera animações Lottie por conta própria.
- Não existe editor de animação dentro do aplicativo.
- Não existe sincronização real de boca com TTS.
- Os estados visuais detalhados OUVINDO/PENSANDO/RESPONDENDO/FALANDO/ERRO ainda precisam ser ligados a um controlador de presença único.
- Eventos personalizados ainda não possuem tela de cadastro.

## Qualidade dos arquivos

As referências fornecidas pelo usuário foram copiadas para o projeto sem redimensionamento ou recompressão adicional. O avatar limpo existente continua preservado para evitar degradar a qualidade enquanto a extração de fundo da nova referência não puder ser feita de forma confiável sem alterar a arte.
