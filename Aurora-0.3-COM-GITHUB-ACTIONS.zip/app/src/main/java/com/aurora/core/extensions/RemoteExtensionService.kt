package com.aurora.core.extensions

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Catálogo remoto de extensões. GitHub é resolvido pela API para não assumir que o branch é main. */
data class ExtensionCatalogItem(
    val id: String,
    val name: String,
    val category: String,
    val description: String,
    val source: String,
    val capabilities: Int = 0
)

class RemoteExtensionService(private val context: Context) {
    fun catalog(): List<ExtensionCatalogItem> = runCatching {
        val raw=context.assets.open("extensions/catalog.json").bufferedReader().use { it.readText() }
        val a=JSONObject(raw).getJSONArray("catalog")
        buildList { for(i in 0 until a.length()){ val o=a.getJSONObject(i); add(ExtensionCatalogItem(o.getString("id"),o.getString("name"),o.getString("category"),o.getString("description"),o.optString("source"),o.optInt("capabilities",0))) } }
    }.getOrDefault(emptyList())

    suspend fun download(item: ExtensionCatalogItem): Result<File> = withContext(Dispatchers.IO) { runCatching {
        val url = resolveDownloadUrl(item.source)
        val dir=File(context.cacheDir,"remote-extensions").apply{mkdirs()}
        val target=File(dir, "${safe(item.id)}.zip.part")
        val final=File(dir, "${safe(item.id)}.zip")
        val c=(URL(url).openConnection() as HttpURLConnection).apply{connectTimeout=15_000;readTimeout=120_000;instanceFollowRedirects=true;setRequestProperty("User-Agent","Aurora/0.1");setRequestProperty("Accept","application/octet-stream,application/zip,*/*")}
        try {
            require(c.responseCode in 200..299){"Download HTTP ${c.responseCode}"}
            c.inputStream.use { input -> target.outputStream().use { output -> input.copyTo(output,1024*1024) } }
        } finally { c.disconnect() }
        require(target.length() > 0) { "Download vazio" }
        require(target.renameTo(final)){"Não foi possível finalizar o download"}
        final
    } }

    private fun resolveDownloadUrl(source: String): String {
        if (!source.contains("github.com/")) return source
        val uri = java.net.URI(source.trimEnd('/'))
        val parts = uri.path.trim('/').split('/')
        require(parts.size >= 2) { "Repositório GitHub inválido" }
        val owner=parts[0]; val repo=parts[1]
        val api="https://api.github.com/repos/${URLEncoder.encode(owner,"UTF-8")}/${URLEncoder.encode(repo,"UTF-8") }"
        val c=(URL(api).openConnection() as HttpURLConnection).apply{connectTimeout=10_000;readTimeout=20_000;setRequestProperty("Accept","application/vnd.github+json");setRequestProperty("User-Agent","Aurora/0.1")}
        try {
            require(c.responseCode in 200..299){"GitHub HTTP ${c.responseCode}"}
            val branch=JSONObject(c.inputStream.bufferedReader().use{it.readText()}).optString("default_branch").ifBlank{"main"}
            return "https://github.com/$owner/$repo/archive/refs/heads/$branch.zip"
        } finally { c.disconnect() }
    }

    private fun safe(s:String)=s.replace(Regex("[^A-Za-z0-9._-]"),"_").ifBlank{"extension"}
}
