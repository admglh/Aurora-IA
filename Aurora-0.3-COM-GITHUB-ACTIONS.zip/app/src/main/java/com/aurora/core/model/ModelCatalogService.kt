package com.aurora.core.model

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class CatalogModel(val id: String, val name: String, val family: String, val quant: String, val url: String, val sizeLabel: String)

class ModelCatalogService(private val context: Context) {
    fun load(): List<CatalogModel> = runCatching {
        val raw = context.assets.open("models/catalog.json").bufferedReader().use { it.readText() }
        val a = JSONArray(raw)
        buildList { for (i in 0 until a.length()) { val o=a.getJSONObject(i); add(CatalogModel(o.getString("id"),o.getString("name"),o.getString("family"),o.getString("quant"),o.getString("url"),o.getString("size"))) } }
    }.getOrDefault(emptyList())

    /**
     * Pesquisa o Hugging Face em tempo real e escolhe automaticamente um GGUF compatível,
     * preferindo Q4_K_M, depois Q5_K_M/Q6_K/Q8_0. Isso transforma o catálogo fixo em uma
     * biblioteca aberta: novos modelos podem aparecer sem atualizar o APK.
     */
    suspend fun searchOnline(query: String, limit: Int = 30): Result<List<CatalogModel>> = withContext(Dispatchers.IO) {
        runCatching {
            require(query.trim().length >= 2) { "Digite pelo menos 2 caracteres para pesquisar." }
            val q = URLEncoder.encode(query.trim().take(100), "UTF-8")
            val requested = limit.coerceIn(1, 500)
            val url = "https://huggingface.co/api/models?search=$q&limit=$requested&expand[]=siblings"
            val json = getText(url)
            val repos = JSONArray(json)
            buildList {
                for (i in 0 until repos.length()) {
                    val repo = repos.optJSONObject(i) ?: continue
                    val id = repo.optString("id").takeIf { it.isNotBlank() } ?: continue
                    val detail = repo
                    val siblings = detail.optJSONArray("siblings") ?: runCatching {
                        JSONObject(getText("https://huggingface.co/api/models/${id.encodePath()}")).optJSONArray("siblings")
                    }.getOrNull() ?: continue
                    val files = buildList {
                        for (j in 0 until siblings.length()) {
                            val f = siblings.optJSONObject(j)?.optString("rfilename").orEmpty()
                            if (f.lowercase().endsWith(".gguf")) add(f)
                        }
                    }
                    val selected = files.sortedWith(compareBy<String> { rankQuant(it) }.thenBy { it.length }).firstOrNull() ?: continue
                    val quant = quantName(selected)
                    val size = detail.optLong("safetensors", 0L).takeIf { it > 0 }?.let(::humanSize) ?: "GGUF online"
                    add(CatalogModel(
                        id = "hf:${id}:$selected",
                        name = selected.substringAfterLast('/'),
                        family = id.substringAfterLast('/'),
                        quant = quant,
                        url = "https://huggingface.co/$id/resolve/main/${selected.split('/').joinToString("/")}?download=true",
                        sizeLabel = size
                    ))
                }
            }
        }
    }

    suspend fun download(model: CatalogModel, onProgress: (Long, Long) -> Unit = { _, _ -> }): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            val dir = File(context.filesDir, "models").apply { mkdirs() }
            val target = File(dir, model.name)
            val part = File(dir, model.name + ".part")
            val existing = part.length()
            val c = (URL(model.url).openConnection() as HttpURLConnection).apply {
                connectTimeout=15_000; readTimeout=120_000; instanceFollowRedirects=true
                if (existing > 0) setRequestProperty("Range", "bytes=$existing-")
                setRequestProperty("User-Agent", "Aurora/0.1")
            }
            try {
                require(c.responseCode == 200 || c.responseCode == 206) { "Download HTTP ${c.responseCode}" }
                val total = (if (c.responseCode == 206) existing else 0L) + c.contentLengthLong.coerceAtLeast(0L)
                if (c.responseCode == 200 && existing > 0) part.delete()
                c.inputStream.use { input -> part.outputStream().use { output ->
                    val buffer=ByteArray(1024*1024); var done=if(c.responseCode==206) existing else 0L
                    while(true){ val n=input.read(buffer); if(n<0) break; output.write(buffer,0,n); done+=n; onProgress(done,total) }
                } }
                require(part.length() > 4L * 1024L * 1024L) { "Arquivo baixado pequeno demais para um GGUF." }
                require(part.renameTo(target)) { "Não foi possível finalizar o download" }
                target
            } finally { c.disconnect() }
        }
    }

    private fun getText(url: String): String {
        val c=(URL(url).openConnection() as HttpURLConnection).apply{connectTimeout=10_000;readTimeout=20_000;instanceFollowRedirects=true;setRequestProperty("User-Agent","Aurora/0.1");setRequestProperty("Accept","application/json")}
        try { require(c.responseCode in 200..299){"HTTP ${c.responseCode}"}; return c.inputStream.bufferedReader().use{it.readText().take(400_000)} } finally { c.disconnect() }
    }
    private fun String.encodePath(): String = java.net.URLEncoder.encode(this, "UTF-8").replace("+", "%20")
    private fun rankQuant(name: String): Int { val n=name.lowercase(); return when { "q4_k_m" in n -> 0; "q5_k_m" in n -> 1; "q6_k" in n -> 2; "q8_0" in n -> 3; "q4" in n -> 4; else -> 5 } }
    private fun quantName(name: String): String = Regex("q[0-9]+(?:_[a-z0-9]+)*", RegexOption.IGNORE_CASE).find(name)?.value ?: "GGUF"
    private fun humanSize(bytes: Long): String = when { bytes >= 1_000_000_000 -> "~%.1f GB".format(java.util.Locale.US, bytes/1_000_000_000.0); bytes >= 1_000_000 -> "~%.0f MB".format(java.util.Locale.US, bytes/1_000_000.0); else -> "GGUF online" }
}
