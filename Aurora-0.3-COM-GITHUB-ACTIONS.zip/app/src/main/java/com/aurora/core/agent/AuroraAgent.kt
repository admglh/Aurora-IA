package com.aurora.core.agent

import android.util.Log
import com.aurora.core.model.ChatMessage
import com.aurora.core.perf.PerfLog
import com.aurora.core.perf.PerfTrace
import com.aurora.core.tools.AndroidToolRegistry
import com.aurora.core.tools.WebFetchTool
import com.aurora.core.tools.WebSearchTool
import com.aurora.core.tools.GitHubService
import com.aurora.core.model.GenerationRequest
import com.aurora.core.model.ModelLimits
import com.aurora.core.model.ModelManager
import com.aurora.core.model.ChatJson
import com.aurora.core.model.OpenAICompatibleProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.flow.flowOn
import org.json.JSONArray
import org.json.JSONObject
import com.aurora.core.tools.ModelToolResult
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * Monta o contexto (persona + data/hora + memórias relevantes + histórico recente) e delega a geração
 * ao [ModelManager]. Não conhece UI nem banco de conversas.
 *
 * A camada de ferramentas é consultada de forma contextual; internet e GitHub entram quando solicitados.
 */
class AuroraAgent(
    private val persona: PersonaProvider,
    private val memory: MemoryRetriever,
    private val models: ModelManager,
    private val tools: AndroidToolRegistry
) {
    private val web = WebFetchTool()
    private val webSearch = WebSearchTool()
    private val github = GitHubService()
    /** [history] = mensagens anteriores da conversa, em ordem cronológica, SEM a mensagem atual. */
    suspend fun buildRequest(history: List<ChatMessage>, userText: String, trace: PerfTrace = PerfTrace.NONE, images: List<String> = emptyList()): GenerationRequest {
        val memories = trace.measureSuspend("memory") { memory.relevant(userText, trace = trace) }
        // Com a nuvem ativa o MODELO decide quando pesquisar/ler/agir (function calling); a pré-injeção por palavra-chave
        // só existe para o modelo local, que não sabe chamar ferramentas.
        val remoteActive = models.remoteProvider() != null
        val toolResults: List<Pair<String, String>> = if (remoteActive) emptyList() else trace.measureSuspend("tools") {
            val local = tools.contextualResults(userText).toMutableList()
            val q = userText.trim()
            val lower = q.lowercase()
            // Gatilhos explícitos. Antes, palavras soltas como "site", "link" ou "pesquisa" disparavam busca na web
            // em conversas comuns e injetavam páginas inteiras no prompt (lento e confuso).
            val urlInText = Regex("https?://\\S+").find(q)?.value?.trimEnd('.', ',', ')', ']', '}', ';')
            val wantsWeb = urlInText != null || listOf("pesquise", "pesquisa na internet", "pesquisa na web", "busque", "procure na internet", "procure na web", "na internet", "na web", "consulte a internet").any(lower::contains)
            if (wantsWeb) {
                val url = urlInText
                if (url != null) web.fetch(url).onSuccess { local += "internet" to it }.onFailure { local += "internet" to "Falha: ${it.message}" }
                else webSearch.search(q).onSuccess { local += "pesquisa_web" to it }.onFailure { local += "pesquisa_web" to "Falha: ${it.message}" }
            }
            if (lower.contains("github")) {
                val repo = Regex("github\\.com/([A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+)").find(q)?.groupValues?.getOrNull(1)
                if (repo != null) {
                    when {
                        listOf("issue", "issues", "problema", "bug").any(lower::contains) -> github.issues(repo).onSuccess { local += "github_issues" to it }.onFailure { local += "github_issues" to "Falha: ${it.message}" }
                        listOf("release", "releases", "versão", "versao", "lançamento", "lancamento").any(lower::contains) -> github.releases(repo).onSuccess { local += "github_releases" to it }.onFailure { local += "github_releases" to "Falha: ${it.message}" }
                        else -> github.repository(repo).onSuccess { local += "github" to it }.onFailure { local += "github" to "Falha: ${it.message}" }
                    }
                } else github.searchRepositories(q.replace(Regex("(?i)github"), "").trim()).onSuccess { local += "github" to it }.onFailure { local += "github" to "Falha: ${it.message}" }
            }
            local
        }
        val system = trace.measure("prompt_assemble") { buildString {
            append(persona.systemPrompt())
            append("\n\n## Contexto atual\nData e hora: ").append(nowText())
            append("\n\n## O que você consegue fazer nesta versão\n").append(tools.capabilitySummary(compact = models.isLocalActive()))
            if (memories.isNotEmpty()) {
                append("\n\n## Memórias sobre o usuário\n")
                memories.forEach { append("- ").append(it.content).append('\n') }
            }
            if (toolResults.isNotEmpty()) {
                append("\n\n## Resultados de ferramentas locais\n")
                val cap = if (models.isLocalActive()) LOCAL_TOOL_CHARS else REMOTE_TOOL_CHARS
                toolResults.forEach { (name, result) -> append("- ").append(name).append(": ").append(result.take(cap)).append('\n') }
            }
        }.trimEnd() }

        // Orçamento do prompt. HIPÓTESE (não confirmada no AAR): `Llama.complete` reprocessa o prompt inteiro a cada
        // chamada (sem reaproveitar o cache KV), então caracteres a mais = prefill a mais. Em qualquer caso o prompt
        // precisa caber na janela de contexto. Consequência do corte: o histórico antigo deixa de ser visto pelo modelo.
        val local = models.isLocalActive()
        val maxTokens = ModelLimits.DEFAULT_MAX_TOKENS
        val promptBudget = if (local) ((ModelLimits.CONTEXT_TOKENS - maxTokens) * ModelLimits.CHARS_PER_TOKEN).toInt()
        else REMOTE_PROMPT_CHARS // endpoint remoto: contexto grande, prefill barato no servidor
        val historyCap = if (local) MAX_HISTORY_CHARS else REMOTE_HISTORY_CHARS
        val userBudget = (promptBudget - system.length).coerceAtLeast(MIN_USER_CHARS)
        val userFitted = fitUserText(userText, userBudget)
        val historyBudget = minOf(historyCap, promptBudget - system.length - userFitted.length).coerceAtLeast(0)

        val fittedHistory = trimHistory(history, historyBudget)
        val totalChars = system.length + fittedHistory.sumOf { it.content.length } + userFitted.length
        if (trace.enabled) {
            val estTokens = (totalChars / ModelLimits.CHARS_PER_TOKEN).toInt()
            trace.note("prompt_chars", "system=${system.length} history=${fittedHistory.sumOf { it.content.length }}(${fittedHistory.size}msgs) user=${userFitted.length}")
            trace.note("prompt_est_tokens", "$estTokens (estimativa; contexto=${ModelLimits.CONTEXT_TOKENS}, max_tokens=$maxTokens, local=$local)")
            if (local && estTokens + maxTokens > ModelLimits.CONTEXT_TOKENS) {
                // Persona/anexos grandes: o prompt NÃO é cortado aqui (a persona é do usuário). Pode exceder a janela do runtime.
                trace.note("ctx_overflow_risk", true)
                Log.w(PerfLog.TAG, "req=${trace.id} prompt estimado + max_tokens excede o contexto local")
            }
        }

        return GenerationRequest(
            messages = listOf(ChatMessage("system", system)) + fittedHistory + ChatMessage("user", userFitted, images),
            // Local não tem stop sequence nem streaming: teto menor limita o pior caso de espera.
            maxTokens = if (local) LOCAL_MAX_TOKENS else maxTokens,
            trace = trace
        )
    }

    private sealed interface LoopResult {
        object Done : LoopResult
        data class Failed(val reason: String, val streamed: Boolean) : LoopResult
    }

    /**
     * [userText] = texto completo para o modelo (inclui o conteúdo de anexos); [typed] = só o que o usuário digitou
     * (usado nos atalhos de ação, para que o texto de um documento nunca dispare alarme/ligação sem querer).
     */
    fun respond(
        history: List<ChatMessage>, userText: String, trace: PerfTrace = PerfTrace.NONE,
        images: List<String> = emptyList(), typed: String = userText
    ): Flow<String> = channelFlow {
        if (images.isEmpty()) {
            // Pergunta sobre as próprias funções: resposta fixa e verdadeira, instantânea.
            tools.capabilityAnswer(typed)?.let { send(it); return@channelFlow }
            // Frases diretas (alarme, timer, lanterna, ligar, SMS…) e respostas "sim/não" a confirmações pendentes.
            tools.handleAction(typed)?.let { send(it); return@channelFlow }
        }
        val request = trace.measureSuspend("prompt_total") { buildRequest(history, userText, trace, images) }
        trace.at("generation_requested")
        // Perguntas comuns não enviam dezenas de esquemas de ferramentas ao Gemini:
        // isso reduz o prefill e o tempo até o primeiro token. O laço de ferramentas só
        // é usado quando o texto pede claramente uma ação, pesquisa ou consulta externa.
        if (models.remoteProvider() != null && shouldUseTools(typed)) {
            when (val r = runToolLoop(request) { piece -> send(piece) }) {
                is LoopResult.Done -> return@channelFlow
                is LoopResult.Failed -> {
                    send((if (r.streamed) "\n\n" else "") + "⚠️ Tive um problema (${r.reason.take(300)}).")
                    if (r.streamed) return@channelFlow
                    send("\n\nVou tentar responder sem as ferramentas.\n\n")
                }
            }
        }
        models.generate(request).collect { send(it) }
    }.flowOn(Dispatchers.IO)

    /** Ferramentas só quando a intenção sugere pesquisa externa ou ação no aparelho. */
    private fun shouldUseTools(text: String): Boolean {
        val q = text.trim().lowercase()
        if (Regex("https?://\\S+").containsMatchIn(q)) return true
        val triggers = listOf(
            "pesquise", "pesquisa na internet", "pesquise na internet", "pesquise na web",
            "pesquisa na web", "busque na internet", "busque na web", "procure na internet",
            "procure na web", "consulte a internet", "notícias de hoje", "noticias de hoje",
            "previsão do tempo", "previsao do tempo", "clima em ", "temperatura em ",
            "cotação do", "cotacao do", "preço atual", "preco atual", "github.com", "no github",
            "abra o site", "acesse o site", "leia este link", "resuma este link",
            "gere uma imagem", "gerar imagem", "crie uma imagem", "faça uma imagem", "faca uma imagem",
            "abra o aplicativo", "abra o app", "inicie o aplicativo", "feche o aplicativo",
            "ligue para", "faça uma ligação", "faca uma ligacao", "envie sms", "mande sms",
            "envie uma mensagem", "mande uma mensagem", "crie um alarme", "defina um alarme",
            "coloque um timer", "inicie um timer", "temporizador", "acenda a lanterna",
            "apague a lanterna", "ligue o bluetooth", "desligue o bluetooth", "ligue o wi-fi",
            "desligue o wi-fi", "ligue o wifi", "desligue o wifi", "modo avião", "modo aviao",
            "mude o brilho", "aumente o brilho", "diminua o brilho", "mude o volume",
            "faça uma captura de tela", "faca uma captura de tela", "screenshot",
            "meus contatos", "procure o contato", "crie um contato", "crie um evento",
            "adicione à agenda", "adicione a agenda", "calendário", "calendario",
            "leia o arquivo", "abra o arquivo", "procure um arquivo", "liste os arquivos",
            "pesquise meus arquivos", "papel de parede", "instale o aplicativo",
            "desinstale o aplicativo", "informações do aparelho", "informacoes do aparelho",
            "quanto espaço livre", "quanto espaco livre", "armazenamento livre",
            "lembre-se de", "lembre disso", "salve na memória", "salve na memoria",
            "apague da memória", "apague da memoria", "consulte", "pesquise", "pesquisa",
            "pesquise online", "busque", "procure na web"
        )
        return triggers.any(q::contains)
    }

    /**
     * Rodadas de function calling com streaming: o modelo chama ferramentas (internet, memória, imagem, arquivos, celular),
     * o app executa (ou pede o "sim" nas ações sensíveis) e devolve o resultado até haver a resposta final.
     */
    private suspend fun runToolLoop(request: GenerationRequest, onPiece: suspend (String) -> Unit): LoopResult {
        val remote: OpenAICompatibleProvider = models.remoteProvider() ?: return LoopResult.Failed("nuvem não está ativa", false)
        var specs = tools.toolSpecs()
        val msgs = JSONArray()
        request.messages.forEachIndexed { i, m ->
            val content = if (i == 0 && m.role == "system") m.content + TOOL_HINT else m.content
            msgs.put(ChatJson.message(m.role, content, m.images))
        }
        val maxTokens = maxOf(request.maxTokens, TOOL_MAX_TOKENS)
        val temp = request.temperature.toDouble()
        val imageMarkers = mutableListOf<String>()
        val emitted = StringBuilder()
        var streamed = false
        var needSeparator = false
        var downgraded = false

        suspend fun emitPiece(piece: String) {
            if (needSeparator) { needSeparator = false; emitted.append("\n\n"); onPiece("\n\n") }
            streamed = true
            emitted.append(piece)
            onPiece(piece)
        }

        for (round in 0 until MAX_TOOL_ROUNDS) {
            val turn: OpenAICompatibleProvider.ToolTurn = try {
                remote.chatStream(msgs, specs, maxTokens, temp) { emitPiece(it) }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                val msg = e.message ?: e.javaClass.simpleName
                Log.w("AuroraAgent", "function calling falhou: $msg")
                // HTTP 400 costuma ser o esquema de alguma ferramenta do celular que o Gemini não aceitou:
                // tenta de novo só com as ferramentas próprias (internet, memória, imagem, arquivos…).
                if (!downgraded && !streamed && msg.contains("HTTP 400")) {
                    downgraded = true
                    val own = JSONArray()
                    val ownNames = tools.ownToolNames()
                    for (i in 0 until specs.length()) {
                        val n = specs.optJSONObject(i)?.optJSONObject("function")?.optString("name").orEmpty()
                        if (n in ownNames) own.put(specs.getJSONObject(i))
                    }
                    specs = own
                    try {
                        remote.chatStream(msgs, specs, maxTokens, temp) { emitPiece(it) }
                    } catch (e2: kotlinx.coroutines.CancellationException) {
                        throw e2
                    } catch (e2: Exception) {
                        return LoopResult.Failed(e2.message ?: e2.javaClass.simpleName, streamed)
                    }
                } else return LoopResult.Failed(msg, streamed)
            }
            if (turn.calls.isEmpty()) {
                if (turn.text.isBlank() && imageMarkers.isEmpty() && !streamed) return LoopResult.Failed("o modelo respondeu vazio", false)
                val missing = imageMarkers.distinct().filter { it !in emitted }
                if (missing.isNotEmpty()) emitPiece((if (emitted.isNotBlank()) "\n\n" else "") + missing.joinToString("\n"))
                return LoopResult.Done
            }
            if (turn.text.isNotBlank()) needSeparator = true
            msgs.put(turn.raw ?: JSONObject().put("role", "assistant").put("content", JSONObject.NULL))
            for (c in turn.calls) {
                when (val r = tools.executeModelTool(c.name, c.args)) {
                    is ModelToolResult.Confirm -> { emitPiece(r.prompt); return LoopResult.Done }
                    is ModelToolResult.Output -> {
                        IMG_RE.findAll(r.text).forEach { imageMarkers += it.value }
                        msgs.put(
                            JSONObject().put("role", "tool").put("tool_call_id", c.id).put("name", c.name)
                                .put("content", r.text.replace(IMG_RE, "(imagem já exibida ao usuário)").take(TOOL_RESULT_CHARS))
                        )
                    }
                }
            }
            // Imagens/páginas de arquivos lidos por read_file: entregues ao modelo depois de TODAS as respostas de ferramenta.
            val fileImages = tools.takePendingImages()
            if (fileImages.isNotEmpty()) {
                msgs.put(ChatJson.message("user", "Estas são as páginas/imagens do arquivo que você acabou de ler. Leia-as para responder.", fileImages))
            }
        }
        // Estourou as rodadas: pede a resposta final sem ferramentas, com o que já foi coletado.
        return try {
            remote.chatStream(msgs, JSONArray(), maxTokens, temp) { emitPiece(it) }
            LoopResult.Done
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            LoopResult.Failed(e.message ?: e.javaClass.simpleName, streamed)
        }
    }

    fun cancel() = models.cancel()

    /** Orçamento por caracteres (aproximação); um tokenizador real virá com o llama.cpp. */
    private fun trimHistory(history: List<ChatMessage>, budget: Int): List<ChatMessage> {
        if (budget <= 0) return emptyList()
        var used = 0
        val kept = ArrayDeque<ChatMessage>()
        for (m in history.asReversed()) {
            if (used + m.content.length > budget) break
            used += m.content.length
            kept.addFirst(m)
        }
        return kept.toList()
    }

    /** Anexos grandes (até 30 mil caracteres) não cabem no contexto: mantém começo e fim e avisa o modelo. */
    private fun fitUserText(text: String, budget: Int): String {
        if (text.length <= budget) return text
        val head = (budget * 0.65).toInt()
        val tail = budget - head - TRUNCATION_NOTE.length
        if (tail <= 0) return text.take(budget)
        return text.take(head) + TRUNCATION_NOTE + text.takeLast(tail)
    }

    private fun nowText(): String =
        ZonedDateTime.now().format(
            DateTimeFormatter.ofPattern("EEEE, dd/MM/yyyy HH:mm", Locale.forLanguageTag("pt-BR"))
        )

    private companion object {
        const val MAX_TOOL_ROUNDS = 6
        const val TOOL_MAX_TOKENS = 2048 // o "pensamento" do Gemini conta no limite; abaixo disso a resposta pode vir vazia
        const val TOOL_RESULT_CHARS = 20_000
        val IMG_RE = Regex("\\[\\[img:[^\\]]+\\]\\]")
        const val TOOL_HINT = "\n\nDepois de receber os resultados das ferramentas, responda ao usuário em português, de forma curta e natural."
        const val LOCAL_MAX_TOKENS = 450
        const val LOCAL_TOOL_CHARS = 1500
        const val REMOTE_TOOL_CHARS = 8000
        const val MAX_HISTORY_CHARS = 3200
        const val REMOTE_PROMPT_CHARS = 60_000
        const val REMOTE_HISTORY_CHARS = 6000
        const val MIN_USER_CHARS = 1200
        const val TRUNCATION_NOTE = "\n[…trecho central omitido por limite de contexto…]\n"
    }
}
