package com.aurora.core.bible

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject

data class DailyWord(val reference: String, val text: String, val source: String)

object DailyWordService {
    private const val PREFS = "aurora_daily_word"
    private const val KEY_REF = "reference"
    private const val KEY_TEXT = "text"
    private const val KEY_SOURCE = "source"
    // BibleGateway VOTD service. NVI-PT is the Brazilian Portuguese translation.
    private const val URL_VOTD = "https://www.biblegateway.com/votd/get/?format=json&version=NVI-PT"

    fun cached(context: Context): DailyWord? = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).let { p ->
        val text = p.getString(KEY_TEXT, null) ?: return@let null
        DailyWord(
            p.getString(KEY_REF, "Palavra do dia") ?: "Palavra do dia",
            text,
            p.getString(KEY_SOURCE, "BibleGateway · NVI-PT") ?: "BibleGateway · NVI-PT"
        )
    }

    suspend fun fetchAndCache(context: Context): Result<DailyWord> = withContext(Dispatchers.IO) {
        runCatching {
            val c = (URL(URL_VOTD).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 10_000
                readTimeout = 15_000
                instanceFollowRedirects = true
                setRequestProperty("Accept", "application/json")
                setRequestProperty("Accept-Language", "pt-BR,pt;q=0.9")
                setRequestProperty("User-Agent", "Aurora/0.1 (BibleGateway VOTD)")
            }
            try {
                require(c.responseCode in 200..299) { "Bíblia indisponível (${c.responseCode})" }
                val raw = c.inputStream.bufferedReader().use { it.readText() }
                val root = JSONObject(raw)
                // O BibleGateway devolve {"votd": {...}}; aceita também o formato sem envelope.
                val json = root.optJSONObject("votd") ?: root
                val reference = firstNonBlank(
                    json.optString("display_ref"),
                    json.optString("reference"),
                    json.optString("title"),
                    json.optString("verse"),
                    "Palavra do dia"
                )
                val html = firstNonBlank(json.optString("text"), json.optString("content"), "")
                val clean = android.text.Html.fromHtml(html, android.text.Html.FROM_HTML_MODE_LEGACY)
                    .toString()
                    .replace('\u00A0', ' ')
                    .replace(Regex("\\s+"), " ")
                    .trim()
                require(clean.isNotBlank()) { "O site não retornou o texto da Palavra do Dia." }
                DailyWord(reference, clean, "BibleGateway · NVI-PT").also { word ->
                    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                        .putString(KEY_REF, word.reference)
                        .putString(KEY_TEXT, word.text)
                        .putString(KEY_SOURCE, word.source)
                        .apply()
                }
            } finally {
                c.disconnect()
            }
        }
    }

    private fun firstNonBlank(vararg values: String): String = values.firstOrNull { it.isNotBlank() }.orEmpty()
}
