# Privacidade

- Conversas e memórias ficam no Room privado da aplicação.
- Modelos ficam no armazenamento privado da aplicação.
- `allowBackup=false` evita backup automático do conteúdo privado.
- Chaves remotas usam Android Keystore + AES/GCM.
- Endpoint remoto é opcional e vazio por padrão.
- Tráfego HTTP claro é bloqueado, exceto loopback para servidores locais no aparelho.
- O runtime local não precisa de internet depois que o APK, o modelo e os componentes opcionais necessários estiverem instalados.
