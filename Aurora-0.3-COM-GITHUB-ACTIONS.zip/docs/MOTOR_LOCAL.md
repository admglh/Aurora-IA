# Motor local

A Aurora usa `dev.ffmpegkit-maintained:llama-android:0.1.1`, um AAR pré-compilado de llama.cpp para Android arm64-v8a.

O aplicativo importa GGUF para seu armazenamento privado, valida o cabeçalho e passa o caminho do arquivo ao runtime.

A versão gratuita do AAR expõe completion e embeddings, mas não streaming de tokens. Por isso a implementação atual não promete streaming falso.

Se outro runtime com streaming real for escolhido, ele pode entrar como uma nova implementação de `ModelProvider`.
