package com.aurora.core.tools

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Dados da internet SEM chave de API (verificado em 2026):
 *  - Open-Meteo: geocodificação + clima
 *  - Frankfurter: câmbio (Banco Central Europeu)
 *  - Wikipédia (REST): resumos
 *  - Google Notícias (RSS): manchetes
 * Cada função devolve texto pronto para o modelo ler (ou lança exceção com a causa).
 */
object WebData {
    private const val UA = "Aurora/0.3 (assistente pessoal Android)"

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private suspend fun get(url: String, timeoutMs: Int = 15_000): String = withContext(Dispatchers.IO) {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = timeoutMs
            conn.readTimeout = timeoutMs
            conn.instanceFollowRedirects = true
            conn.setRequestProperty("User-Agent", UA)
            conn.setRequestProperty("Accept", "application/json, application/xml, text/xml, */*")
            val code = conn.responseCode
            if (code !in 200..299) error("HTTP $code em ${URL(url).host}")
            conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    private val WEATHER_CODES = mapOf(
        0 to "céu limpo", 1 to "quase limpo", 2 to "parcialmente nublado", 3 to "nublado", 45 to "neblina", 48 to "neblina com geada",
        51 to "garoa fraca", 53 to "garoa", 55 to "garoa forte", 61 to "chuva fraca", 63 to "chuva", 65 to "chuva forte",
        71 to "neve fraca", 73 to "neve", 75 to "neve forte", 80 to "pancadas de chuva fracas", 81 to "pancadas de chuva",
        82 to "pancadas de chuva fortes", 95 to "tempestade", 96 to "tempestade com granizo", 99 to "tempestade com granizo forte"
    )

    suspend fun weather(city: String): String {
        val name = city.trim()
        require(name.isNotEmpty()) { "Faltou o nome da cidade." }
        val geo = JSONObject(get("https://geocoding-api.open-meteo.com/v1/search?name=${enc(name)}&count=1&language=pt&format=json"))
        val place = geo.optJSONArray("results")?.optJSONObject(0) ?: error("Não achei a cidade \"$name\".")
        val lat = place.getDouble("latitude")
        val lon = place.getDouble("longitude")
        val label = listOf(place.optString("name"), place.optString("admin1"), place.optString("country")).filter { it.isNotBlank() }.joinToString(", ")
        val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
            "&current=temperature_2m,apparent_temperature,relative_humidity_2m,precipitation,weather_code,wind_speed_10m" +
            "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
            "&timezone=auto&forecast_days=3"
        val w = JSONObject(get(url))
        val cur = w.getJSONObject("current")
        val d = w.getJSONObject("daily")
        fun codeText(c: Int) = WEATHER_CODES[c] ?: "tempo variável"
        return buildString {
            append("Clima em $label (Open-Meteo)\n")
            append("Agora: ${cur.getDouble("temperature_2m").toInt()}°C (sensação ${cur.getDouble("apparent_temperature").toInt()}°C), ")
            append("${codeText(cur.getInt("weather_code"))}, umidade ${cur.getInt("relative_humidity_2m")}%, vento ${cur.getDouble("wind_speed_10m").toInt()} km/h.\n")
            val days = d.getJSONArray("time")
            val labels = listOf("Hoje", "Amanhã", "Depois de amanhã")
            for (i in 0 until minOf(days.length(), 3)) {
                append("${labels[i]}: ${d.getJSONArray("temperature_2m_min").getDouble(i).toInt()}° a ${d.getJSONArray("temperature_2m_max").getDouble(i).toInt()}°C, ")
                append("${codeText(d.getJSONArray("weather_code").getInt(i))}, chance de chuva ${d.getJSONArray("precipitation_probability_max").optInt(i)}%.\n")
            }
        }.trim()
    }

    suspend fun currency(amount: Double, from: String, to: String): String {
        val f = from.trim().uppercase().take(3)
        val t = to.trim().uppercase().take(3)
        require(f.length == 3 && t.length == 3) { "Use códigos de moeda como USD, EUR, BRL." }
        val j = JSONObject(get("https://api.frankfurter.dev/v1/latest?amount=$amount&base=$f&symbols=$t"))
        val value = j.getJSONObject("rates").getDouble(t)
        return "%.2f %s = %.2f %s (câmbio do Banco Central Europeu em %s)".format(amount, f, value, t, j.optString("date"))
    }

    suspend fun wikipedia(term: String): String {
        val q = term.trim()
        require(q.isNotEmpty()) { "Faltou o termo." }
        // Busca o título certo primeiro (tolera erros de digitação), depois pega o resumo.
        val search = JSONArray(get("https://pt.wikipedia.org/w/api.php?action=opensearch&search=${enc(q)}&limit=1&format=json"))
        val title = search.optJSONArray(1)?.optString(0).orEmpty().ifBlank { q }
        val s = JSONObject(get("https://pt.wikipedia.org/api/rest_v1/page/summary/${enc(title.replace(' ', '_')).replace("+", "%20")}"))
        val extract = s.optString("extract")
        if (extract.isBlank()) error("Sem verbete para \"$q\".")
        return "Wikipédia — ${s.optString("title")}: ${extract.take(1800)}"
    }

    suspend fun news(topic: String, max: Int = 6): String {
        val t = topic.trim()
        val url = if (t.isEmpty()) "https://news.google.com/rss?hl=pt-BR&gl=BR&ceid=BR:pt-419"
        else "https://news.google.com/rss/search?q=${enc(t)}&hl=pt-BR&gl=BR&ceid=BR:pt-419"
        val xml = get(url, 20_000)
        val items = Regex("<item>(.*?)</item>", RegexOption.DOT_MATCHES_ALL).findAll(xml).take(max).toList()
        if (items.isEmpty()) error("Nenhuma notícia encontrada.")
        return buildString {
            append("Manchetes${if (t.isNotEmpty()) " sobre $t" else ""} (Google Notícias):\n")
            items.forEachIndexed { i, m ->
                val block = m.groupValues[1]
                fun tag(n: String) = Regex("<$n>(.*?)</$n>", RegexOption.DOT_MATCHES_ALL).find(block)?.groupValues?.get(1)
                    ?.replace("<![CDATA[", "")?.replace("]]>", "")?.replace("&amp;", "&")?.replace("&quot;", "\"")?.replace("&#39;", "'")?.trim().orEmpty()
                append("${i + 1}. ${tag("title")} — ${tag("pubDate").take(22)}\n")
            }
        }.trim()
    }

    /** Calculadora segura (sem eval de código): + - * / ^ % ( ) e funções sqrt, sin, cos, tan, log, ln, abs. */
    fun calculate(expr: String): String {
        val parser = ExprParser(expr.lowercase().replace(",", ".").replace("×", "*").replace("÷", "/").replace("x", "*"))
        val v = parser.parse()
        val shown = if (v == Math.floor(v) && Math.abs(v) < 1e15) v.toLong().toString() else "%.10g".format(v).trimEnd('0').trimEnd('.')
        return "$expr = $shown"
    }

    private class ExprParser(private val s: String) {
        private var pos = 0
        fun parse(): Double { val v = expr(); skip(); if (pos < s.length) error("Expressão inválida perto de \"${s.substring(pos)}\""); return v }
        private fun skip() { while (pos < s.length && s[pos] == ' ') pos++ }
        private fun eat(c: Char): Boolean { skip(); if (pos < s.length && s[pos] == c) { pos++; return true }; return false }
        private fun expr(): Double { var v = term(); while (true) { v = if (eat('+')) v + term() else if (eat('-')) v - term() else return v } }
        private fun term(): Double {
            var v = pow()
            while (true) {
                v = if (eat('*')) v * pow() else if (eat('/')) { val d = pow(); if (d == 0.0) error("Divisão por zero."); v / d }
                else if (eat('%')) v % pow() else return v
            }
        }
        private fun pow(): Double { val b = unary(); return if (eat('^')) Math.pow(b, pow()) else b }
        private fun unary(): Double = if (eat('-')) -unary() else if (eat('+')) unary() else atom()
        private fun atom(): Double {
            skip()
            if (eat('(')) { val v = expr(); if (!eat(')')) error("Faltou fechar parêntese."); return v }
            val start = pos
            if (pos < s.length && (s[pos].isDigit() || s[pos] == '.')) {
                while (pos < s.length && (s[pos].isDigit() || s[pos] == '.')) pos++
                return s.substring(start, pos).toDoubleOrNull() ?: error("Número inválido.")
            }
            while (pos < s.length && s[pos].isLetter()) pos++
            val name = s.substring(start, pos)
            if (name.isEmpty()) error("Expressão inválida.")
            if (name == "pi") return Math.PI
            if (name == "e") return Math.E
            if (!eat('(')) error("Função \"$name\" sem parênteses.")
            val a = expr()
            if (!eat(')')) error("Faltou fechar parêntese.")
            return when (name) {
                "sqrt", "raiz" -> Math.sqrt(a); "sin" -> Math.sin(Math.toRadians(a)); "cos" -> Math.cos(Math.toRadians(a))
                "tan" -> Math.tan(Math.toRadians(a)); "log" -> Math.log10(a); "ln" -> Math.log(a); "abs" -> Math.abs(a)
                else -> error("Função desconhecida: $name")
            }
        }
    }

    /** Usado pelo resumo matinal: junta clima + manchetes sem passar pelo modelo. */
    suspend fun plainBrief(city: String, topics: String): String {
        val parts = mutableListOf<String>()
        if (city.isNotBlank()) runCatching { weather(city) }.onSuccess { parts += it }
        val topic = topics.split(',').firstOrNull { it.isNotBlank() }.orEmpty()
        runCatching { news(topic, 4) }.onSuccess { parts += it }
        return parts.joinToString("\n\n")
    }
}
