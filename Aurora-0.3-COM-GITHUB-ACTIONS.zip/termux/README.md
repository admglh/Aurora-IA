# Aurora Nova • Termux Runtime

Este diretório incorpora o backend Termux do pacote Aurora Nova básico ao projeto Android.

## Iniciar
```bash
./iniciar.sh
```
Abra `http://127.0.0.1:8081` no navegador.

## Diagnóstico
```bash
./diagnostico.sh
```

## Parar
```bash
./parar.sh
```

Os modelos pesados não ficam dentro do ZIP. O runtime usa `/storage/emulated/0/Download/Aurora`.
O chat usa `llama-cli --single-turn --simple-io`, evitando o modo interativo que causou problemas na versão anterior.
