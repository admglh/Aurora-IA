package com.aurora.core.tools

import android.content.Context
import android.net.Uri
import android.util.Base64
import com.aurora.core.agent.SemanticMemory
import com.aurora.core.database.MemoryDao
import com.aurora.core.database.MemoryEntity
import com.aurora.core.files.DocReader
import com.aurora.core.files.FileFinder
import com.aurora.core.model.CloudUrls
import com.aurora.core.routine.Routines
import com.aurora.core.settings.AuroraSettings
import com.aurora.core.settings.SecretStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Ferramentas próprias da Aurora, oferecidas ao modelo via function calling. Todas são LEITURA, aprendizado
 * ou criação de coisas privadas do app (imagem, lembrete). Ações no celular continuam exigindo "sim"
 * (ver [AndroidToolRegistry]).
 *
 *  internet:   web_search, web_fetch, wikipedia, get_news, get_weather, convert_currency, calculate
 *  aprender:   save_memory
 *  criar:      generate_image, remind_me, list_reminders, cancel_reminder
 *  arquivos:   find_files, read_file (somente nas pastas que o usuário liberou)
 */
class BuiltinTools(
    private val context: Context,
    private val memories: MemoryDao,
    private val semantic: SemanticMemory,
    private val settings: AuroraSettings,
    private val secrets: SecretStore,
    private val finder: FileFinder
) {
    private val search = WebSearchTool()
    private val fetch = WebFetchTool()
    private val pendingImages = mutableListOf<String>()

    val names: Set<String> = setOf(
        "web_search", "web_fetch", "wikipedia", "get_news", "get_weather", "convert_currency", "calculate",
        "save_memory", "generate_image", "remind_me", "list_reminders", "cancel_reminder", "find_files", "read_file"
    )

    /** Imagens (páginas de PDF, fotos) lidas por read_file; o agente as entrega ao modelo na rodada seguinte. */
    fun takePendingImages(): List<String> = synchronized(pendingImages) { pendingImages.toList().also { pendingImages.clear() } }

    private fun fn(name: String, description: String, props: JSONObject, required: List<String>): JSONObject {
        val params = JSONObject().put("type", "object").put("properties", props)
        if (required.isNotEmpty()) params.put("required", JSONArray(required))
        return JSONObject().put("type", "function").put(
            "function", JSONObject().put("name", name).put("description", description).put("parameters", params)
        )
    }

    private fun fnNoArgs(name: String, description: String): JSONObject =
        JSONObject().put("type", "function").put("function", JSONObject().put("name", name).put("description", description))

    private fun str(desc: String) = JSONObject().put("type", "string").put("description", desc)
    private fun num(desc: String) = JSONObject().put("type", "number").put("description", desc)
    private fun int(desc: String) = JSONObject().put("type", "integer").put("description", desc)

    fun specs(): List<JSONObject> = listOf(
        fn("web_search", "Pesquisa na internet (títulos, links, trechos). Use para informação atual ou que você não saiba.",
            JSONObject().put("query", str("O que pesquisar, curto e específico.")), listOf("query")),
        fn("web_fetch", "Abre uma página (URL https:// completa) e devolve o texto principal. Use depois de web_search.",
            JSONObject().put("url", str("URL completa.")), listOf("url")),
        fn("wikipedia", "Resumo da Wikipédia em português sobre uma pessoa, lugar, conceito ou fato.",
            JSONObject().put("term", str("Termo a consultar.")), listOf("term")),
        fn("get_news", "Manchetes recentes (Google Notícias, Brasil). Deixe o assunto vazio para as principais do dia.",
            JSONObject().put("topic", str("Assunto (opcional).")), emptyList()),
        fn("get_weather", "Clima agora e previsão de 3 dias de uma cidade.",
            JSONObject().put("city", str("Nome da cidade.")), listOf("city")),
        fn("convert_currency", "Converte valores entre moedas (USD, EUR, BRL, GBP, JPY…) com câmbio do Banco Central Europeu.",
            JSONObject().put("amount", num("Valor.")).put("from", str("Moeda de origem, ex.: USD.")).put("to", str("Moeda de destino, ex.: BRL.")),
            listOf("amount", "from", "to")),
        fn("calculate", "Calculadora exata: + - * / ^ % ( ) e sqrt, sin, cos, tan, log, ln, abs. Use para qualquer conta.",
            JSONObject().put("expression", str("Expressão, ex.: (12*8)/3")), listOf("expression")),
        fn("save_memory", "APRENDER: grava na memória permanente um fato sobre o usuário ou algo útil que aprendeu. Frase curta e autossuficiente.",
            JSONObject().put("content", str("A frase a lembrar.")).put("kind", str("usuario, aprendido, preferencia ou tarefa.")), listOf("content")),
        fn("generate_image", "Cria uma imagem e mostra no chat. Escreva o prompt em inglês, detalhado (estilo, luz, composição).",
            JSONObject().put("prompt", str("Descrição detalhada, de preferência em inglês.")), listOf("prompt")),
        fn("remind_me", "Agenda um lembrete com notificação. Informe in_minutes (a partir de agora) OU at (data e hora local no formato yyyy-MM-dd HH:mm).",
            JSONObject().put("text", str("O que lembrar.")).put("in_minutes", int("Minutos a partir de agora.")).put("at", str("yyyy-MM-dd HH:mm")), listOf("text")),
        fnNoArgs("list_reminders", "Lista os lembretes pendentes."),
        fn("cancel_reminder", "Cancela um lembrete pelo id (veja list_reminders).",
            JSONObject().put("id", int("Id do lembrete.")), listOf("id")),
        fn("find_files", "Procura arquivos do usuário (PDF, DOCX, fotos, textos…) nas pastas que ele liberou. Devolve nome e uri.",
            JSONObject().put("query", str("Palavras do nome do arquivo (pode ficar vazio).")).put("type", str("pdf, docx, imagem, texto ou uma extensão (opcional).")), emptyList()),
        fn("read_file", "Lê um arquivo achado com find_files (texto, DOCX, PDF e imagens; PDFs e fotos são mostrados a você em seguida).",
            JSONObject().put("uri", str("O uri devolvido por find_files.")), listOf("uri"))
    )

    suspend fun run(name: String, args: Map<String, Any?>): String {
        fun s(k: String) = args[k]?.toString().orEmpty().trim()
        fun n(k: String): Double? = (args[k] as? Number)?.toDouble() ?: args[k]?.toString()?.replace(",", ".")?.toDoubleOrNull()
        return try {
            when (name) {
                "web_search" -> s("query").ifBlank { return "falhou: faltou o texto da pesquisa." }.let { search.search(it).getOrElse { e -> "falhou: ${e.message ?: e.javaClass.simpleName}" } }
                "web_fetch" -> s("url").ifBlank { return "falhou: faltou a URL." }.let { fetch.fetch(it).getOrElse { e -> "falhou: ${e.message ?: e.javaClass.simpleName}" } }
                "wikipedia" -> WebData.wikipedia(s("term"))
                "get_news" -> WebData.news(s("topic"))
                "get_weather" -> WebData.weather(s("city"))
                "convert_currency" -> WebData.currency(n("amount") ?: return "falhou: faltou o valor.", s("from"), s("to"))
                "calculate" -> WebData.calculate(s("expression"))
                "save_memory" -> saveMemory(s("content"), s("kind"))
                "generate_image" -> generateImage(s("prompt"))
                "remind_me" -> remind(s("text"), n("in_minutes")?.toLong(), s("at"))
                "list_reminders" -> listReminders()
                "cancel_reminder" -> { Routines.cancelReminder(context, settings, (n("id") ?: return "falhou: faltou o id.").toInt()); "lembrete cancelado." }
                "find_files" -> findFiles(s("query"), s("type"))
                "read_file" -> readFile(s("uri"))
                else -> "falhou: ferramenta desconhecida $name."
            }
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            "falhou: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    // ---------------- aprender ----------------

    private suspend fun saveMemory(content: String, kind: String): String {
        val clean = content.trim()
        if (clean.length < 3) return "falhou: conteúdo vazio."
        if (memories.all().any { it.content.equals(clean, ignoreCase = true) }) return "já estava na memória."
        val now = System.currentTimeMillis()
        val entity = MemoryEntity(content = clean.take(600), kind = kind.ifBlank { "aprendido" }.take(30), source = "aurora", createdAt = now, updatedAt = now)
        val id = memories.insert(entity)
        runCatching { semantic.index(entity.copy(id = id)) }
        return "memorizado (aparece em Memória e pode ser apagado)."
    }

    // ---------------- lembretes ----------------

    private fun remind(text: String, inMinutes: Long?, at: String): String {
        if (text.isBlank()) return "falhou: faltou o que lembrar."
        val whenMs = when {
            inMinutes != null && inMinutes > 0 -> System.currentTimeMillis() + inMinutes * 60_000
            at.isNotBlank() -> runCatching { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).parse(at)?.time }.getOrNull()
                ?: return "falhou: data inválida, use yyyy-MM-dd HH:mm."
            else -> return "falhou: informe in_minutes ou at."
        }
        if (whenMs <= System.currentTimeMillis()) return "falhou: esse horário já passou."
        val r = Routines.addReminder(context, settings, whenMs, text)
        return "lembrete #${r.id} agendado para " + SimpleDateFormat("dd/MM HH:mm", Locale("pt", "BR")).format(Date(r.at)) + "."
    }

    private fun listReminders(): String {
        val list = Routines.reminders(settings).sortedBy { it.at }
        if (list.isEmpty()) return "nenhum lembrete pendente."
        val f = SimpleDateFormat("dd/MM HH:mm", Locale("pt", "BR"))
        return list.joinToString("\n") { "#${it.id} ${f.format(Date(it.at))} — ${it.text}" }
    }

    // ---------------- arquivos ----------------

    private suspend fun findFiles(query: String, type: String): String {
        if (finder.folders().isEmpty()) return "falhou: o usuário ainda não liberou nenhuma pasta. Peça para abrir Ajustes → Arquivos e escolher uma pasta (ex.: Download)."
        val found = finder.search(query, type)
        if (found.isEmpty()) return "nenhum arquivo encontrado nas pastas liberadas."
        val f = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR"))
        return found.joinToString("\n") { "• ${it.name} (${it.folder}, ${f.format(Date(it.modified))}) uri=${it.uri}" }
    }

    private suspend fun readFile(uriText: String): String {
        val uri = runCatching { Uri.parse(uriText) }.getOrNull() ?: return "falhou: uri inválido."
        // Só lê dentro das pastas liberadas pelo usuário.
        val allowed = finder.folders().any { uri.toString().startsWith(it.toString()) }
        if (!allowed) return "falhou: esse arquivo não está nas pastas liberadas."
        val doc = DocReader.read(context, uri)
        if (doc.kind == "erro" || doc.kind == "desconhecido") return "falhou: ${doc.note}"
        if (doc.images.isNotEmpty()) synchronized(pendingImages) { pendingImages.addAll(doc.images) }
        return buildString {
            append("arquivo \"${doc.name}\" (${doc.kind}). ${doc.note}".trim())
            if (doc.text.isNotBlank()) append("\n\n").append(doc.text.take(MAX_FILE_CHARS))
            if (doc.images.isNotEmpty()) append("\n\n(${doc.images.size} imagem(ns) do arquivo serão mostradas a você na próxima mensagem; leia-as.)")
        }
    }

    // ---------------- imagem ----------------

    private suspend fun generateImage(prompt: String): String = withContext(Dispatchers.IO) {
        val p = prompt.trim()
        if (p.isBlank()) return@withContext "falhou: faltou a descrição da imagem."
        val dir = File(context.filesDir, "images").apply { mkdirs() }
        // 1) Gemini (mesma chave/Worker, grátis até o limite diário da sua conta)
        val viaWorker = runCatching { imageViaWorker(p, dir) }.getOrNull()
        if (viaWorker != null) return@withContext "imagem criada: [[img:${viaWorker.absolutePath}]]"
        // 2) Pollinations (grátis, sem chave; anônimo = 1 pedido a cada ~15 s)
        val viaPollinations = runCatching { imagePollinations(p, dir) }.getOrNull()
        if (viaPollinations != null) return@withContext "imagem criada: [[img:${viaPollinations.absolutePath}]]"
        "falhou: os serviços gratuitos de imagem não responderam agora. Tente de novo em alguns instantes."
    }

    private fun imageViaWorker(prompt: String, dir: File): File? {
        val endpoint = settings.remoteEndpoint
        if (endpoint.isBlank()) return null
        val conn = URL(CloudUrls.image(endpoint)).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15_000
            conn.readTimeout = 120_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            secrets.get(SecretStore.KEY_REMOTE_API)?.trim()?.takeIf { it.isNotBlank() }?.let { conn.setRequestProperty("Authorization", "Bearer $it") }
            conn.outputStream.use { it.write(JSONObject().put("prompt", prompt).toString().toByteArray(Charsets.UTF_8)) }
            if (conn.responseCode !in 200..299) return null
            val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            val bytes = Base64.decode(json.getString("image"), Base64.DEFAULT)
            if (bytes.size < 2_000) return null
            val ext = if (json.optString("mime").contains("jpeg")) "jpg" else "png"
            return File(dir, "aurora-${System.currentTimeMillis()}.$ext").also { it.writeBytes(bytes) }
        } finally {
            conn.disconnect()
        }
    }

    private suspend fun imagePollinations(prompt: String, dir: File): File? {
        val seed = (System.currentTimeMillis() % 1_000_000).toInt()
        val url = "https://image.pollinations.ai/prompt/" + URLEncoder.encode(prompt.take(900), "UTF-8").replace("+", "%20") +
            "?width=1024&height=1024&seed=$seed&nologo=true&model=flux"
        repeat(2) { attempt ->
            val conn = URL(url).openConnection() as HttpURLConnection
            try {
                conn.connectTimeout = 20_000
                conn.readTimeout = 120_000
                conn.instanceFollowRedirects = true
                conn.setRequestProperty("User-Agent", "Aurora/0.3")
                val code = conn.responseCode
                if (code in 200..299) {
                    val bytes = conn.inputStream.use { it.readBytes() }
                    if (bytes.size > 2_000 && (conn.contentType.orEmpty().startsWith("image") || conn.contentType == null)) {
                        return File(dir, "aurora-${System.currentTimeMillis()}.jpg").also { it.writeBytes(bytes) }
                    }
                } else if (code == 429 && attempt == 0) {
                    delay(16_000) // limite anônimo: 1 pedido a cada ~15 s
                    return@repeat
                }
            } finally {
                conn.disconnect()
            }
            if (attempt == 0) delay(1_500)
        }
        return null
    }

    private companion object { const val MAX_FILE_CHARS = 20_000 }
}
