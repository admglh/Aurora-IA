#!/data/data/com.termux/files/usr/bin/bash
BASE="/storage/emulated/0/Download/Aurora"

echo
echo "===== RECURSOS AURORA ====="
echo

if [ ! -d "$BASE" ]; then
    echo "Pasta não encontrada: $BASE"
    exit 0
fi

find "$BASE" -type f \
  \( -iname "*.gguf" -o -iname "*.onnx" -o -iname "*.bin" -o -iname "*.zip" \) \
  -print

echo
echo "TOTAL:"
find "$BASE" -type f \
  \( -iname "*.gguf" -o -iname "*.onnx" -o -iname "*.bin" -o -iname "*.zip" \) \
  | wc -l
