#!/data/data/com.termux/files/usr/bin/bash
set +e
BASE="$(cd "$(dirname "$0")" && pwd)"
ASSETS="${AURORA_ASSET_ROOT:-/storage/emulated/0/Download/Aurora}"
echo "=== AURORA NOVA: DIAGNÓSTICO ==="
echo "Projeto: $BASE"
echo "Recursos: $ASSETS"
command -v llama-cli >/dev/null && echo "OK  llama-cli" || echo "FALT llama-cli"
python --version
for f in  "Modelos/Qwen3-1.7B-Q8_0.gguf"  "Visão/Qwen2.5-VL-3B-Instruct-Q4_K_M.gguf"  "Visão/mmproj-Qwen2.5-VL-3B-Instruct-Q8_0.gguf"  "Memória/bge-m3-Q4_K_M.gguf"  "Memória/bge-reranker-v2-m3-q4_k.gguf"  "Voz/Whisper/ggml-base-q8_0.bin"  "Voz/VAD/silero_vad.onnx"  "Voz/TTS/Kokoro/model.onnx"  "Voz/TTS/Kokoro/voices.bin"; do
  [ -f "$ASSETS/$f" ] && echo "OK  $f" || echo "FALT $f"
done
curl -s --max-time 3 http://127.0.0.1:8081/api/health || true
