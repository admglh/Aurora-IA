#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
BASE="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$BASE/data/logs"
if [ -f "$BASE/data/logs/server.pid" ] && kill -0 "$(cat "$BASE/data/logs/server.pid")" 2>/dev/null; then
  echo "Aurora Termux já está rodando: http://127.0.0.1:8081"; exit 0
fi
nohup python "$BASE/app/backend/server.py" >"$BASE/data/logs/server.log" 2>&1 &
echo $! > "$BASE/data/logs/server.pid"
sleep 1
echo "Aurora Termux iniciada: http://127.0.0.1:8081"
