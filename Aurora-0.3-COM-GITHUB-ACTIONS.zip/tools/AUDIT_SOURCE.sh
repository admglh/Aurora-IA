#!/data/data/com.termux/files/usr/bin/bash
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
fail=0
ok(){ printf '[OK] %s\n' "$1"; }
bad(){ printf '[FALHA] %s\n' "$1"; fail=1; }
contains(){ grep -R -q -- "$2" "$1" 2>/dev/null; }

# API real do droid-mcp, não reflexão em singleton inexistente.
contains "$ROOT/app/src/main/java/com/aurora/core/tools/DroidMcpRuntime.kt" 'DroidMcp.builder()' && ok "DroidMcp usa builder() oficial" || bad "DroidMcp builder()"
contains "$ROOT/app/src/main/java/com/aurora/core/tools/DroidMcpRuntime.kt" '.addTools(' && ok "Módulos droid-mcp registrados pela API oficial" || bad "Módulos droid-mcp"
contains "$ROOT/app/src/main/java/com/aurora/core/tools/DroidMcpRuntime.kt" '.enableHttpServer(context = context' && ok "MCP HTTP configurado com API oficial" || bad "MCP HTTP"
! contains "$ROOT/app/src/main/java/com/aurora/core/tools/DroidMcpRuntime.kt" 'getField("INSTANCE")' && ok "Sem singleton INSTANCE incorreto" || bad "Ainda existe singleton INSTANCE incorreto"

contains "$ROOT/app/src/main/java/com/aurora/core/bible/DailyWordService.kt" 'NVI-PT' && ok "Palavra do Dia NVI-PT" || bad "Palavra do Dia NVI-PT"
contains "$ROOT/app/src/main/java/com/aurora/core/extensions/ExtensionManager.kt" 'aurora-extension.json' && ok "Manifesto de plugin validado" || bad "Manifesto de plugin"
contains "$ROOT/app/src/main/java/com/aurora/core/model/ModelCatalogService.kt" 'huggingface.co/api/models' && ok "Pesquisa online de modelos" || bad "Pesquisa online de modelos"
contains "$ROOT/app/src/main/java/com/aurora/core/tools/WebAndGithubTools.kt" 'api.github.com' && ok "GitHub API" || bad "GitHub API"
contains "$ROOT/app/src/main/java/com/aurora/core/tools/WebAndGithubTools.kt" 'duckduckgo.com/html' && ok "Pesquisa web" || bad "Pesquisa web"
contains "$ROOT/tools/INSTALL_AURORA_MEGA.sh" 'github-mcp-server' && ok "Instalação GitHub MCP pelo Termux" || bad "GitHub MCP Termux"
contains "$ROOT/tools/INSTALL_AURORA_MEGA.sh" 'nodejs' && ok "Pilha MCP Node disponível" || bad "Node MCP"
contains "$ROOT/tools/INSTALL_AURORA_MEGA.sh" 'golang' && ok "Go disponível para GitHub MCP" || bad "Go"
contains "$ROOT/tools/build_apk.sh" 'Aurora-0.3-CORRIGIDA.apk' && ok "Build aponta para 0.3 corrigida" || bad "Build aponta para 0.3 corrigida"
contains "$ROOT/app/build.gradle.kts" 'droid-mcp-shizuku:0.11.0' && ok "Shizuku opt-in incluído" || bad "Shizuku"
contains "$ROOT/app/build.gradle.kts" 'droid-mcp-root:0.11.0' && ok "Root opt-in incluído" || bad "Root"
contains "$ROOT/app/src/main/AndroidManifest.xml" 'largeHeap="true"' && ok "Heap grande habilitado" || bad "Heap grande"

# Regressões prioritárias da versão 0.3 corrigida.
contains "$ROOT/app/src/main/java/com/aurora/AppContainer.kt" 'generationText' && ok "Streaming compartilhado entre Activities" || bad "Streaming compartilhado"
contains "$ROOT/app/src/main/java/com/aurora/ui/AuroraViewModel.kt" 'container.appScope.launch' && ok "Geração não presa ao viewModelScope" || bad "Geração ainda presa à tela"
contains "$ROOT/app/src/main/java/com/aurora/core/agent/AuroraAgent.kt" 'shouldUseTools(typed)' && ok "Ferramentas sob demanda para reduzir latência" || bad "Roteamento de ferramentas"
contains "$ROOT/app/src/main/java/com/aurora/core/model/OpenAICompatibleProvider.kt" 'isTerminalSse(payload)' && ok "Streaming encerra ao receber finish_reason" || bad "Fim de streaming"
contains "$ROOT/app/src/main/java/com/aurora/service/AuroraBubbleService.kt" 'FOREGROUND_SERVICE_TYPE_SPECIAL_USE' && ok "Bolha mantida por foreground service" || bad "Serviço foreground da bolha"
contains "$ROOT/app/src/main/java/com/aurora/AuroraNotifications.kt" 'setAllowBubbles(true)' && ok "Canal de conversa permite bolhas" || bad "Canal de bolhas"
contains "$ROOT/app/src/main/java/com/aurora/AuroraNotifications.kt" 'aurora_notification_avatar' && ok "Foto da Aurora em notificações" || bad "Ícone com foto da Aurora"

# Não permitir que documentação ativa afirme que um recurso está testado quando só foi declarado.
if grep -R -n -E 'Resultado da auditoria estrutural: OK|151 capacidades.*funcionando|build.*100%.*pronto' "$ROOT/docs" --include='*.md' 2>/dev/null; then
  bad "Documentação contém afirmações de runtime não verificadas"
else
  ok "Documentação não declara runtime não testado como verde"
fi

if grep -R -n -E 'Aurora 9\.1|AURORA 9\.1|Aurora-9\.1|45 módulos|versão 9\.1' "$ROOT" --exclude-dir=.gradle --exclude-dir=build --exclude='*.mp4' --exclude='*.jpg' --exclude='*.png' --exclude='*.webp' --exclude='AUDIT_SOURCE.sh' >/tmp/aurora_stale.txt 2>/dev/null; then
  bad "Há referências antigas de 9.1/45 módulos"
  cat /tmp/aurora_stale.txt
else
  ok "Sem referências antigas de 9.1/45 módulos"
fi

printf '\nResultado da auditoria de fonte: %s\n' "$([ "$fail" -eq 0 ] && echo OK || echo FALHA)"
exit "$fail"
