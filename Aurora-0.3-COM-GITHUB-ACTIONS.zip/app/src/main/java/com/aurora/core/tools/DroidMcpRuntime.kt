package com.aurora.core.tools

import android.content.Context
import android.util.Log
import io.droidmcp.alarms.AlarmsTools
import io.droidmcp.apps.AppsTools
import io.droidmcp.audio.AudioTools
import io.droidmcp.accessibility.AccessibilityTools
import io.droidmcp.biometric.BiometricTools
import io.droidmcp.bluetooth.BluetoothTools
import io.droidmcp.calllog.CallLogTools
import io.droidmcp.camera.CameraTools
import io.droidmcp.calendar.CalendarTools
import io.droidmcp.clipboard.ClipboardTools
import io.droidmcp.contacts.ContactsTools
import io.droidmcp.core.DroidMcp
import io.droidmcp.core.McpTool
import io.droidmcp.device.DeviceTools
import io.droidmcp.dnd.DndTools
import io.droidmcp.downloads.DownloadsTools
import io.droidmcp.files.FilesTools
import io.droidmcp.flashlight.FlashlightTools
import io.droidmcp.health.HealthTools
import io.droidmcp.ime.ImeTools
import io.droidmcp.intent.IntentTools
import io.droidmcp.keyguard.KeyguardTools
import io.droidmcp.location.LocationTools
import io.droidmcp.media.MediaTools
import io.droidmcp.mlkit.MlKitTools
import io.droidmcp.network.NetworkTools
import io.droidmcp.nfc.NfcTools
import io.droidmcp.notificationwatch.NotificationWatchTools
import io.droidmcp.notifications.NotificationsTools
import io.droidmcp.notificationsreply.NotificationsReplyTools
import io.droidmcp.overlay.OverlayTools
import io.droidmcp.playback.PlaybackTools
import io.droidmcp.print.PrintTools
import io.droidmcp.qr.QrTools
import io.droidmcp.ringtone.RingtoneTools
import io.droidmcp.screenshot.ScreenshotTools
import io.droidmcp.screen.ScreenTools
import io.droidmcp.sensors.SensorTools
import io.droidmcp.settings.SettingsTools
import io.droidmcp.sms.SmsTools
import io.droidmcp.telephony.TelephonyTools
import io.droidmcp.tts.TtsTools
import io.droidmcp.usb.UsbTools
import io.droidmcp.vibration.VibrationTools
import io.droidmcp.wallpaper.WallpaperTools
import io.droidmcp.web.WebTools
import io.droidmcp.wifi.WifiTools
import io.droidmcp.root.RootTools
import io.droidmcp.shizuku.ShizukuTools
import io.droidmcp.shell.ShellPolicy
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Runtime oficial do droid-mcp 0.11.0.
 *
 * A versão anterior tentava descobrir o SDK por reflexão e procurava um singleton
 * Kotlin inexistente. Aqui usamos a API pública documentada pelo próprio projeto:
 * DroidMcp.builder().addTools(...).build().
 *
 * Os módulos permission-gated só entram no registry quando o Android já concedeu
 * as permissões necessárias; quando não concedidos, continuam visíveis no catálogo
 * da Aurora como indisponíveis até a permissão ser liberada.
 */
class DroidMcpRuntime(private val context: Context) {
    data class Status(
        val loadedModules: List<String>,
        val unavailableModules: List<String>,
        val toolCount: Int,
        val serverRunning: Boolean,
        val serverToken: String?
    )

    @Volatile private var runtime: DroidMcp? = null
    @Volatile private var status = Status(emptyList(), emptyList(), 0, false, null)

    @Synchronized
    fun initialize(): Status {
        runtime?.let { return status.copy(serverRunning = it.isServerRunning(), serverToken = it.serverToken) }

        val tools = mutableListOf<McpTool>()
        val loaded = mutableListOf<String>()
        val unavailable = mutableListOf<String>()

        fun add(name: String, provider: () -> List<McpTool>) {
            runCatching { tools.addAll(provider()); loaded += name }
                .onFailure { unavailable += name; Log.w(TAG, "$name indisponível: ${it.message}") }
        }
        fun addIf(name: String, allowed: Boolean, provider: () -> List<McpTool>) {
            if (allowed) add(name, provider) else unavailable += "$name (permissão/configuração)"
        }

        // Always available / normal permission modules.
        add("device") { DeviceTools.all(context) }
        add("clipboard") { ClipboardTools.all(context) }
        add("apps") { AppsTools.all(context) }
        add("screen") { ScreenTools.all(context) }
        add("tts") { TtsTools.all(context) }
        add("notifications") { NotificationsTools.all(context) }
        add("biometric") { BiometricTools.all(context) }
        add("sensors") { SensorTools.all(context) }
        add("audio") { AudioTools.all(context) }
        add("web") { WebTools.all(context) }
        add("network") { NetworkTools.all(context) }
        add("nfc") { NfcTools.all(context) }
        add("intent") { IntentTools.all(context) }
        add("playback") { PlaybackTools.all(context) }
        add("notification-reply") { NotificationsReplyTools.all(context) }
        add("notification-watch") { NotificationWatchTools.all(context) }
        add("accessibility") { AccessibilityTools.all(context) }
        add("ime") { ImeTools.all(context) }
        add("screenshot") { ScreenshotTools.all(context) }
        add("dnd") { DndTools.all(context) }
        add("keyguard") { KeyguardTools.all(context) }
        add("wallpaper") { WallpaperTools.all(context) }
        add("ringtone") { RingtoneTools.all(context) }
        add("usb") { UsbTools.all(context) }
        add("print") { PrintTools.all(context) { null } }
        add("mlkit") { MlKitTools.all(context) }

        // Runtime permission-gated modules. The droid-mcp sample uses the same hasPermissions/all pattern.
        addIf("calendar", CalendarTools.hasPermissions(context)) { CalendarTools.all(context) }
        addIf("contacts", ContactsTools.hasPermissions(context)) { ContactsTools.all(context) }
        addIf("sms", SmsTools.hasPermissions(context)) { SmsTools.all(context) }
        addIf("files", FilesTools.hasPermissions(context)) { FilesTools.all(context) }
        addIf("calllog", CallLogTools.hasPermissions(context)) { CallLogTools.all(context) }
        addIf("media", MediaTools.hasPermissions(context)) { MediaTools.all(context) }
        addIf("location", LocationTools.hasPermissions(context)) { LocationTools.all(context) }
        addIf("health", HealthTools.hasPermissions(context)) { HealthTools.all(context) }
        addIf("alarms", AlarmsTools.hasPermissions(context)) { AlarmsTools.all(context) }
        addIf("settings", SettingsTools.hasPermissions(context)) { SettingsTools.all(context) }
        addIf("bluetooth", BluetoothTools.hasPermissions(context)) { BluetoothTools.all(context) }
        addIf("wifi", WifiTools.hasPermissions(context)) { WifiTools.all(context) }
        addIf("downloads", DownloadsTools.hasPermissions(context)) { DownloadsTools.all(context) }
        addIf("telephony", TelephonyTools.hasPermissions(context)) { TelephonyTools.all(context) }
        addIf("vibration", VibrationTools.hasPermissions(context)) { VibrationTools.all(context) }
        addIf("flashlight", FlashlightTools.hasPermissions(context)) { FlashlightTools.all(context) }
        addIf("qr", QrTools.hasPermissions(context)) { QrTools.all(context) }
        addIf("camera", CameraTools.hasPermissions(context)) { CameraTools.all(context) }

        // Shell capabilities: root when available, otherwise Shizuku. The official all bundle
        // intentionally leaves these opt-in because they pull native third-party dependencies.
        val shellPolicy = ShellPolicy.RECOMMENDED
        runCatching {
            if (RootTools.isRootAvailable()) {
                tools.addAll(RootTools.all(context, shellPolicy)); loaded += "root"
            } else {
                tools.addAll(ShizukuTools.all(context, shellPolicy)); loaded += "shizuku"
            }
        }.onFailure { unavailable += "shell (root/Shizuku)" }

        val built = DroidMcp.builder()
            .addTools(tools)
            .enableHttpServer(context = context, requireAuth = true, readOnly = false)
            .build()
        runtime = built
        status = Status(loaded.distinct(), unavailable.distinct(), built.listTools().size, built.isServerRunning(), built.serverToken)
        return status
    }

    @Synchronized
    fun reinitialize(): Status {
        runtime?.stopServer()
        runtime = null
        status = Status(emptyList(), emptyList(), 0, false, null)
        return initialize()
    }

    fun status(): Status = status.copy(
        serverRunning = runtime?.isServerRunning() ?: false,
        serverToken = runtime?.serverToken
    )

    fun startHttpServer(): Result<String> = runCatching {
        val r = runtime ?: initialize().let { runtime } ?: error("droid-mcp não inicializado")
        r.startServer()
        status = status.copy(serverRunning = true, serverToken = r.serverToken)
        r.serverToken ?: error("Servidor iniciado sem token; configuração inesperada")
    }

    fun stopHttpServer(): Result<Unit> = runCatching {
        runtime?.stopServer()
        status = status.copy(serverRunning = false)
    }

    fun listToolsJson(): String = runtime?.listToolsJson() ?: "[]"

    suspend fun callTool(name: String, args: Map<String, Any?>): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val r = runtime ?: initialize().let { runtime } ?: error("droid-mcp não inicializado")
            @Suppress("UNCHECKED_CAST")
            val result = r.callTool(name, args.mapValues { it.value ?: "" } as Map<String, Any>)
            result.toString()
        }
    }

    companion object { private const val TAG = "AuroraDroidMcp" }
}
