#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
BASE="${AURORA_BASE:-$HOME/Aurora Projeto}/modelo"
mkdir -p "$BASE"
python -m pip install --user --upgrade huggingface_hub >/dev/null 2>&1 || true
command -v hf >/dev/null 2>&1 || { echo 'hf não instalado'; exit 1; }
DL(){ repo="$1"; pattern="$2"; dir="$3"; mkdir -p "$BASE/$dir"; hf download "$repo" --include "$pattern" --local-dir "$BASE/$dir" --local-dir-use-symlinks False; }
# Biblioteca inicial ampla: várias famílias e quantizações. O catálogo online da Aurora permite muito mais.
DL ggml-org/Qwen3-4B-GGUF '*Q4_K_M.gguf' Qwen3-4B-Q4
DL ggml-org/Qwen3-4B-GGUF '*Q8_0.gguf' Qwen3-4B-Q8
DL ggml-org/Qwen3-1.7B-GGUF '*Q4_K_M.gguf' Qwen3-1.7B-Q4
DL ggml-org/Qwen3-1.7B-GGUF '*Q8_0.gguf' Qwen3-1.7B-Q8
DL ggml-org/Qwen3-0.6B-GGUF '*Q4_K_M.gguf' Qwen3-0.6B-Q4
DL ggml-org/Qwen3-14B-GGUF '*Q4_K_M.gguf' Qwen3-14B-Q4
DL ggml-org/Qwen3-14B-GGUF '*Q5_K_M.gguf' Qwen3-14B-Q5
DL ggml-org/Qwen3-14B-GGUF '*Q8_0.gguf' Qwen3-14B-Q8
DL ggml-org/gemma-3-4b-it-GGUF '*Q4_K_M.gguf' Gemma3-4B-Q4
DL ggml-org/gemma-3-4b-it-GGUF '*Q8_0.gguf' Gemma3-4B-Q8
DL ggml-org/gemma-3-27b-it-GGUF '*Q4_K_M.gguf' Gemma3-27B-Q4
DL tensorblock/Phi-4-mini-instruct-GGUF '*Q4_K_M.gguf' Phi4-mini-Q4
DL tensorblock/Phi-4-mini-instruct-GGUF '*Q5_K_M.gguf' Phi4-mini-Q5
DL tensorblock/Phi-4-mini-instruct-GGUF '*Q8_0.gguf' Phi4-mini-Q8
DL QuantFactory/SmolLM2-1.7B-Instruct-GGUF '*Q5_K_M.gguf' SmolLM2-1.7B-Q5
DL second-state/DeepSeek-R1-Distill-Qwen-7B-GGUF '*Q4_K_M.gguf' DeepSeek-R1-7B-Q4
DL second-state/DeepSeek-R1-Distill-Qwen-7B-GGUF '*Q5_K_M.gguf' DeepSeek-R1-7B-Q5
DL second-state/DeepSeek-R1-Distill-Qwen-7B-GGUF '*Q8_0.gguf' DeepSeek-R1-7B-Q8
DL ggml-org/Llama-2-7B-GGUF '*Q4_K_M.gguf' Llama2-7B-Q4
