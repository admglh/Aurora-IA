package com.aurora.ui

import com.aurora.service.AuroraGenerationService

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ProcessLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.viewModelScope
import com.aurora.AuroraApplication
import com.aurora.AuroraNotifications
import com.aurora.core.database.ConversationEntity
import com.aurora.core.database.MessageEntity
import com.aurora.core.database.Roles
import com.aurora.core.database.MemoryEntity
import com.aurora.core.tools.DeviceInfoTool
import com.aurora.core.tools.StorageInfoTool
import com.aurora.core.model.ChatMessage
import com.aurora.core.model.ModelState
import com.aurora.core.model.CatalogModel
import com.aurora.core.model.ModelCatalogService
import com.aurora.core.model.OpenAICompatibleProvider
import com.aurora.core.files.DocReader
import com.aurora.core.routine.Reminder
import com.aurora.core.routine.Routines
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import com.aurora.core.perf.PerfLog
import com.aurora.core.settings.SecretStore
import com.aurora.core.voice.AuroraVoice
import com.aurora.core.bible.DailyWord
import com.aurora.core.bible.DailyWordService
import com.aurora.core.extensions.ExtensionManager
import com.aurora.core.extensions.RemoteExtensionService
import com.aurora.core.extensions.ExtensionCatalogItem
import com.aurora.core.theme.AuroraThemeSelection
import com.aurora.core.theme.AuroraThemeStore
import android.net.Uri
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class UiMessage(
    val id: Long,
    val role: String,
    val text: String,
    /** true enquanto a resposta ainda está sendo gerada (ainda não gravada no banco). */
    val streaming: Boolean = false
)

@OptIn(ExperimentalCoroutinesApi::class)
class AuroraViewModel(app: Application) : AndroidViewModel(app) {

    private val container = (app as AuroraApplication).container
    private val chat = container.chat
    private val agent = container.agent
    private val persona = container.persona
    private val settings = container.settings
    private val voice = AuroraVoice(app.applicationContext, container.settings, container.secrets)
    private val themeStore = AuroraThemeStore(app.applicationContext)
    private val extensionManager = ExtensionManager(app.applicationContext)
    private val remoteExtensionService = RemoteExtensionService(app.applicationContext)
    val extensionCatalog: List<ExtensionCatalogItem> = remoteExtensionService.catalog()

    private val _dailyWord = MutableStateFlow(DailyWordService.cached(app.applicationContext))
    val dailyWord: StateFlow<DailyWord?> = _dailyWord.asStateFlow()

    private val _extensions = MutableStateFlow(extensionManager.installed())
    val extensions: StateFlow<List<ExtensionManager.Installed>> = _extensions.asStateFlow()
    private val _resourceInstallVersion = MutableStateFlow(0)
    val resourceInstallVersion: StateFlow<Int> = _resourceInstallVersion.asStateFlow()

    private val _themeSelection = MutableStateFlow(themeStore.selection())
    val themeSelection: StateFlow<AuroraThemeSelection> = _themeSelection.asStateFlow()

    private val _animationEnabled = MutableStateFlow(settings.animationEnabled)
    val animationEnabled: StateFlow<Boolean> = _animationEnabled.asStateFlow()

    private val _voiceEnabled = MutableStateFlow(settings.voiceEnabled)
    val voiceEnabled: StateFlow<Boolean> = _voiceEnabled.asStateFlow()

    private val _bubbleEnabled = MutableStateFlow(settings.bubbleEnabled)
    val bubbleEnabled: StateFlow<Boolean> = _bubbleEnabled.asStateFlow()
    private val _voicePitch = MutableStateFlow(settings.voicePitch)
    val voicePitch: StateFlow<Float> = _voicePitch.asStateFlow()
    private val _voiceRate = MutableStateFlow(settings.voiceRate)
    val voiceRate: StateFlow<Float> = _voiceRate.asStateFlow()
    private val _localModelName = MutableStateFlow(settings.localModelFileName)
    val localModelName: StateFlow<String> = _localModelName.asStateFlow()
    private val _speechModelName = MutableStateFlow(settings.speechModelFileName)
    val speechModelName: StateFlow<String> = _speechModelName.asStateFlow()
    private val _embeddingModelName = MutableStateFlow(settings.embeddingModelFileName)
    val embeddingModelName: StateFlow<String> = _embeddingModelName.asStateFlow()
    val modelLibrary = container.models.library
    private val modelCatalogService = ModelCatalogService(app.applicationContext)
    val modelCatalog: List<CatalogModel> = modelCatalogService.load()
    private val _onlineModelCatalog = MutableStateFlow<List<CatalogModel>>(emptyList())
    val onlineModelCatalog: StateFlow<List<CatalogModel>> = _onlineModelCatalog.asStateFlow()
    private val _downloadProgress = MutableStateFlow<Map<String, Float>>(emptyMap())
    val downloadProgress: StateFlow<Map<String, Float>> = _downloadProgress.asStateFlow()

    fun searchModelsOnline(query: String) {
        viewModelScope.launch {
            _error.value = null
            modelCatalogService.searchOnline(query).onSuccess { _onlineModelCatalog.value = it }.onFailure {
                _error.value = "Não foi possível pesquisar modelos: ${it.message ?: "erro desconhecido"}"
            }
        }
    }

    fun downloadCatalogModel(model: CatalogModel) {
        viewModelScope.launch {
            _error.value = null
            modelCatalogService.download(model) { done, total ->
                val p = if (total > 0) done.toFloat() / total else 0f
                _downloadProgress.value = _downloadProgress.value + (model.id to p)
            }.onSuccess {
                _downloadProgress.value = _downloadProgress.value - model.id
                container.models.refreshAsync()
            }.onFailure {
                _downloadProgress.value = _downloadProgress.value - model.id
                _error.value = "Não foi possível baixar ${model.name}: ${it.message ?: "erro desconhecido"}"
            }
        }
    }

    fun deleteLocalModel(fileName: String) {
        viewModelScope.launch {
            container.models.deleteLocalModel(fileName).onFailure {
                _error.value = "Não foi possível apagar o modelo: ${it.message ?: "erro desconhecido"}"
            }
        }
    }

    fun deleteEmbeddingModel() {
        viewModelScope.launch {
            container.models.deleteEmbeddingModel().onSuccess {
                _embeddingModelName.value = ""
            }.onFailure {
                _error.value = "Não foi possível apagar a memória semântica: ${it.message ?: "erro desconhecido"}"
            }
        }
    }

    fun refreshAndroidTools() { viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) { container.tools.refreshDroidMcp() } }

    fun refreshDailyWord() {
        viewModelScope.launch {
            DailyWordService.fetchAndCache(getApplication<Application>())
                .onSuccess { _dailyWord.value = it }
                .onFailure {
                    // Sem isto a tela ficava para sempre em "Consultando…". Mantém o último versículo salvo, se houver.
                    if (_dailyWord.value == null) {
                        _dailyWord.value = DailyWord("Palavra do dia", "Não consegui consultar agora. Volte à tela inicial para tentar de novo.", "sem conexão")
                    }
                }
        }
    }

    fun inspectResource(uri: Uri): ExtensionManager.InstallPlan = extensionManager.inspect(uri)

    fun importExtension(uri: Uri) {
        viewModelScope.launch {
            extensionManager.import(uri).onSuccess {
                _extensions.value = extensionManager.installed()
                container.models.refreshAsync()
                _resourceInstallVersion.value += 1
            }.onFailure { _error.value = "Não foi possível instalar o recurso: ${it.message ?: "erro desconhecido"}" }
        }
    }

    fun downloadExtension(item: ExtensionCatalogItem) {
        viewModelScope.launch {
            remoteExtensionService.download(item).onSuccess { file ->
                extensionManager.installDownloaded(file, "${item.id}.zip").onSuccess {
                    runCatching { file.delete() }
                    _extensions.value = extensionManager.installed()
                    container.models.refreshAsync()
                }.onFailure { _error.value = "Não foi possível instalar ${item.name}: ${it.message ?: "erro desconhecido"}" }
            }.onFailure { _error.value = "Não foi possível baixar ${item.name}: ${it.message ?: "erro desconhecido"}" }
        }
    }

    fun deleteExtension(item: ExtensionManager.Installed) {
        viewModelScope.launch {
            extensionManager.delete(item).onSuccess { _extensions.value = extensionManager.installed() }
                .onFailure { _error.value = "Não foi possível apagar o recurso: ${it.message ?: "erro desconhecido"}" }
        }
    }

    fun visionResources(): List<java.io.File> = java.io.File(getApplication<Application>().filesDir, "vision").listFiles()?.filter { it.isFile }?.sortedBy { it.name } ?: emptyList()

    fun deleteVisionResource(name: String) {
        val safe = name.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]"), "_")
        java.io.File(java.io.File(getApplication<Application>().filesDir, "vision"), safe).delete()
    }

    fun importVisionResource(uri: Uri) {
        viewModelScope.launch {
            runCatching { withContext(kotlinx.coroutines.Dispatchers.IO) {
                val dir = java.io.File(getApplication<Application>().filesDir, "vision").apply { mkdirs() }
                val name = (uri.lastPathSegment?.substringAfterLast('/') ?: "vision-resource").replace(Regex("[^A-Za-z0-9._-]"), "_")
                val target = java.io.File(dir, "${System.currentTimeMillis()}-$name")
                getApplication<Application>().contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "Não foi possível abrir o recurso de visão." }
                    target.outputStream().use { output -> input.copyTo(output, 1024 * 1024) }
                }
            } }.onFailure { _error.value = "Não foi possível importar o recurso de visão: ${it.message ?: "erro desconhecido"}" }
        }
    }

    fun deleteSpeechModel() {
        viewModelScope.launch {
            val dir = java.io.File(getApplication<Application>().filesDir, "models")
            val name = settings.speechModelFileName
            if (name.isBlank()) return@launch
            val ok = withContext(kotlinx.coroutines.Dispatchers.IO) { java.io.File(dir, name).delete() }
            if (ok) {
                settings.speechModelFileName = ""
                _speechModelName.value = ""
            } else {
                _error.value = "Não foi possível apagar o modelo de voz."
            }
        }
    }

    private val _personaText = MutableStateFlow(persona.systemPrompt())
    val personaText: StateFlow<String> = _personaText.asStateFlow()

    /** Estado REAL do modelo (não existe estado "fingido" na UI). */
    val modelState: StateFlow<ModelState> = container.models.state

    val conversations: StateFlow<List<ConversationEntity>> =
        chat.observeConversations().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val memories: StateFlow<List<MemoryEntity>> =
        container.db.memories().observeAll().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val deviceTool = DeviceInfoTool(app.applicationContext)
    private val storageTool = StorageInfoTool(app.applicationContext)
    private val _deviceInfo = MutableStateFlow("Consultando…")
    val deviceInfo: StateFlow<String> = _deviceInfo.asStateFlow()
    private val _storageInfo = MutableStateFlow("Consultando…")
    val storageInfo: StateFlow<String> = _storageInfo.asStateFlow()

    private val _activeConversationId = MutableStateFlow<Long?>(null)
    /** null = conversa nova ainda não criada (é criada ao enviar a primeira mensagem). */
    val activeConversationId: StateFlow<Long?> = _activeConversationId.asStateFlow()

    // Compartilhado no processo: se a Activity for recriada, o texto parcial continua disponível.
    private val streaming = container.generationText

    /** Mapeia as mensagens do banco UMA vez por mudança no banco (e não a cada token de streaming). */
    private val persistedMessages: Flow<List<UiMessage>> = _activeConversationId.flatMapLatest { id ->
        if (id == null) flowOf(emptyList<UiMessage>()) else chat.observeMessages(id).map { list ->
            list.map { UiMessage(it.id, it.role, it.content) }
        }
    }

    val messages: StateFlow<List<UiMessage>> = combine(persistedMessages, streaming, container.generationActive) { persisted, partial, active ->
        when {
            partial != null -> persisted + UiMessage(
                STREAMING_ID, Roles.ASSISTANT,
                partial.ifBlank { "Aurora está pensando…" }, streaming = true
            )
            active -> persisted + UiMessage(STREAMING_ID, Roles.ASSISTANT, "Aurora está pensando…", streaming = true)
            else -> persisted
        }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val isGenerating: StateFlow<Boolean> =
        combine(streaming, container.generationActive) { partial, active -> partial != null || active }
            .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    private val _attachment = MutableStateFlow<Pair<String, String>?>(null)
    val attachment: StateFlow<Pair<String, String>?> = _attachment.asStateFlow()
    /** Imagens (fotos, páginas de PDF) do anexo atual, em base64. */
    private val _attachImages = MutableStateFlow<List<String>>(emptyList())
    /** Nome do anexo atual (texto ou imagens) para mostrar no chat. */
    private val _attachName = MutableStateFlow<String?>(null)
    val attachName: StateFlow<String?> = _attachName.asStateFlow()

    // ---------- modo conversa (mãos livres) ----------
    private val _handsFree = MutableStateFlow(false)
    val handsFree: StateFlow<Boolean> = _handsFree.asStateFlow()
    private val _listenRequests = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val listenRequests: SharedFlow<Unit> = _listenRequests.asSharedFlow()
    private var handsFreeMisses = 0

    /** Pedido para a UI abrir o chat (ex.: arquivo compartilhado de outro app). */
    private val _openChat = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val openChat: SharedFlow<Unit> = _openChat.asSharedFlow()

    init {
        // Fim da fala da Aurora -> no modo conversa, volta a ouvir sozinha.
        voice.onFinished = {
            if (_handsFree.value) viewModelScope.launch { kotlinx.coroutines.delay(350); _listenRequests.emit(Unit) }
        }
    }

    fun setHandsFree(on: Boolean) {
        _handsFree.value = on
        handsFreeMisses = 0
        voice.stop()
        if (on) viewModelScope.launch { _listenRequests.emit(Unit) }
    }

    /** O microfone terminou sem texto. Tenta de novo algumas vezes; depois encerra o modo conversa. */
    fun handsFreeMiss() {
        if (!_handsFree.value) return
        handsFreeMisses++
        if (handsFreeMisses >= 3) {
            _handsFree.value = false
            _error.value = "Modo conversa encerrado: não ouvi nada. Toque nas ondas para voltar."
        } else viewModelScope.launch { kotlinx.coroutines.delay(500); _listenRequests.emit(Unit) }
    }

    /** Texto final reconhecido no modo conversa: envia direto. */
    fun handsFreeHeard(text: String) {
        handsFreeMisses = 0
        if (!send(text)) viewModelScope.launch { kotlinx.coroutines.delay(800); _listenRequests.emit(Unit) }
    }

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private var generationJob: Job? = null

    init {
        viewModelScope.launch { _deviceInfo.value = deviceTool.run(emptyMap()); _storageInfo.value = storageTool.run(emptyMap()) }
        viewModelScope.launch {
            container.startup.join()
            val last = settings.lastConversationId
            if (last > 0 && chat.conversationExists(last)) _activeConversationId.value = last
        }
    }

    /** @return true se a mensagem foi aceita (a UI só limpa o campo de texto nesse caso). */
    fun send(text: String): Boolean {
        val attachment = _attachment.value
        val images = _attachImages.value
        val attachName = _attachName.value
        val typed = text.trim()
        val clean = (when {
            attachment != null -> typed + "\n\n[Arquivo: ${attachment.first}]\n${attachment.second}"
            images.isNotEmpty() -> (typed.ifBlank { "Analise este arquivo." }) + "\n\n[Arquivo anexado: $attachName]"
            else -> typed
        }).trim()
        // O que aparece/fica salvo no chat: só o que a pessoa escreveu + o nome do anexo (não o conteúdo inteiro).
        val shown = if (attachName != null) (typed + "\n📎 " + attachName).trim() else typed
        if (clean.isEmpty()) return false
        if (generationJob?.isActive == true || container.generationActive.value) return false
        if (modelState.value !is ModelState.Ready) {
            _error.value = "Nenhum modelo está pronto. Em Configurações, preencha o endereço, o modelo e a chave da nuvem, ou importe um modelo local."
            return false
        }
        _error.value = null
        voice.stop()

        themeStore.applyIntent(typed.ifBlank { clean })?.let { _themeSelection.value = themeStore.selection() }

        val trace = PerfLog.newTrace() // t0 = toque em "enviar" (mensagem já aceita)
        if (!container.tryBeginGeneration()) return false
        // A geração pertence ao escopo do processo, não ao ciclo de vida da tela.
        // Assim, fechar a Activity não cancela a resposta enquanto o serviço foreground mantém o processo vivo.
        generationJob = container.appScope.launch {
            trace.at("job_started")
            runCatching {
                val intent = android.content.Intent(
                    getApplication<Application>(),
                    AuroraGenerationService::class.java
                ).apply {
                    action = AuroraGenerationService.ACTION_START
                }
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    getApplication<Application>().startForegroundService(intent)
                } else {
                    getApplication<Application>().startService(intent)
                }
            }.onFailure {
                trace.note("foreground_service_error", it.javaClass.simpleName)
            } // atraso entre o toque e o início do processamento
            var conversationId: Long? = null
            val buffer = StringBuilder()
            try {
                val id = _activeConversationId.value ?: trace.measureSuspend("db_create_conversation") { chat.createConversation() }.also {
                    _activeConversationId.value = it
                    settings.lastConversationId = it
                }
                conversationId = id
                extractMemoryCommand(typed)?.let { remembered ->
                    addMemory(remembered, "manual")
                }
                runCatching { autoRemember(typed) }
                val history = trace.measureSuspend("db_history") {
                    chat.recentHistory(id, HISTORY_MESSAGES).map { ChatMessage(it.role, it.content) }
                }
                trace.measureSuspend("db_save_user_message") { chat.addMessage(id, Roles.USER, shown) }
                _attachment.value = null
                _attachImages.value = emptyList()
                _attachName.value = null

                streaming.value = ""
                trace.at("thinking_bubble_published")
                PerfLog.markUiPublished(trace, "thinking_bubble")
                var lastPublish = 0L
                var pieces = 0
                agent.respond(history, clean, trace, images, typed).collect { piece ->
                    if (pieces++ == 0) trace.at("first_piece") // no motor local = resposta COMPLETA (sem streaming)
                    buffer.append(piece)
                    // Streaming remoto pode emitir dezenas de tokens por segundo: publica no máx. ~20x/s.
                    val now = android.os.SystemClock.uptimeMillis()
                    if (now - lastPublish >= STREAM_PUBLISH_INTERVAL_MS) {
                        lastPublish = now
                        streaming.value = buffer.toString()
                        if (pieces == 1) PerfLog.markUiPublished(trace, "first_text")
                    }
                }
                streaming.value = buffer.toString() // garante o texto final completo
                trace.note("pieces_emitted", pieces)
                trace.at("generation_done")
                PerfLog.markUiPublished(trace, "final_text")
                if (buffer.isBlank()) _error.value = "O modelo não retornou texto."
                else if ((settings.autoSpeak && _voiceEnabled.value) || _handsFree.value) voice.speak(buffer.toString())
            } catch (e: CancellationException) {
                trace.note("outcome", "cancelled")
                throw e
            } catch (t: Throwable) {
                trace.note("outcome", "error:${t.javaClass.simpleName}")
                _error.value = "Falha ao gerar a resposta: " + (t.message ?: t.javaClass.simpleName)
            } finally {
                withContext(NonCancellable) {
                    val id = conversationId
                    val savedMessageId = if (id != null && buffer.isNotBlank()) {
                        trace.measureSuspend("db_save_assistant_message") { chat.addMessage(id, Roles.ASSISTANT, buffer.toString()) }
                    } else null
                    streaming.value = null
                    // O onStop da Activity pode ter ocorrido antes de a resposta terminar. Espera o
                    // ProcessLifecycleOwner estabilizar e avisa quando a Aurora conclui já em segundo plano.
                    if (savedMessageId != null && buffer.isNotBlank()) {
                        val background = runCatching {
                            withContext(kotlinx.coroutines.Dispatchers.Main.immediate) {
                                kotlinx.coroutines.delay(900)
                                !ProcessLifecycleOwner.get().lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)
                            }
                        }.getOrDefault(false)
                        if (background) runCatching {
                            AuroraNotifications.notifyConversationForMessage(
                                getApplication<Application>(), savedMessageId, buffer.toString()
                            )
                        }
                    }
                    // Para via ACTION_STOP (e não stopService): mantém o foreground ativo até salvar
                    // a resposta e, se necessário, publicar a notificação de conclusão.
                    runCatching {
                        getApplication<Application>().startService(
                            android.content.Intent(
                                getApplication<Application>(),
                                AuroraGenerationService::class.java
                            ).apply { action = AuroraGenerationService.ACTION_STOP }
                        )
                    }
                    container.finishGeneration()
                    trace.at("total")
                    // Aquece o modelo de embeddings FORA do caminho crítico (depois da resposta), sem disputar CPU com a inferência.
                    container.semanticMemory.warmUp()
                }
            }
        }
        container.attachGenerationJob(generationJob!!)
        return true
    }

    /** Interrompe a geração; o texto parcial já recebido é gravado como resposta. */
    fun stop() {
        voice.stop()
        agent.cancel()
        container.cancelActiveGeneration()
        generationJob?.cancel()
    }

    /** Anexa foto, PDF, DOCX ou texto ao próximo envio (também usado por "Compartilhar com a Aurora"). */
    fun attachFile(uri: Uri) {
        viewModelScope.launch {
            val doc = DocReader.read(getApplication<Application>(), uri)
            if (doc.kind == "erro" || doc.kind == "desconhecido") {
                _error.value = doc.note.ifBlank { "Não consegui ler esse arquivo." }
                return@launch
            }
            _attachment.value = if (doc.text.isNotBlank()) doc.name to doc.text else null
            _attachImages.value = doc.images
            _attachName.value = doc.name
            if (doc.note.isNotBlank()) _error.value = doc.note
            _openChat.emit(Unit)
        }
    }

    fun attachTextFile(uri: Uri) = attachFile(uri)

    /** Texto compartilhado de outro app: vira o rascunho. */
    private val _sharedText = MutableStateFlow<String?>(null)
    val sharedText: StateFlow<String?> = _sharedText.asStateFlow()
    fun shareText(t: String) { _sharedText.value = t; viewModelScope.launch { _openChat.emit(Unit) } }
    fun consumeSharedText() { _sharedText.value = null }

    fun clearAttachment() { _attachment.value = null; _attachImages.value = emptyList(); _attachName.value = null }

    fun dismissError() { _error.value = null }

    fun showError(message: String) { _error.value = message }

    fun newConversation() {
        stop()
        _activeConversationId.value = null
        settings.lastConversationId = -1L
    }

    fun openConversation(id: Long) {
        stop()
        _activeConversationId.value = id
        settings.lastConversationId = id
    }

    fun deleteConversation(id: Long) {
        viewModelScope.launch {
            if (_activeConversationId.value == id) {
                stop()
                _activeConversationId.value = null
                settings.lastConversationId = -1L
            }
            chat.deleteConversation(id)
        }
    }

    fun deleteMessage(id: Long) {
        viewModelScope.launch { chat.deleteMessage(id) }
    }

    fun deleteMemory(id: Long) {
        viewModelScope.launch {
            container.db.memories().delete(id)
            container.semanticMemory.remove(id)
        }
    }

    fun addMemory(content: String, kind: String) {
        val clean = content.trim()
        if (clean.isBlank()) return
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val entity = MemoryEntity(content = clean, kind = kind.trim().ifBlank { "geral" }, source = "user", createdAt = now, updatedAt = now)
            val id = container.db.memories().insert(entity)
            container.semanticMemory.index(entity.copy(id = id))
        }
    }

    fun updateMemory(id: Long, content: String, kind: String) {
        val clean = content.trim()
        if (clean.isBlank()) return
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val normalizedKind = kind.trim().ifBlank { "geral" }
            container.db.memories().update(id, clean, normalizedKind, now)
            container.semanticMemory.index(MemoryEntity(id = id, content = clean, kind = normalizedKind, source = "user", createdAt = now, updatedAt = now))
        }
    }

    fun savePersona(text: String) {
        runCatching { persona.save(text) }
            .onSuccess { _personaText.value = persona.systemPrompt() }
            .onFailure { _error.value = "Não foi possível salvar a personalidade: ${it.message ?: "erro desconhecido"}" }
    }

    fun resetPersona() {
        persona.reset()
        _personaText.value = persona.systemPrompt()
    }

    // --- Endpoint remoto opcional ---

    fun remoteEndpoint(): String = settings.remoteEndpoint
    fun remoteModel(): String = settings.remoteModel
    fun hasRemoteKey(): Boolean = container.secrets.has(SecretStore.KEY_REMOTE_API)

    /** [apiKey] em branco mantém a chave atual. */
    fun saveRemoteConfig(endpoint: String, model: String, apiKey: String) {
        settings.remoteEndpoint = endpoint.trim()
        settings.remoteModel = model.trim()
        if (apiKey.isNotBlank()) container.secrets.put(SecretStore.KEY_REMOTE_API, apiKey.trim())
        container.models.refreshAsync()
    }

    fun clearRemoteConfig() {
        settings.remoteEndpoint = ""
        settings.remoteModel = ""
        container.secrets.put(SecretStore.KEY_REMOTE_API, null)
        container.models.refreshAsync()
    }

    fun setAnimationEnabled(enabled: Boolean) {
        settings.animationEnabled = enabled
        _animationEnabled.value = enabled
    }

    fun setVoiceEnabled(enabled: Boolean) {
        settings.voiceEnabled = enabled
        _voiceEnabled.value = enabled
        if (!enabled) voice.stop()
    }

    fun setBubbleEnabled(enabled: Boolean) {
        settings.bubbleEnabled = enabled
        _bubbleEnabled.value = enabled

        val app = getApplication<android.app.Application>()
        val intent = android.content.Intent(
            app,
            com.aurora.service.AuroraBubbleService::class.java
        )

        if (enabled && android.provider.Settings.canDrawOverlays(app)) {
            runCatching {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    androidx.core.content.ContextCompat.startForegroundService(app, intent)
                } else {
                    @Suppress("DEPRECATION")
                    app.startService(intent)
                }
            }
        } else if (!enabled) {
            runCatching { app.stopService(intent) }
        }
    }

    // ---------- Estúdio de voz ----------
    private fun readVoiceConfig() = VoiceConfig(
        engine = settings.voiceEngine, deviceName = settings.voiceDeviceName, cloudName = settings.voiceCloudName,
        pitch = settings.voicePitch, rate = settings.voiceRate, bass = settings.voiceBass, treble = settings.voiceTreble,
        boost = settings.voiceBoost, gain = settings.voiceGain, autoSpeak = settings.autoSpeak
    )
    private val _voiceConfig = MutableStateFlow(readVoiceConfig())
    val voiceConfig: StateFlow<VoiceConfig> = _voiceConfig.asStateFlow()

    fun updateVoice(c: VoiceConfig) {
        settings.voiceEngine = c.engine
        settings.voiceDeviceName = c.deviceName
        settings.voiceCloudName = c.cloudName
        settings.voicePitch = c.pitch
        settings.voiceRate = c.rate
        settings.voiceBass = c.bass
        settings.voiceTreble = c.treble
        settings.voiceBoost = c.boost
        settings.voiceGain = c.gain
        settings.autoSpeak = c.autoSpeak
        _voiceConfig.value = readVoiceConfig()
        _voicePitch.value = settings.voicePitch
        _voiceRate.value = settings.voiceRate
    }

    fun resetVoice() = updateVoice(VoiceConfig())

    fun testVoice() {
        voice.speak("Olá! Eu sou a Aurora. Esta é a minha voz. Ajuste o tom, a velocidade, os graves e os agudos até ficar do seu jeito.")
    }

    fun stopVoice() = voice.stop()
    fun deviceVoices(): List<com.aurora.core.voice.VoiceInfo> = voice.deviceVoices()
    fun voiceNote(): String = voice.lastNote

    // ---------- Rotinas (resumo matinal e lembretes) ----------
    data class BriefConfig(val enabled: Boolean, val hour: Int, val minute: Int, val city: String, val topics: String)
    private fun readBrief() = BriefConfig(settings.briefEnabled, settings.briefHour, settings.briefMinute, settings.briefCity, settings.briefTopics)
    private val _brief = MutableStateFlow(readBrief())
    val brief: StateFlow<BriefConfig> = _brief.asStateFlow()
    private val _reminders = MutableStateFlow(Routines.reminders(settings))
    val reminders: StateFlow<List<Reminder>> = _reminders.asStateFlow()

    fun updateBrief(c: BriefConfig) {
        settings.briefEnabled = c.enabled; settings.briefHour = c.hour; settings.briefMinute = c.minute
        settings.briefCity = c.city; settings.briefTopics = c.topics
        _brief.value = readBrief()
        Routines.applyBrief(getApplication<Application>(), settings)
    }

    fun refreshReminders() { _reminders.value = Routines.reminders(settings) }
    fun cancelReminder(id: Int) { Routines.cancelReminder(getApplication<Application>(), settings, id); refreshReminders() }

    /** Gera e mostra o resumo agora (para testar sem esperar o horário). */
    fun briefNow() {
        viewModelScope.launch {
            _error.value = "Montando seu resumo…"
            val text = runCatching { Routines.buildBrief(getApplication<Application>()) }.getOrElse { "Não consegui montar o resumo: ${it.message}" }
            _error.value = null
            Routines.notify(getApplication<Application>(), 7002, "Aurora · seu resumo de hoje", text)
        }
    }

    // ---------- Arquivos liberados ----------
    private val _folders = MutableStateFlow(container.files.folders())
    val folders: StateFlow<List<Uri>> = _folders.asStateFlow()
    fun folderLabel(u: Uri): String = container.files.folderLabel(u)
    fun addFolder(u: Uri) { container.files.addFolder(u); _folders.value = container.files.folders() }
    fun removeFolder(u: Uri) { container.files.removeFolder(u); _folders.value = container.files.folders() }

    // ---------- Teste da nuvem ----------
    private val _cloudTest = MutableStateFlow("")
    val cloudTest: StateFlow<String> = _cloudTest.asStateFlow()

    fun testCloud() {
        viewModelScope.launch {
            _cloudTest.value = "Testando a conexão…"
            val provider = OpenAICompatibleProvider(settings.remoteEndpoint, settings.remoteModel, container.secrets.get(SecretStore.KEY_REMOTE_API))
            _cloudTest.value = provider.test()
        }
    }

    fun setVoicePitch(value: Float) {
        settings.voicePitch = value
        _voicePitch.value = value
        voice.configure(value, _voiceRate.value)
    }

    fun setVoiceRate(value: Float) {
        settings.voiceRate = value
        _voiceRate.value = value
        voice.configure(_voicePitch.value, value)
    }

    fun speakLast() {
        if (!_voiceEnabled.value) return
        val last = messages.value.lastOrNull { it.role == Roles.ASSISTANT && !it.streaming }?.text.orEmpty()
        if (last.isNotBlank()) voice.speak(last)
    }

    fun speechModelFile(): java.io.File = java.io.File(getApplication<Application>().filesDir, "models/${settings.speechModelFileName}")

    fun importSpeechModel(uri: Uri) {
        viewModelScope.launch {
            runCatching { withContext(kotlinx.coroutines.Dispatchers.IO) {
                val dir = java.io.File(getApplication<Application>().filesDir, "models").apply { mkdirs() }
                val target = java.io.File(dir, "whisper-${System.currentTimeMillis()}.bin")
                val temp = java.io.File(dir, ".${target.name}.part")
                getApplication<Application>().contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "Não foi possível abrir o modelo Whisper." }
                    temp.outputStream().use { output -> input.copyTo(output, 1024 * 1024) }
                }
                require(temp.length() > 10L * 1024L * 1024L) { "O arquivo Whisper é pequeno demais." }
                check(temp.renameTo(target)) { "Não foi possível finalizar a importação do modelo Whisper." }
                settings.speechModelFileName = target.name
                _speechModelName.value = target.name
            } }.onFailure { _error.value = "Não foi possível importar o modelo Whisper: ${it.message ?: "erro desconhecido"}" }
        }
    }


    fun importEmbeddingModel(uri: Uri) {
        viewModelScope.launch {
            _error.value = null
            val name = uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':') ?: "bge-m3.gguf"
            container.models.importEmbeddingModel(uri, name)
                .onSuccess { file ->
                    _embeddingModelName.value = file.name
                    container.db.memories().all().forEach { memory -> container.semanticMemory.index(memory) }
                }
                .onFailure { t ->
                    _error.value = "Não foi possível importar o modelo de memória: ${t.message ?: "erro desconhecido"}"
                }
        }
    }

    fun importModel(uri: Uri) {
        viewModelScope.launch {
            _error.value = null
            val name = uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':') ?: "Qwen-model.gguf"
            val result = container.models.importLocalModel(uri, name)
            result.onSuccess { file ->
                _localModelName.value = file.name
            }.onFailure { t ->
                _error.value = "Não foi possível importar o modelo: ${t.message ?: "erro desconhecido"}"
            }
        }
    }

    fun refreshTheme() { _themeSelection.value = themeStore.selection() }

    fun setTheme(theme: com.aurora.core.theme.AuroraTheme) {
        themeStore.set(theme)
        _themeSelection.value = themeStore.selection()
    }

    fun clearThemeOverride() {
        themeStore.clear()
        _themeSelection.value = themeStore.selection()
    }

    override fun onCleared() {
        voice.shutdown()
        super.onCleared()
    }

    // ---------- Memória automática (fatos básicos ditos pelo usuário; aparecem em Memória e podem ser apagados) ----------
    private suspend fun autoRemember(text: String) {
        val fact = extractAutoFact(text) ?: return
        val dao = container.db.memories()
        if (dao.all().any { it.content.equals(fact, ignoreCase = true) }) return
        val now = System.currentTimeMillis()
        val entity = MemoryEntity(content = fact, kind = "auto", source = "auto", createdAt = now, updatedAt = now)
        val id = dao.insert(entity)
        container.semanticMemory.index(entity.copy(id = id))
    }

    private fun extractAutoFact(text: String): String? {
        val t = text.trim().trimEnd('.', '!')
        if (t.length > 160 || t.endsWith("?")) return null
        val rules: List<Pair<Regex, (MatchResult) -> String>> = listOf(
            Regex("(?i)(?:^|[,.!] ?)meu nome é ([\\p{L}][\\p{L} ]{1,38})$") to { m: MatchResult -> "O nome do usuário é ${m.groupValues[1].trim()}." },
            Regex("(?i)(?:^|[,.!] ?)eu moro (?:em|no|na) ([\\p{L}][\\p{L} ,-]{1,40})$") to { m: MatchResult -> "O usuário mora em ${m.groupValues[1].trim()}." },
            Regex("(?i)(?:^|[,.!] ?)meu anivers[áa]rio é (?:dia )?([\\p{L}0-9/ ]{3,30})$") to { m: MatchResult -> "O aniversário do usuário é ${m.groupValues[1].trim()}." },
            Regex("(?i)(?:^|[,.!] ?)eu trabalho (?:como|com|na|no|em) ([\\p{L}][\\p{L} ]{1,40})$") to { m: MatchResult -> "O usuário trabalha ${t.substringAfter("trabalho ").trim()}." },
            Regex("(?i)(?:^|[,.!] ?)minha (esposa|marido|namorada|namorado|filha|filho|m[ãa]e|pai|irm[ãa]|irm[ãa]o) se chama ([\\p{L}][\\p{L} ]{1,30})$") to { m: MatchResult -> "${m.groupValues[1].replaceFirstChar { c -> c.uppercase() }} do usuário: ${m.groupValues[2].trim()}." },
            Regex("(?i)(?:^|[,.!] ?)eu sou al[ée]rgico (?:a|ao|à) ([\\p{L}][\\p{L} ,]{1,40})$") to { m: MatchResult -> "O usuário é alérgico a ${m.groupValues[1].trim()}." }
        )
        for ((re, build) in rules) re.find(t)?.let { return build(it) }
        return null
    }

    // ---------- Backup (conversas e memórias em JSON) ----------
    fun exportBackup(uri: Uri) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            runCatching {
                val db = container.db
                val convs = org.json.JSONArray()
                db.conversations().all().forEach { c ->
                    convs.put(org.json.JSONObject().put("id", c.id).put("title", c.title).put("createdAt", c.createdAt).put("updatedAt", c.updatedAt).put("source", c.source))
                }
                val msgs = org.json.JSONArray()
                db.messages().all().forEach { m ->
                    msgs.put(org.json.JSONObject().put("conversationId", m.conversationId).put("role", m.role).put("content", m.content).put("timestamp", m.timestamp))
                }
                val mems = org.json.JSONArray()
                db.memories().all().forEach { m ->
                    mems.put(org.json.JSONObject().put("content", m.content).put("kind", m.kind).put("source", m.source).put("createdAt", m.createdAt).put("updatedAt", m.updatedAt))
                }
                val root = org.json.JSONObject().put("app", "aurora").put("version", 1).put("exportedAt", System.currentTimeMillis())
                    .put("conversations", convs).put("messages", msgs).put("memories", mems)
                val out = getApplication<Application>().contentResolver.openOutputStream(uri, "wt") ?: error("Não foi possível abrir o arquivo de destino.")
                out.bufferedWriter(Charsets.UTF_8).use { it.write(root.toString()) }
                _error.value = "Backup salvo: ${convs.length()} conversas, ${msgs.length()} mensagens, ${mems.length()} memórias."
            }.onFailure { _error.value = "Falha ao exportar o backup: ${it.message ?: it.javaClass.simpleName}" }
        }
    }

    fun importBackup(uri: Uri) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            runCatching {
                val text = getApplication<Application>().contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                    ?: error("Não foi possível ler o arquivo.")
                val root = org.json.JSONObject(text)
                require(root.optString("app") == "aurora") { "Este arquivo não é um backup da Aurora." }
                val db = container.db
                val existing = db.conversations().all().map { it.title to it.createdAt }.toSet()
                val idMap = HashMap<Long, Long>()
                var newConvs = 0; var newMsgs = 0; var newMems = 0
                val convArr = root.optJSONArray("conversations") ?: org.json.JSONArray()
                for (i in 0 until convArr.length()) {
                    val c = convArr.getJSONObject(i)
                    val title = c.optString("title"); val created = c.optLong("createdAt")
                    if ((title to created) in existing) continue // já existe: não duplica
                    idMap[c.getLong("id")] = db.conversations().insert(
                        com.aurora.core.database.ConversationEntity(title = title, createdAt = created, updatedAt = c.optLong("updatedAt", created), source = c.optString("source", "app"))
                    )
                    newConvs++
                }
                val msgArr = root.optJSONArray("messages") ?: org.json.JSONArray()
                for (i in 0 until msgArr.length()) {
                    val m = msgArr.getJSONObject(i)
                    val newConv = idMap[m.optLong("conversationId")] ?: continue
                    db.messages().insert(MessageEntity(conversationId = newConv, role = m.optString("role"), content = m.optString("content"), timestamp = m.optLong("timestamp")))
                    newMsgs++
                }
                val have = db.memories().all().map { it.content.lowercase() }.toMutableSet()
                val memArr = root.optJSONArray("memories") ?: org.json.JSONArray()
                for (i in 0 until memArr.length()) {
                    val m = memArr.getJSONObject(i)
                    val content = m.optString("content").trim()
                    if (content.isBlank() || !have.add(content.lowercase())) continue
                    val e = MemoryEntity(content = content, kind = m.optString("kind", "geral"), source = m.optString("source", "user"), createdAt = m.optLong("createdAt"), updatedAt = m.optLong("updatedAt"))
                    val id = db.memories().insert(e)
                    container.semanticMemory.index(e.copy(id = id))
                    newMems++
                }
                _error.value = "Backup importado: $newConvs conversas, $newMsgs mensagens, $newMems memórias novas."
            }.onFailure { _error.value = "Falha ao importar o backup: ${it.message ?: it.javaClass.simpleName}" }
        }
    }

    private fun extractMemoryCommand(text: String): String? {
        val match = Regex("^(?:lembre(?:-se)?|memorize|guarde)(?:\\s+que)?\\s*[:,-]?\\s+(.+)$", RegexOption.IGNORE_CASE).find(text.trim())
        return match?.groupValues?.getOrNull(1)?.trim()?.takeIf { it.length >= 3 }
    }

    private companion object {
        const val STREAMING_ID = -1L
        const val HISTORY_MESSAGES = 24
        const val STREAM_PUBLISH_INTERVAL_MS = 50L
    }
}


/** Estado do estúdio de voz. Os valores padrão são a "voz feminina padrão" da Aurora. */
data class VoiceConfig(
    val engine: String = "cloud",
    val deviceName: String = "",
    val cloudName: String = "Kore",
    val pitch: Float = 1.0f,
    val rate: Float = 1.0f,
    val bass: Float = 0f,
    val treble: Float = 0.15f,
    val boost: Float = 0f,
    val gain: Float = 1f,
    val autoSpeak: Boolean = true
)
