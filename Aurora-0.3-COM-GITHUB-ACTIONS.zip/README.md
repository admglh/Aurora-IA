# Aurora — assistente pessoal local

Aurora é uma assistente Android local-first. O APK não embute pesos de LLM: o usuário importa um GGUF e o aplicativo usa llama.cpp no próprio aparelho.

## O que está realmente implementado

- Chat local com histórico persistente em Room.
- Importação e validação de GGUF, com cópia atômica e biblioteca de modelos.
- Seleção automática: GGUF local primeiro, endpoint compatível opcional como fallback.
- Sanitização de respostas para remover blocos `<think>` e ecos de papéis.
- Memórias persistentes editáveis, apagáveis e criáveis pelo usuário.
- Comando natural de memória: `lembre que ...`, `memorize ...` ou `guarde ...` cria uma memória manual.
- Recuperação local de memórias por correspondência lexical, sem enviar dados para a nuvem.
- Persona editável dentro do próprio aplicativo, pelo **Estúdio da Aurora**, sem recompilar.
- Identidade visual própria com temas de aniversário, formal, calor, frio, Páscoa, 7 de setembro e Halloween.
- Presença animada por Compose e runtime Lottie preparado para futuras animações locais.
- TTS Android com seleção automática de voz pt-BR instalada e preferência por vozes locais/naturais quando disponíveis.
- Reconhecimento de voz pelo Android com preferência offline.
- Provider opcional para Whisper totalmente offline, ativado quando um modelo Whisper é importado.
- Cancelamento, tratamento de exceções e estados reais do motor.
- Armazenamento privado e `allowBackup=false`.
- Runtime local sem CMake/JNI próprio da aplicação.
- Arquitetura de provider preparada para outros runtimes no futuro.

## Limites honestos

O AAR gratuito `llama-android:0.1.1` oferece completion e embeddings, mas não streaming de tokens. A Aurora não simula streaming: a resposta local chega ao UI como um bloco. Um provider de runtime que ofereça streaming real pode ser conectado sem reescrever a UI/agent.

Geração de imagens não é fingida. O projeto deve receber um provider de imagem separado quando um runtime local/remoto adequado for escolhido.

## Build

O ambiente desta revisão não tinha acesso à distribuição Gradle nem às dependências Maven, portanto o APK não pôde ser produzido aqui. O projeto mantém o Gradle Wrapper e inclui `tools/build_apk.sh` para a compilação no Android/Termux em uma única execução depois que o SDK/JDK estiverem disponíveis.

Veja `COMO_GERAR_APK.txt`.
