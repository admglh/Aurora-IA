#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
SRC="$(cd "$(dirname "$0")/.." && pwd)"
TARGET="${AURORA_HOME:-$HOME/Aurora Nova}"
OLD1="$HOME/Aurora Projeto"
OLD2="$HOME/Nova-Aurora"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$HOME/Aurora-Backup-$STAMP"
ASSETS="${AURORA_ASSET_ROOT:-/storage/emulated/0/Download/Aurora}"
log(){ printf '\n[AURORA] %s\n' "$*"; }

log "Instalação limpa da Aurora Nova"
log "Projeto-fonte: $SRC"
log "Destino: $TARGET"
log "Recursos pesados: $ASSETS"

[ -d "$SRC/app" ] || { echo "Execute este script dentro do ZIP extraído da Aurora."; exit 2; }

# Preserva a instalação antiga antes de substituí-la.
if [ -e "$TARGET" ]; then
  mkdir -p "$BACKUP"
  mv "$TARGET" "$BACKUP/Aurora-Nova-existente"
  log "Backup criado: $BACKUP/Aurora-Nova-existente"
fi
if [ -e "$OLD1" ]; then
  mkdir -p "$BACKUP"
  mv "$OLD1" "$BACKUP/Aurora-Projeto-antiga"
  log "Instalação antiga preservada: $BACKUP/Aurora-Projeto-antiga"
fi
if [ -e "$OLD2" ]; then
  mkdir -p "$BACKUP"
  mv "$OLD2" "$BACKUP/Nova-Aurora-antiga"
  log "Instalação antiga preservada: $BACKUP/Nova-Aurora-antiga"
fi

mkdir -p "$TARGET"
cp -a "$SRC/." "$TARGET/"
chmod +x "$TARGET"/tools/*.sh "$TARGET"/gradlew 2>/dev/null || true

# Nunca duplica os 6+ GB de modelos: organiza e registra o armazenamento compartilhado.
if [ -d "$ASSETS" ]; then
  AURORA_ASSET_ROOT="$ASSETS" "$TARGET/tools/ORGANIZAR_RECURSOS_AURORA.sh"
else
  log "Aviso: a pasta compartilhada $ASSETS ainda não existe. Ela será criada."
  mkdir -p "$ASSETS"
fi

cat > "$TARGET/aurora-env.sh" <<ENV
export AURORA_HOME="$TARGET"
export AURORA_ASSET_ROOT="$ASSETS"
export ANDROID_HOME="\${ANDROID_HOME:-$HOME/android-sdk}"
export ANDROID_SDK_ROOT="\${ANDROID_SDK_ROOT:-$HOME/android-sdk}"
export PATH="\$AURORA_HOME/ferramentas/bin:\$ANDROID_HOME/platform-tools:\$PATH"
ENV

cat > "$TARGET/INSTALACAO_REALIZADA.txt" <<TXT
Aurora Nova instalada em: $TARGET
Recursos compartilhados: $ASSETS
Backup desta instalação: $BACKUP
Data: $(date -Iseconds)

Modelos não são duplicados pelo ZIP. O Termux usa os arquivos existentes em Download/Aurora.
TXT

log "Instalação concluída."
log "Próximo passo: source '$TARGET/aurora-env.sh'"
log "Depois: '$TARGET/tools/INVENTARIO_AURORA.sh'"
log "Para gerar o APK: '$TARGET/tools/build_apk.sh'"
