package com.aurora.core.agent

import android.content.Context
import android.util.Log
import java.io.File
import java.io.IOException

/**
 * Persona editável sem recompilar o APK.
 * O asset é a versão inicial; depois disso o usuário pode editar o arquivo privado do app.
 */
class PersonaProvider(context: Context) {
    private val app = context.applicationContext
    private val configDir = File(app.filesDir, "aurora-config").apply { mkdirs() }
    private val personaFile = File(configDir, "persona.md")
    @Volatile private var cached: String? = null

    fun systemPrompt(): String = cached ?: load().also { cached = it }

    fun save(prompt: String) {
        val clean = prompt.trim()
        require(clean.length >= 40) { "A personalidade precisa ter pelo menos 40 caracteres." }
        require(clean.length <= MAX_CHARS) { "A personalidade é grande demais (máximo $MAX_CHARS caracteres)." }
        val temp = File(configDir, "persona.md.part")
        temp.writeText(clean, Charsets.UTF_8)
        check(temp.renameTo(personaFile) || temp.copyTo(personaFile, overwrite = true).let { temp.delete(); true })
        cached = clean
    }

    fun reset() {
        personaFile.delete()
        cached = null
    }

    fun file(): File = personaFile

    private fun load(): String {
        if (!personaFile.exists()) {
            val default = loadAsset()
            try {
                personaFile.writeText(default, Charsets.UTF_8)
            } catch (t: Throwable) {
                Log.w(TAG, "Não foi possível criar a cópia editável da persona", t)
            }
            return default
        }
        return try {
            personaFile.readText(Charsets.UTF_8).trim().ifBlank { loadAsset() }
        } catch (t: Throwable) {
            Log.e(TAG, "Falha ao ler a persona editável; usando padrão.", t)
            loadAsset()
        }
    }

    private fun loadAsset(): String = try {
        app.assets.open(ASSET).bufferedReader(Charsets.UTF_8).use { it.readText() }
            .replace(Regex("<!--.*?-->", RegexOption.DOT_MATCHES_ALL), "")
            .trim()
    } catch (e: IOException) {
        Log.e(TAG, "Persona não encontrada em assets/$ASSET; usando prompt mínimo.", e)
        FALLBACK
    }

    private companion object {
        const val TAG = "PersonaProvider"
        const val ASSET = "persona/aurora_5_0.md"
        const val MAX_CHARS = 24_000
        const val FALLBACK = "Você é a Aurora, assistente pessoal. Responda em português do Brasil. " +
            "Não afirme ter acesso a ferramentas ou dados que você não tem."
    }
}
