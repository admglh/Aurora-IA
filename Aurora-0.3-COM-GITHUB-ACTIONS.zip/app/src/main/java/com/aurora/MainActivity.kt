package com.aurora

import android.Manifest
import android.app.NotificationManager
import android.content.pm.PackageManager
import android.graphics.drawable.AnimatedImageDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.DocumentsContract
import android.view.ViewGroup
import android.widget.ImageView
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aurora.core.database.ConversationEntity
import com.aurora.core.database.MemoryEntity
import com.aurora.core.database.Roles
import com.aurora.core.extensions.ExtensionManager
import com.aurora.core.model.LocalModelInfo
import com.aurora.core.model.ModelState
import com.aurora.core.theme.AuroraTheme
import com.aurora.core.theme.AuroraThemeSelection
import com.aurora.core.voice.AuroraSpeechRecognizer
import com.aurora.ui.AuroraViewModel
import com.aurora.ui.CloudTestCard
import com.aurora.ui.FilesCard
import com.aurora.ui.MemoryScreenV2
import com.aurora.ui.RoutinesCard
import com.aurora.ui.MessageText
import com.aurora.ui.VoiceStudioCard
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import kotlinx.coroutines.delay

private val BLACK = Color(0xFF000000)
private val BLUE = Color(0xFF1E5EFF)
private val BLUE_SOFT = Color(0xFF123A8A)
private val GOLD = Color(0xFFD7B45A)
private val GOLD_SOFT = Color(0xFF6E5A2D)
private val WHITE = Color(0xFFF2F2F2)
private val MUTED = Color(0xFF777777)
private val PANEL = Color(0xFF050505)
private val RED = Color(0xFFD85A5A)

class MainActivity : ComponentActivity() {
    private var latestVm: AuroraViewModel? = null
    private var pendingShare: android.content.Intent? = null
    private var lastAssistantMessageId = Long.MIN_VALUE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pendingShare = intent
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = BLUE, secondary = GOLD, background = BLACK, surface = PANEL, onSurface = WHITE)) {
                AuroraApp(onVmReady = { latestVm = it; consumeShare() })
            }
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 710)
        }
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        pendingShare = intent
        consumeShare()
    }

    /** "Compartilhar com a Aurora": foto/PDF/documento viram anexo; texto vira rascunho. */
    private fun consumeShare() {
        val vm = latestVm ?: return
        val i = pendingShare ?: return
        pendingShare = null
        if (i.action != android.content.Intent.ACTION_SEND) return
        val uri: Uri? = if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(android.content.Intent.EXTRA_STREAM, Uri::class.java)
        else @Suppress("DEPRECATION") i.getParcelableExtra<Uri>(android.content.Intent.EXTRA_STREAM)
        val text = i.getStringExtra(android.content.Intent.EXTRA_TEXT)
        if (uri != null) vm.attachFile(uri) else if (!text.isNullOrBlank()) vm.shareText(text)
    }

    override fun onResume() {
        super.onResume()
        val vm = latestVm ?: return
        if (vm.bubbleEnabled.value &&
            android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M &&
            android.provider.Settings.canDrawOverlays(this)) {
            runCatching {
                val intent = android.content.Intent(
                    this,
                    com.aurora.service.AuroraBubbleService::class.java
                )
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    startForegroundService(intent)
                } else {
                    startService(intent)
                }
            }
        }
    }

    override fun onStop() {
        super.onStop()
        val vm = latestVm ?: return
        val last = vm.messages.value.lastOrNull { it.role == Roles.ASSISTANT && !it.streaming }
        if (last != null && last.id != Long.MIN_VALUE && last.id != lastAssistantMessageId) {
            lastAssistantMessageId = last.id
            AuroraNotifications.notifyConversationForMessage(this, last.id, last.text)
        }
    }

}

private enum class Screen { HOME, CHAT, TOOLS, TOOL_DETAIL, MEMORY, SETTINGS, SETTING_DETAIL, WARDROBE, CONVERSATIONS }

private data class ToolItem(val name: String, val description: String, val editable: Boolean = true)
private data class SettingItem(val name: String, val description: String)

@Composable
private fun AuroraApp(onVmReady: (AuroraViewModel) -> Unit, vm: AuroraViewModel = viewModel()) {
    LaunchedEffect(vm) { onVmReady(vm) }
    val messages by vm.messages.collectAsState()
    val modelState by vm.modelState.collectAsState()
    val generating by vm.isGenerating.collectAsState()
    val error by vm.error.collectAsState()
    val conversations by vm.conversations.collectAsState()
    val memories by vm.memories.collectAsState()
    val activeId by vm.activeConversationId.collectAsState()
    val animationEnabled by vm.animationEnabled.collectAsState()
    val voiceEnabled by vm.voiceEnabled.collectAsState()
    val voicePitch by vm.voicePitch.collectAsState()
    val voiceRate by vm.voiceRate.collectAsState()
    val localModelName by vm.localModelName.collectAsState()
    val speechModelName by vm.speechModelName.collectAsState()
    val embeddingModelName by vm.embeddingModelName.collectAsState()
    val modelLibrary by vm.modelLibrary.collectAsState()
    val onlineModelCatalog by vm.onlineModelCatalog.collectAsState()
    val themeSelection by vm.themeSelection.collectAsState()
    val personaText by vm.personaText.collectAsState()
    val dailyWord by vm.dailyWord.collectAsState()
    val extensions by vm.extensions.collectAsState()
    val resourceInstallVersion by vm.resourceInstallVersion.collectAsState()
    val downloadProgress by vm.downloadProgress.collectAsState()

    var screen by rememberSaveable { mutableStateOf(Screen.HOME) }
    var selectedTool by rememberSaveable { mutableStateOf("") }
    var selectedSetting by rememberSaveable { mutableStateOf("") }
    var input by rememberSaveable { mutableStateOf("") }
    var showDeleteMemory by remember { mutableStateOf<MemoryEntity?>(null) }
    var showEditMemory by remember { mutableStateOf<MemoryEntity?>(null) }
    var showAddMemory by remember { mutableStateOf(false) }
    var showChats by remember { mutableStateOf(false) }
    var showDeleteModel by remember { mutableStateOf<LocalModelInfo?>(null) }
    var showDeleteSpeech by remember { mutableStateOf(false) }
    var showDeleteEmbedding by remember { mutableStateOf(false) }
    var showDeleteExtension by remember { mutableStateOf<ExtensionManager.Installed?>(null) }
    var pendingOriginalUri by remember { mutableStateOf<Uri?>(null) }
    var pendingInstallPlan by remember { mutableStateOf<ExtensionManager.InstallPlan?>(null) }
    var installVersionBeforePick by remember { mutableIntStateOf(resourceInstallVersion) }
    var showDeleteOriginal by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val activity = context as? ComponentActivity
    var listening by remember { mutableStateOf(false) }
    var permVersion by remember { mutableIntStateOf(0) }
    val handsFree by vm.handsFree.collectAsState()
    val attachName by vm.attachName.collectAsState()
    val sharedText by vm.sharedText.collectAsState()
    val speech = remember(activity, speechModelName) {
        activity?.let { host ->
            AuroraSpeechRecognizer(host, com.aurora.core.voice.OfflineWhisper(context, vm.speechModelFile()), { input = it }, { listening = it }, { vm.showError(it) }, { if (vm.handsFree.value) { input = ""; vm.handsFreeHeard(it) } }, { vm.handsFreeMiss() })
        }
    }
    DisposableEffect(speech) { onDispose { speech?.shutdown() } }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) speech?.start() else vm.showError("Permissão do microfone não concedida.") }
    val phonePermissions = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { vm.refreshAndroidTools(); permVersion++ }
    val requestPhonePermissions = {
        val wanted = buildList {
            add(Manifest.permission.CAMERA)
            add(Manifest.permission.RECORD_AUDIO)
            add(Manifest.permission.READ_CONTACTS)
            add(Manifest.permission.WRITE_CONTACTS)
            add(Manifest.permission.READ_CALENDAR)
            add(Manifest.permission.WRITE_CALENDAR)
            add(Manifest.permission.READ_CALL_LOG)
            add(Manifest.permission.WRITE_CALL_LOG)
            add(Manifest.permission.READ_PHONE_STATE)
            add(Manifest.permission.READ_PHONE_NUMBERS)
            add(Manifest.permission.CALL_PHONE)
            add(Manifest.permission.READ_SMS)
            add(Manifest.permission.SEND_SMS)
            if (Build.VERSION.SDK_INT >= 33) { add(Manifest.permission.POST_NOTIFICATIONS); add(Manifest.permission.READ_MEDIA_IMAGES); add(Manifest.permission.READ_MEDIA_VIDEO); add(Manifest.permission.READ_MEDIA_AUDIO) }
            else { add(Manifest.permission.READ_EXTERNAL_STORAGE) }
            add(Manifest.permission.ACCESS_FINE_LOCATION)
            add(Manifest.permission.ACCESS_COARSE_LOCATION)
            add(Manifest.permission.ACTIVITY_RECOGNITION)
            if (Build.VERSION.SDK_INT >= 31) { add(Manifest.permission.BLUETOOTH_CONNECT); add(Manifest.permission.BLUETOOTH_SCAN) }
        }.filter { ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }.toTypedArray()
        if (wanted.isNotEmpty()) phonePermissions.launch(wanted) else vm.refreshAndroidTools()
    }
    val attachPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(vm::attachFile) }
    val startListening = {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) speech?.start()
        else micPermission.launch(Manifest.permission.RECORD_AUDIO)
    }
    LaunchedEffect(vm, speech) { vm.listenRequests.collect { if (vm.handsFree.value && !vm.isGenerating.value) startListening() } }
    LaunchedEffect(vm) { vm.openChat.collect { screen = Screen.CHAT } }
    LaunchedEffect(sharedText) { sharedText?.let { input = it; vm.consumeSharedText() } }
    LaunchedEffect(screen) { if (screen != Screen.CHAT && vm.handsFree.value) vm.setHandsFree(false) }
    val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(vm::importModel) }
    val speechPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(vm::importSpeechModel) }
    val embeddingPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(vm::importEmbeddingModel) }
    val visionPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(vm::importVisionResource) }
    val resourcePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            pendingOriginalUri = uri
            installVersionBeforePick = resourceInstallVersion
            pendingInstallPlan = vm.inspectResource(uri)
        }
    }

    LaunchedEffect(screen) {
        if (screen == Screen.HOME) vm.refreshDailyWord()
        if (screen == Screen.TOOLS || screen == Screen.TOOL_DETAIL) vm.refreshAndroidTools()
    }
    LaunchedEffect(resourceInstallVersion) {
        if (pendingOriginalUri != null && resourceInstallVersion > installVersionBeforePick) {
            pendingInstallPlan = null
            showDeleteOriginal = true
        }
    }
    val listState = rememberLazyListState()
    LaunchedEffect(messages.size, messages.lastOrNull()?.text?.length) {
        if (screen == Screen.CHAT && messages.isNotEmpty()) listState.scrollToItem(messages.lastIndex)
    }

    Scaffold(containerColor = BLACK) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (screen) {
                Screen.HOME -> HomeScreen(themeSelection, animationEnabled, dailyWord, { screen = it }, { screen = Screen.CHAT }, { screen = Screen.CHAT; vm.setHandsFree(true) })
                Screen.CHAT -> ChatScreen(messages, modelState, generating, input, { input = it }, { if (vm.send(input)) input = "" }, vm::stop, vm::speakLast, { showChats = true }, { screen = Screen.HOME }, listState, error, vm::dismissError, listening, { if (listening) speech?.stop() else startListening() }, attachName, { attachPicker.launch(arrayOf("*/*")) }, vm::clearAttachment, handsFree, { vm.setHandsFree(!handsFree) }, { vm.newConversation() })
                Screen.CONVERSATIONS -> ConversationsScreen(conversations, activeId, { vm.openConversation(it); screen = Screen.CHAT }, vm::deleteConversation, { screen = Screen.CHAT })
                Screen.TOOLS -> ToolsScreen({ screen = Screen.HOME }, requestPhonePermissions, permVersion)
                Screen.TOOL_DETAIL -> ToolDetailScreen(selectedTool, { screen = Screen.TOOLS }, vm, requestPhonePermissions)
                Screen.MEMORY -> MemoryScreenV2(memories, { screen = Screen.HOME }, { showDeleteMemory = it }, { showEditMemory = it }, { showAddMemory = true })
                Screen.SETTINGS -> SettingsScreen({ selectedSetting = it; screen = Screen.SETTING_DETAIL }, { screen = Screen.HOME }, { screen = Screen.WARDROBE }, { screen = Screen.MEMORY }, { screen = Screen.TOOLS })
                Screen.SETTING_DETAIL -> SettingDetailScreen(selectedSetting, { screen = Screen.SETTINGS }, vm, localModelName, speechModelName, embeddingModelName, modelLibrary, personaText, animationEnabled, voiceEnabled, voicePitch, voiceRate, modelPicker, speechPicker, embeddingPicker, visionPicker, resourcePicker, extensions, vm.modelCatalog, downloadProgress, vm.extensionCatalog, vm::downloadExtension, { showDeleteModel = it }, { showDeleteSpeech = true }, { showDeleteEmbedding = true }, { showDeleteExtension = it })
                Screen.WARDROBE -> WardrobeScreen(themeSelection, vm::setTheme, vm::clearThemeOverride, { screen = Screen.SETTINGS })
            }
        }
    }

    if (showChats) ConversationsDialog(conversations, activeId, vm::openConversation, vm::deleteConversation) { showChats = false; screen = Screen.CHAT }
    showDeleteMemory?.let { memory -> ConfirmDialog("APAGAR MEMÓRIA", "Esta ação não pode ser desfeita.", "APAGAR", RED, { vm.deleteMemory(memory.id); showDeleteMemory = null }) { showDeleteMemory = null } }
    showEditMemory?.let { memory -> MemoryEditDialog(memory, vm::updateMemory, { showEditMemory = null }) }
    if (showAddMemory) MemoryEditDialog(null, { _, _, _ -> }, { showAddMemory = false }, vm)
    showDeleteModel?.let { model -> ConfirmDialog("APAGAR MODELO", model.fileName, "APAGAR", RED, { vm.deleteLocalModel(model.fileName); showDeleteModel = null }) { showDeleteModel = null } }
    if (showDeleteSpeech) ConfirmDialog("APAGAR MODELO DE VOZ", speechModelName, "APAGAR", RED, { vm.deleteSpeechModel(); showDeleteSpeech = false }) { showDeleteSpeech = false }
    if (showDeleteEmbedding) ConfirmDialog("APAGAR MEMÓRIA SEMÂNTICA", embeddingModelName, "APAGAR", RED, { vm.deleteEmbeddingModel(); showDeleteEmbedding = false }) { showDeleteEmbedding = false }
    showDeleteExtension?.let { item -> ConfirmDialog("APAGAR RECURSO", "${item.name} · ${item.type}", "APAGAR", RED, { vm.deleteExtension(item); showDeleteExtension = null }) { showDeleteExtension = null } }
    pendingInstallPlan?.let { plan ->
        AlertDialog(
            onDismissRequest = { pendingInstallPlan = null; pendingOriginalUri = null },
            title = { Text("INSTALAR RECURSO", color = GOLD) },
            text = { Text("${plan.name}\n\nTipo: ${plan.type}\nDestino: ${plan.destination}\nTamanho: ${if (plan.size >= 0) "%.1f MB".format(plan.size / 1048576.0) else "desconhecido"}", color = WHITE) },
            confirmButton = { TextButton({ pendingInstallPlan = null; pendingOriginalUri?.let(vm::importExtension) }) { Text("INSTALAR", color = GOLD) } },
            dismissButton = { TextButton({ pendingInstallPlan = null; pendingOriginalUri = null }) { Text("CANCELAR", color = WHITE) } }
        )
    }
    if (showDeleteOriginal && pendingOriginalUri != null) {
        ConfirmDialog("INSTALAÇÃO CONCLUÍDA", "O recurso já foi copiado para a Aurora. Quer apagar o arquivo original?", "APAGAR ORIGINAL", RED, {
            val uri = pendingOriginalUri
            runCatching { if (uri != null) DocumentsContract.deleteDocument(context.contentResolver, uri) else false }
                .onFailure { runCatching { if (uri != null) context.contentResolver.delete(uri, null, null) } }
            pendingOriginalUri = null
            showDeleteOriginal = false
        }, { pendingOriginalUri = null; showDeleteOriginal = false })
    }
}

@Composable
private fun HomeScreen(theme: AuroraThemeSelection, animated: Boolean, dailyWord: com.aurora.core.bible.DailyWord?, onOpen: (Screen) -> Unit, onChat: () -> Unit, onTalk: () -> Unit) {
    Box(Modifier.fillMaxSize().background(BLACK)) {
        BinaryBackdrop()
        Column(Modifier.fillMaxSize().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("AURORA", color = WHITE, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(top = 4.dp, bottom = 6.dp))
            AuroraFrame(theme, animated, Modifier.fillMaxWidth().weight(1f).heightIn(min = 200.dp))
            dailyWord?.text?.let {
                Text(it, color = GOLD, textAlign = TextAlign.Center, maxLines = 3, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, modifier = Modifier.padding(vertical = 10.dp))
            }
            MainButton("CONVERSAR", "◉", onChat, Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MainButton("FALAR", "〰", onTalk, Modifier.weight(1f))
                MainButton("MEMÓRIA", "⌁", { onOpen(Screen.MEMORY) }, Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MainButton("ACESSOS", "◇", { onOpen(Screen.TOOLS) }, Modifier.weight(1f))
                MainButton("AJUSTES", "⚙", { onOpen(Screen.SETTINGS) }, Modifier.weight(1f))
            }
            Spacer(Modifier.height(6.dp))
        }
    }
}
@Composable
private fun BinaryBackdrop() {
    Canvas(Modifier.fillMaxSize().alpha(.18f)) {
        val rows = listOf("100111010101010110", "010110101101001011", "110010101011010100", "001101101010111001", "101001010110100101", "011010110100101011")
        rows.forEachIndexed { i, text ->
            drawContext.canvas.nativeCanvas.drawText(text, 12f, 110f + i * 180f, android.graphics.Paint().apply { color = android.graphics.Color.rgb(28, 77, 160); textSize = 26f; typeface = android.graphics.Typeface.MONOSPACE })
        }
    }
}

@Composable
private fun AuroraFrame(theme: AuroraThemeSelection, animated: Boolean, modifier: Modifier) {
    val transition = rememberInfiniteTransition(label = "aurora")
    val scale by transition.animateFloat(.985f, 1.015f, infiniteRepeatable(tween(2200), RepeatMode.Reverse), label = "scale")
    val frameAlpha by transition.animateFloat(.72f, 1f, infiniteRepeatable(tween(1800), RepeatMode.Reverse), label = "alpha")
    val image = when (theme.theme) {
        AuroraTheme.BASE -> R.drawable.aurora_identity_reference
        AuroraTheme.BIRTHDAY -> R.drawable.aurora_theme_birthday
        AuroraTheme.FORMAL -> R.drawable.aurora_theme_formal
        AuroraTheme.SUMMER -> R.drawable.aurora_theme_summer
        AuroraTheme.WINTER -> R.drawable.aurora_theme_winter
        AuroraTheme.EASTER -> R.drawable.aurora_theme_easter
        AuroraTheme.SEPTEMBER_7 -> R.drawable.aurora_theme_september7
        AuroraTheme.HALLOWEEN -> R.drawable.aurora_theme_halloween
    }
    Box(modifier.border(1.dp, BLUE, RoundedCornerShape(28.dp)).padding(7.dp), contentAlignment = Alignment.Center) {
        Box(Modifier.fillMaxSize().border(1.dp, GOLD_SOFT, RoundedCornerShape(22.dp)).clip(RoundedCornerShape(22.dp)).background(BLACK), contentAlignment = Alignment.Center) {
            Image(painterResource(image), null, Modifier.fillMaxSize().graphicsLayer { scaleX = if (animated) scale else 1f; scaleY = if (animated) scale else 1f; alpha = if (animated) frameAlpha else 1f }, contentScale = ContentScale.Fit)
            Canvas(Modifier.fillMaxSize()) {
                drawRect(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = .32f))))
            }
        }
    }
}

@Composable private fun GoldDivider() { Box(Modifier.fillMaxWidth().height(1.dp).background(GOLD.copy(alpha = .55f))) }

@Composable private fun MainButton(text: String, icon: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Surface(modifier.clickable(onClick = onClick).then(modifier).border(1.dp, BLUE.copy(alpha = .75f), RoundedCornerShape(14.dp)), color = Color.Transparent, shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            Text(icon, color = GOLD, modifier = Modifier.padding(end = 7.dp))
            Text(text, color = WHITE, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelMedium)
        }
    }
}

@Composable private fun Header(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(52.dp).clickable(onClick = onBack), contentAlignment = Alignment.Center) { Text("‹", color = BLUE, style = MaterialTheme.typography.headlineMedium) }
        Text(title, color = WHITE, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
    }
}
@Composable private fun ToolsScreen(onBack: () -> Unit, onGrant: () -> Unit, refreshKey: Int) {
    val context = LocalContext.current
    @Suppress("UNUSED_VARIABLE") val key = refreshKey // força recomposição depois que o usuário concede permissões
    val media = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE
    val items = buildList {
        add("Contatos" to listOf(Manifest.permission.READ_CONTACTS))
        add("Agenda" to listOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR))
        add("Mensagens" to listOf(Manifest.permission.SEND_SMS, Manifest.permission.READ_SMS))
        add("Ligações" to listOf(Manifest.permission.CALL_PHONE))
        add("Localização" to listOf(Manifest.permission.ACCESS_FINE_LOCATION))
        add("Fotos" to listOf(media))
        add("Câmera" to listOf(Manifest.permission.CAMERA))
        add("Microfone" to listOf(Manifest.permission.RECORD_AUDIO))
        if (Build.VERSION.SDK_INT >= 33) add("Notificações" to listOf(Manifest.permission.POST_NOTIFICATIONS))
    }
    Column(Modifier.fillMaxSize().background(BLACK)) {
        Header("ACESSOS", onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)) {
            items.forEach { (label, perms) ->
                val ok = perms.all { ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED }
                Row(Modifier.fillMaxWidth().padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(if (ok) "✓" else "✗", color = if (ok) GOLD else RED, fontWeight = FontWeight.Bold, modifier = Modifier.width(30.dp))
                    Text(label, color = WHITE)
                }
            }
            Spacer(Modifier.height(18.dp))
            ActionButton("LIBERAR TUDO", onGrant, GOLD)
            Spacer(Modifier.height(8.dp))
            ActionButton("AJUSTES DO ANDROID", {
                runCatching {
                    context.startActivity(android.content.Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}")))
                }
            })
        }
    }
}
@Composable private fun ToolDetailScreen(name: String, onBack: () -> Unit, vm: AuroraViewModel, onRequestPhonePermissions: () -> Unit) {
    val descriptions = mapOf("INTERNET" to "A Aurora pode pesquisar e ler páginas online. A ferramenta web do droid-mcp bloqueia por padrão endereços privados/loopback.", "GITHUB" to "Integração para consultar repositórios e recursos GitHub. Credenciais próprias podem ser adicionadas separadamente.", "ARQUIVOS" to "Importa e gerencia recursos no armazenamento privado da Aurora.", "CELULAR · 151 CAPACIDADES" to "droid-mcp fornece 151 capacidades Android distribuídas por módulos independentes, incluindo calendário, contatos, SMS, câmera, sensores, localização, rede, aplicativos, automação de interface e web. Permissões e acessos especiais são concedidos pelo usuário quando necessários.", "CÂMERA" to "Entrada visual para câmera, fotos e vídeo.", "VOZ" to "Whisper + sherpa-onnx para STT, TTS, VAD, identificação de voz e recursos de áudio.", "VISÃO" to "MediaPipe e modelos locais para rosto, objetos, pose, gestos, segmentação e embeddings.", "SISTEMA" to "Diagnóstico, armazenamento e desempenho da Aurora.")
    DetailScreen(name, descriptions[name].orEmpty(), onBack) {
        if (name == "GITHUB") Text("GitHub público: disponível como ferramenta de consulta. Credenciais privadas não são compartilhadas com serviços externos.", color = MUTED)
        if (name == "INTERNET") Text("Acesso de rede: ativo no aplicativo. A Aurora não recebe acesso irrestrito ao aparelho só por ter internet.", color = MUTED)
        if (name == "SISTEMA") Text("O diagnóstico deve ser usado para medir desempenho antes de otimizações.", color = MUTED)
        if (name == "CELULAR · 151 CAPACIDADES") ActionButton("LIBERAR ACESSOS DO CELULAR", onRequestPhonePermissions, GOLD)
    }
}

@Composable private fun SettingsScreen(onSelect: (String) -> Unit, onBack: () -> Unit, onWardrobe: () -> Unit, onMemory: () -> Unit, onAccess: () -> Unit) {
    var advanced by remember { mutableStateOf(false) }
    val tiles = listOf(
        Triple("🧠", "NUVEM", { onSelect("🧠 CÉREBRO") }),
        Triple("🎙", "VOZ", { onSelect("🎙 VOZ") }),
        Triple("⌁", "MEMÓRIA", { onMemory() }),
        Triple("◇", "ACESSOS", { onAccess() }),
        Triple("⏰", "ROTINAS", { onSelect("ROTINAS") }),
        Triple("📁", "ARQUIVOS", { onSelect("ARQUIVOS") }),
        Triple("💬", "BOLHA", { onSelect("💬 BOLHA") }),
        Triple("💾", "BACKUP", { onSelect("💾 BACKUP") }),
        Triple("🎨", "VISUAL", { onWardrobe() }),
        Triple("⚙", "AVANÇADO", { advanced = !advanced })
    )
    Column(Modifier.fillMaxSize().background(BLACK)) {
        Header("AJUSTES", onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp)) {
            tiles.chunked(2).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { (icon, label, action) ->
                        Surface(
                            Modifier.weight(1f).height(92.dp).clickable(onClick = action).border(1.dp, BLUE.copy(alpha = .7f), RoundedCornerShape(16.dp)),
                            color = Color.Transparent, shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                Text(icon, color = GOLD, style = MaterialTheme.typography.headlineSmall)
                                Spacer(Modifier.height(4.dp))
                                Text(label, color = WHITE, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }
                }
            }
            if (advanced) {
                listOf("IDENTIDADE", "👁 VISÃO", "PERSONALIDADE", "PLUGINS").forEach { name -> SimpleRow(name, { onSelect(name) }) }
            }
            Spacer(Modifier.height(20.dp))
        }
    }
}
@Composable private fun SettingDetailScreen(name: String, onBack: () -> Unit, vm: AuroraViewModel, localModelName: String, speechModelName: String, embeddingModelName: String, models: List<LocalModelInfo>, persona: String, animation: Boolean, voice: Boolean, pitch: Float, rate: Float, modelPicker: androidx.activity.result.ActivityResultLauncher<Array<String>>, speechPicker: androidx.activity.result.ActivityResultLauncher<Array<String>>, embeddingPicker: androidx.activity.result.ActivityResultLauncher<Array<String>>, visionPicker: androidx.activity.result.ActivityResultLauncher<Array<String>>, resourcePicker: androidx.activity.result.ActivityResultLauncher<Array<String>>, extensions: List<ExtensionManager.Installed>, catalog: List<com.aurora.core.model.CatalogModel>, downloadProgress: Map<String, Float>, extensionCatalog: List<com.aurora.core.extensions.ExtensionCatalogItem>, onDownloadExtension: (com.aurora.core.extensions.ExtensionCatalogItem) -> Unit, onDeleteModel: (LocalModelInfo) -> Unit, onDeleteSpeech: () -> Unit, onDeleteEmbedding: () -> Unit, onDeleteExtension: (ExtensionManager.Installed) -> Unit) {
    Column(Modifier.fillMaxSize().background(BLACK)) {
        Header(name, onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)) {
            when (name) {
                "ROTINAS" -> RoutinesCard(vm)
                "ARQUIVOS" -> FilesCard(vm)
                "IDENTIDADE" -> DetailCard("IDENTIDADE") { Text("Preto absoluto, azul royal, dourado tecnológico e o ambiente visual da Aurora.", color = WHITE); Text("As referências originais permanecem no projeto.", color = MUTED) }
                "🧠 CÉREBRO" -> Column { BrainCard(
                    models, localModelName, modelPicker, catalog + vm.onlineModelCatalog.collectAsState().value, downloadProgress,
                    vm::downloadCatalogModel, onDeleteModel, vm::searchModelsOnline,
                    vm.remoteEndpoint(), vm.remoteModel(), vm.hasRemoteKey(), vm::saveRemoteConfig, vm::clearRemoteConfig
                )
                    CloudTestCard(vm)
                }
                "🎙 VOZ" -> Column {
                    VoiceStudioCard(vm)
                    Spacer(Modifier.height(12.dp))
                    DetailCard("RECONHECIMENTO (MICROFONE OFFLINE)") { Text(if (speechModelName.isBlank()) "Nenhum modelo Whisper importado." else speechModelName, color = WHITE); ActionButton("IMPORTAR VOZ", { speechPicker.launch(arrayOf("*/*")) }); if (speechModelName.isNotBlank()) ActionButton("APAGAR VOZ", onDeleteSpeech, RED) }
                }
                "👁 VISÃO" -> DetailCard("VISÃO") { Text("Importe modelos GGUF, projetores multimodais ou outros recursos de visão.", color = MUTED); ActionButton("IMPORTAR RECURSO DE VISÃO", { visionPicker.launch(arrayOf("*/*")) }); Text("Os arquivos entram no armazenamento privado da Aurora.", color = MUTED) }
                "⌁ MEMÓRIA" -> DetailCard("MEMÓRIA") { Text(if (embeddingModelName.isBlank()) "Memória semântica não instalada." else embeddingModelName, color = WHITE); ActionButton("IMPORTAR MODELO SEMÂNTICO", { embeddingPicker.launch(arrayOf("*/*")) }); if (embeddingModelName.isNotBlank()) ActionButton("APAGAR MODELO SEMÂNTICO", onDeleteEmbedding, RED) }
                "💬 BOLHA" -> {
                    val context = androidx.compose.ui.platform.LocalContext.current
                    val enabled = vm.bubbleEnabled.collectAsState().value
                    DetailCard("BOLHA FLUTUANTE") {
                        Text(
                            "Mostra o ícone da Aurora sobre outros aplicativos.",
                            color = WHITE
                        )
                        Text(
                            if (android.provider.Settings.canDrawOverlays(context))
                                "Permissão de sobreposição: disponível."
                            else
                                "Permissão de sobreposição: ainda não concedida.",
                            color = MUTED
                        )
                        ToggleLine("Bolha da Aurora", enabled, vm::setBubbleEnabled)
                        if (!android.provider.Settings.canDrawOverlays(context)) {
                            ActionButton("PERMITIR SOBRE OUTROS APPS", {
                                val intent = android.content.Intent(
                                    android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    android.net.Uri.parse("package:${context.packageName}")
                                )
                                context.startActivity(intent)
                            })
                        }
                    }
                }
                "💾 BACKUP" -> BackupCard(vm)
                "PERSONALIDADE" -> DetailCard("PERSONALIDADE") { var draft by remember(persona) { mutableStateOf(persona) }; OutlinedTextField(draft, { draft = it }, modifier = Modifier.fillMaxWidth(), minLines = 5, label = { Text("Personalidade") }); ActionButton("SALVAR", { vm.savePersona(draft) }); ActionButton("RESTAURAR", vm::resetPersona, RED) }
                "PLUGINS" -> PluginScreen(extensions, resourcePicker, extensionCatalog, onDownloadExtension, onDeleteExtension)
                else -> DetailCard(name) { Text("Configuração disponível nesta seção.", color = MUTED); ToggleLine("Animações", animation, vm::setAnimationEnabled); ToggleLine("Voz", voice, vm::setVoiceEnabled); Text("Pitch: ${"%.2f".format(pitch)}", color = MUTED); Text("Velocidade: ${"%.2f".format(rate)}", color = MUTED) }
            }
        }
    }
}

@Composable private fun BrainCard(
    models: List<LocalModelInfo>, selected: String,
    picker: androidx.activity.result.ActivityResultLauncher<Array<String>>,
    catalog: List<com.aurora.core.model.CatalogModel>, progress: Map<String, Float>,
    onDownload: (com.aurora.core.model.CatalogModel) -> Unit,
    onDelete: (LocalModelInfo) -> Unit, onSearch: (String) -> Unit,
    remoteEndpoint: String, remoteModel: String, hasRemoteKey: Boolean,
    onSaveRemote: (String, String, String) -> Unit, onClearRemote: () -> Unit
) {
    DetailCard("CÉREBRO") {
        Text(if (selected.isBlank()) "Nenhum cérebro local selecionado." else "Local: $selected", color = WHITE)
        Text(
            if (remoteEndpoint.isNotBlank() && remoteModel.isNotBlank())
                "Nuvem configurada · ${if (hasRemoteKey) "token salvo" else "sem token"}. A nuvem é usada primeiro e o local entra como fallback."
            else "Nuvem não configurada. Se houver GGUF em Download/Aurora, a Aurora tenta encontrá-lo e instalar o melhor automaticamente.",
            color = MUTED, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 4.dp)
        )
        Spacer(Modifier.height(10.dp))
        var endpoint by rememberSaveable(remoteEndpoint) { mutableStateOf(remoteEndpoint) }
        var model by rememberSaveable(remoteModel) { mutableStateOf(remoteModel) }
        var token by rememberSaveable { mutableStateOf("") }
        Text("☁ CÉREBRO NA NUVEM", color = GOLD, fontWeight = FontWeight.Bold)
        OutlinedTextField(endpoint, { endpoint = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Endpoint (ex.: https://servidor/v1)") })
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Modelo remoto") })
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(token, { token = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(if (hasRemoteKey) "Token salvo · deixe vazio para manter" else "Token / APP_TOKEN") })
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ActionButton("USAR NUVEM", { onSaveRemote(endpoint, model, token) }, GOLD, Modifier.weight(1f))
            ActionButton("LIMPAR", onClearRemote, RED, Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        Text("LOCAL", color = GOLD, fontWeight = FontWeight.Bold)
        ActionButton("IMPORTAR GGUF", { picker.launch(arrayOf("application/octet-stream", "*/*")) })
        Spacer(Modifier.height(8.dp))
        if (models.isEmpty()) Text("Nenhum modelo local na biblioteca ainda.", color = MUTED)
        models.forEach { modelInfo ->
            Row(Modifier.fillMaxWidth().padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(modelInfo.fileName, color = if (modelInfo.selected) GOLD else WHITE, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${modelInfo.sizeBytes / (1024 * 1024)} MB${if (modelInfo.selected) " · ATIVO" else ""}", color = MUTED)
                }
                if (!modelInfo.selected) TextButton(onClick = { onDelete(modelInfo) }) { Text("APAGAR", color = RED) }
            }
        }
        Text("A Aurora procura automaticamente GGUF em Download/Aurora e copia somente o cérebro necessário para o armazenamento privado.", color = MUTED, style = MaterialTheme.typography.labelSmall)
        Spacer(Modifier.height(14.dp))
        Text("BIBLIOTECA ONLINE", color = GOLD, fontWeight = FontWeight.Bold)
        var modelQuery by rememberSaveable { mutableStateOf("") }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(modelQuery, { modelQuery = it }, Modifier.weight(1f), singleLine = true, label = { Text("Pesquisar modelos GGUF") })
            Spacer(Modifier.width(6.dp))
            TextButton(enabled = modelQuery.trim().length >= 2, onClick = { onSearch(modelQuery) }) { Text("BUSCAR", color = GOLD) }
        }
        Text("Catálogo público do Hugging Face para baixar modelos sob demanda.", color = MUTED, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(vertical = 5.dp))
        catalog.forEach { item ->
            Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(item.name, color = WHITE, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${item.family} · ${item.quant} · ${item.sizeLabel}", color = MUTED, style = MaterialTheme.typography.labelSmall)
                }
                val p = progress[item.id]
                if (p != null) Text("${(p * 100).toInt()}%", color = GOLD)
                else TextButton({ onDownload(item) }) { Text("BAIXAR", color = GOLD) }
            }
        }
    }
}

@Composable private fun PluginScreen(extensions: List<ExtensionManager.Installed>, picker: androidx.activity.result.ActivityResultLauncher<Array<String>>, catalog: List<com.aurora.core.extensions.ExtensionCatalogItem>, onDownload: (com.aurora.core.extensions.ExtensionCatalogItem) -> Unit, onDelete: (ExtensionManager.Installed) -> Unit) {
    DetailCard("EXTENSÕES") {
        Text("A Aurora pode instalar recursos diretamente pelo Android.", color = WHITE)
        Text("Modelos, visão, voz, memória, plugins, MCP, pacotes e arquivos auxiliares podem ser importados para o armazenamento privado.", color = MUTED, modifier = Modifier.padding(top = 5.dp))
        Spacer(Modifier.height(8.dp))
        ActionButton("+ INSTALAR RECURSO", { picker.launch(arrayOf("*/*")) }, GOLD)
        Spacer(Modifier.height(8.dp))
        if (extensions.isEmpty()) Text("Nenhum recurso adicional instalado.", color = MUTED)
        extensions.forEach { item ->
            Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(item.name, color = WHITE, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${item.type} · ${item.size / (1024 * 1024)} MB", color = MUTED, style = MaterialTheme.typography.labelSmall)
                }
                TextButton({ onDelete(item) }) { Text("APAGAR", color = RED) }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("CATÁLOGO DE EXTENSÕES", color = GOLD, fontWeight = FontWeight.Bold)
        catalog.forEach { item ->
            Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(item.name, color = WHITE, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(item.description, color = MUTED, style = MaterialTheme.typography.labelSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
                TextButton({ onDownload(item) }) { Text("BAIXAR", color = GOLD) }
            }
        }
        Text("Os pacotes baixados são instalados no armazenamento privado; o arquivo temporário de download pode ser apagado depois.", color = MUTED, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable private fun WardrobeScreen(theme: AuroraThemeSelection, setTheme: (AuroraTheme) -> Unit, clear: () -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().background(BLACK)) {
        Header("GUARDA-ROUPA", onBack)
        LazyColumn(Modifier.fillMaxSize().padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Text("Escolha manualmente uma identidade. A seleção dura até o fim do dia; datas especiais continuam podendo ser automáticas.", color = MUTED) }
            AuroraTheme.entries.forEach { t ->
                item { WardrobeRow(t, t == theme.theme, { setTheme(t) }) }
            }
            item { ActionButton("VOLTAR À ESCOLHA AUTOMÁTICA", clear) }
        }
    }
}

@Composable private fun WardrobeRow(theme: AuroraTheme, active: Boolean, onClick: () -> Unit) {
    val image = when (theme) { AuroraTheme.BASE -> R.drawable.aurora_identity_reference; AuroraTheme.BIRTHDAY -> R.drawable.aurora_theme_birthday; AuroraTheme.FORMAL -> R.drawable.aurora_theme_formal; AuroraTheme.SUMMER -> R.drawable.aurora_theme_summer; AuroraTheme.WINTER -> R.drawable.aurora_theme_winter; AuroraTheme.EASTER -> R.drawable.aurora_theme_easter; AuroraTheme.SEPTEMBER_7 -> R.drawable.aurora_theme_september7; AuroraTheme.HALLOWEEN -> R.drawable.aurora_theme_halloween }
    Row(Modifier.fillMaxWidth().height(92.dp).border(1.dp, if (active) GOLD else BLUE.copy(alpha = .5f), RoundedCornerShape(18.dp)).clickable(onClick = onClick).padding(7.dp), verticalAlignment = Alignment.CenterVertically) {
        Image(painterResource(image), null, Modifier.width(82.dp).fillMaxHeight().clip(RoundedCornerShape(13.dp)), contentScale = ContentScale.Crop)
        Text(theme.label, color = if (active) GOLD else WHITE, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 12.dp))
    }
}

@Composable private fun ChatScreen(messages: List<com.aurora.ui.UiMessage>, state: ModelState, generating: Boolean, input: String, onInput: (String) -> Unit, onSend: () -> Unit, onStop: () -> Unit, onSpeak: () -> Unit, onChats: () -> Unit, onBack: () -> Unit, listState: androidx.compose.foundation.lazy.LazyListState, error: String?, dismissError: () -> Unit, listening: Boolean, onVoice: () -> Unit, attachName: String?, onAttach: () -> Unit, onClearAttach: () -> Unit, handsFree: Boolean, onHandsFree: () -> Unit, onNew: () -> Unit) {
    Column(Modifier.fillMaxSize().background(BLACK).imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).clickable(onClick = onBack), contentAlignment = Alignment.Center) { Text("‹", color = BLUE, style = MaterialTheme.typography.headlineMedium) }
            AvatarBlink(44.dp)
            Text("AURORA", color = WHITE, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f).padding(start = 10.dp))
            Box(Modifier.size(46.dp).clickable(onClick = onHandsFree), contentAlignment = Alignment.Center) { Text("〰", color = if (handsFree) GOLD else MUTED, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge) }
            Box(Modifier.size(46.dp).clickable(onClick = onNew), contentAlignment = Alignment.Center) { Text("＋", color = GOLD, style = MaterialTheme.typography.titleLarge) }
            Box(Modifier.size(46.dp).clickable(onClick = onChats), contentAlignment = Alignment.Center) { Text("☰", color = GOLD, style = MaterialTheme.typography.titleLarge) }
        }
        HorizontalDivider(color = GOLD.copy(alpha = .35f))
        LazyColumn(Modifier.weight(1f).padding(horizontal = 10.dp), state = listState, verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(vertical = 12.dp)) {
            items(messages, key = { it.id }) { m -> MessageBubble(m.role == Roles.USER, m.text, m.streaming) }
        }
        if (error != null) Text(error, color = RED, modifier = Modifier.fillMaxWidth().clickable(onClick = dismissError).padding(10.dp))
        if (handsFree) {
            Text(if (listening) "● Ouvindo…" else if (generating) "Pensando…" else "Modo conversa ligado", color = GOLD, modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp), textAlign = TextAlign.Center)
        }
        if (attachName != null) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("📎 $attachName", color = GOLD, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                Box(Modifier.size(44.dp).clickable(onClick = onClearAttach), contentAlignment = Alignment.Center) { Text("✕", color = RED, fontWeight = FontWeight.Bold) }
            }
        }
        Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(8.dp), verticalAlignment = Alignment.Bottom) {
            Button(onClick = onAttach, shape = CircleShape, contentPadding = PaddingValues(0.dp), modifier = Modifier.size(48.dp)) { Text("📎") }
            Spacer(Modifier.width(6.dp))
            OutlinedTextField(input, onInput, Modifier.weight(1f).heightIn(min = 52.dp, max = 130.dp), placeholder = { Text("Fale com a Aurora…") }, enabled = !generating, shape = RoundedCornerShape(18.dp))
            Spacer(Modifier.width(6.dp)); Button(onClick = onVoice, shape = CircleShape, contentPadding = PaddingValues(0.dp), modifier = Modifier.size(48.dp)) { Text(if (listening) "●" else "🎙") }
            Spacer(Modifier.width(6.dp)); Button(onClick = if (generating) onStop else onSend, enabled = generating || input.isNotBlank() || attachName != null, shape = CircleShape, contentPadding = PaddingValues(0.dp), modifier = Modifier.size(48.dp)) { Text(if (generating) "■" else "➤") }
        }
    }
}
@Composable private fun AvatarBlink(size: androidx.compose.ui.unit.Dp) {
    AndroidView(factory = { ctx -> ImageView(ctx).apply { layoutParams = ViewGroup.LayoutParams(-1, -1); scaleType = ImageView.ScaleType.FIT_CENTER; setImageResource(R.drawable.aurora_face_animation); (drawable as? AnimatedImageDrawable)?.start() } }, modifier = Modifier.size(size).clip(CircleShape).border(1.dp, BLUE, CircleShape))
}

@Composable private fun MessageBubble(user: Boolean, text: String, streaming: Boolean) {
    Box(Modifier.fillMaxWidth(), contentAlignment = if (user) Alignment.CenterEnd else Alignment.CenterStart) {
        Surface(
            Modifier.fillMaxWidth(.88f).border(1.dp, if (user) BLUE.copy(alpha = .55f) else GOLD.copy(alpha = .35f), RoundedCornerShape(16.dp)),
            color = if (user) Color(0xFF030A14) else Color(0xFF030303), shape = RoundedCornerShape(16.dp)
        ) { Column(Modifier.padding(12.dp)) { MessageText(text, streaming) } }
    }
}
@Composable private fun ConversationsScreen(items: List<ConversationEntity>, active: Long?, onOpen: (Long) -> Unit, onDelete: (Long) -> Unit, onBack: () -> Unit) { Column(Modifier.fillMaxSize().background(BLACK)) { Header("CONVERSAS", onBack); LazyColumn(Modifier.fillMaxSize().padding(14.dp)) { items(items) { c -> Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) { Text(text = c.title, modifier = Modifier.weight(1f).clickable { onOpen(c.id) }, color = if (c.id == active) GOLD else WHITE); TextButton({ onDelete(c.id) }) { Text("APAGAR", color = RED) } } } } } }

@Composable private fun MemoryScreen(memories: List<MemoryEntity>, onBack: () -> Unit, onDelete: (MemoryEntity) -> Unit, onEdit: (MemoryEntity) -> Unit, onAdd: () -> Unit) { Column(Modifier.fillMaxSize().background(BLACK)) { Header("MEMÓRIA", onBack); LazyColumn(Modifier.fillMaxSize().padding(14.dp)) { item { ActionButton("NOVA MEMÓRIA", onAdd); Spacer(Modifier.height(10.dp)) }; items(memories) { m -> Row(Modifier.fillMaxWidth().padding(vertical = 8.dp).border(1.dp, BLUE.copy(alpha = .35f), RoundedCornerShape(12.dp)).padding(10.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Memória ${m.id}", color = GOLD, fontWeight = FontWeight.Bold); Text(m.kind, color = MUTED) }; TextButton({ onEdit(m) }) { Text("ABRIR", color = WHITE) }; TextButton({ onDelete(m) }) { Text("APAGAR", color = RED) } } } } } }

@Composable private fun MemoryEditDialog(memory: MemoryEntity?, onSave: (Long, String, String) -> Unit, onDismiss: () -> Unit, vm: AuroraViewModel? = null) { var content by remember(memory) { mutableStateOf(memory?.content.orEmpty()) }; var kind by remember(memory) { mutableStateOf(memory?.kind ?: "manual") }; AlertDialog(onDismissRequest = onDismiss, title = { Text(if (memory == null) "NOVA MEMÓRIA" else "MEMÓRIA ${memory.id}") }, text = { Column { OutlinedTextField(content, { content = it }, label = { Text("Conteúdo") }); OutlinedTextField(kind, { kind = it }, label = { Text("Tipo") }) } }, confirmButton = { TextButton({ if (memory == null) vm?.addMemory(content, kind) else onSave(memory.id, content, kind); onDismiss() }) { Text("SALVAR", color = GOLD) } }, dismissButton = { TextButton(onDismiss) { Text("CANCELAR") } }) }

@Composable private fun ConversationsDialog(items: List<ConversationEntity>, active: Long?, onOpen: (Long) -> Unit, onDelete: (Long) -> Unit, onDismiss: () -> Unit) { AlertDialog(onDismissRequest = onDismiss, title = { Text("CONVERSAS") }, text = { LazyColumn { items(items) { c -> Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) { Text(c.title, Modifier.weight(1f).clickable { onOpen(c.id) }, color = if (c.id == active) GOLD else WHITE); TextButton({ onDelete(c.id) }) { Text("APAGAR", color = RED) } } } } }, confirmButton = { TextButton(onDismiss) { Text("FECHAR") } }) }

@Composable private fun SimpleListScreen(title: String, names: List<String>, onBack: () -> Unit, onSelect: (String) -> Unit) { Column(Modifier.fillMaxSize().background(BLACK)) { Header(title, onBack); LazyColumn(Modifier.fillMaxSize().padding(14.dp)) { items(names) { SimpleRow(it) { onSelect(it) } } } } }
@Composable private fun SimpleRow(name: String, onClick: () -> Unit) { Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).border(1.dp, BLUE.copy(alpha = .45f), RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(horizontal = 15.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) { Text(name, color = WHITE, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)); Text("›", color = GOLD) } }
@Composable private fun DetailScreen(name: String, description: String, onBack: () -> Unit, content: @Composable () -> Unit) { Column(Modifier.fillMaxSize().background(BLACK)) { Header(name, onBack); Column(Modifier.padding(14.dp)) { DetailCard(name) { Text(description, color = WHITE); Spacer(Modifier.height(14.dp)); content() } } } }
@Composable private fun DetailCard(title: String, content: @Composable () -> Unit) { Surface(Modifier.fillMaxWidth().border(1.dp, BLUE.copy(alpha = .6f), RoundedCornerShape(18.dp)), color = Color.Transparent, shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(15.dp)) { Text(title, color = GOLD, fontWeight = FontWeight.Bold); Spacer(Modifier.height(10.dp)); content() } } }
@Composable private fun PluginRow(name: String, desc: String) { Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) { Text(name, color = WHITE, modifier = Modifier.weight(1f)); Text(desc, color = MUTED, textAlign = TextAlign.End, modifier = Modifier.weight(1f)) } }
@Composable private fun ToggleLine(name: String, value: Boolean, onChange: (Boolean) -> Unit) { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(text = name, modifier = Modifier.weight(1f), color = WHITE); Switch(checked = value, onCheckedChange = onChange) } }
@Composable private fun ActionButton(text: String, onClick: () -> Unit, color: Color = BLUE, modifier: Modifier = Modifier) { TextButton(onClick = onClick, modifier = modifier.fillMaxWidth().border(1.dp, color.copy(alpha = .6f), RoundedCornerShape(12.dp))) { Text(text, color = color, fontWeight = FontWeight.Bold) } }
@Composable private fun BackupCard(vm: AuroraViewModel) {
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { it?.let(vm::exportBackup) }
    val import = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(vm::importBackup) }
    DetailCard("BACKUP") {
        Text("Salva conversas e memórias num arquivo JSON para você guardar (o app não faz backup na nuvem). Importar não duplica o que já existe.", color = MUTED)
        ActionButton("EXPORTAR TUDO", { export.launch("aurora-backup-" + java.time.LocalDate.now() + ".json") }, GOLD)
        ActionButton("IMPORTAR BACKUP", { import.launch(arrayOf("application/json", "*/*")) })
    }
}
@Composable private fun ConfirmDialog(title: String, message: String, action: String, color: Color, onConfirm: () -> Unit, onDismiss: () -> Unit) { AlertDialog(onDismissRequest = onDismiss, title = { Text(title) }, text = { Text(message, color = MUTED) }, confirmButton = { TextButton(onConfirm) { Text(action, color = color) } }, dismissButton = { TextButton(onDismiss) { Text("CANCELAR") } }) }
