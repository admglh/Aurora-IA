#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
BASE="${AURORA_BASE:-$HOME/Aurora Projeto}"
ZIP="$HOME/zip da Aurora"
mkdir -p "$BASE"/{ferramentas/{bin,src,mcp},memória,modelo,visão,voz,extensoes,cache} "$ZIP"
log(){ printf '\n[AURORA] %s\n' "$*"; }
need(){ command -v "$1" >/dev/null 2>&1 || { log "Instalando $1"; pkg install -y "$1"; }; }
log "Preparando Termux"
pkg update -y
for p in git cmake ninja clang make python curl wget unzip zip jq golang nodejs; do need "$p"; done
python -m pip install --user --upgrade pip huggingface_hub || true

clone(){ repo="$1"; out="$2"; if [ ! -d "$out/.git" ]; then git clone --depth 1 "$repo" "$out"; else git -C "$out" pull --ff-only || true; fi; }

log "llama.cpp — motor local GGUF"
clone https://github.com/ggml-org/llama.cpp.git "$BASE/ferramentas/src/llama.cpp"
cmake -S "$BASE/ferramentas/src/llama.cpp" -B "$BASE/ferramentas/src/llama.cpp/build" -G Ninja -DCMAKE_BUILD_TYPE=Release -DGGML_OPENMP=ON
cmake --build "$BASE/ferramentas/src/llama.cpp/build" --target llama-cli llama-server -j"$(nproc)"
ln -sf "$BASE/ferramentas/src/llama.cpp/build/bin/llama-cli" "$BASE/ferramentas/bin/llama-cli"
ln -sf "$BASE/ferramentas/src/llama.cpp/build/bin/llama-server" "$BASE/ferramentas/bin/llama-server"

log "droid-mcp — todas as capacidades que o SDK fornece"
clone https://github.com/stixez/droid-mcp.git "$BASE/ferramentas/mcp/droid-mcp"
cp -f "$BASE/ferramentas/mcp/droid-mcp/docs/TOOLS.md" "$BASE/ferramentas/mcp/droid-mcp-tools.md" || true

log "MCP servers de referência"
clone https://github.com/modelcontextprotocol/servers.git "$BASE/ferramentas/mcp/servers"

log "GitHub MCP Server oficial"
clone https://github.com/github/github-mcp-server.git "$BASE/ferramentas/mcp/github-mcp-server"
if [ -f "$BASE/ferramentas/mcp/github-mcp-server/go.mod" ]; then
  (cd "$BASE/ferramentas/mcp/github-mcp-server" && go build -o "$BASE/ferramentas/bin/github-mcp-server" ./cmd/github-mcp-server) || log "GitHub MCP Server não compilou neste Termux; fonte foi preservada."
fi

log "MCP oficiais adicionais via npm (quando disponíveis)"
NPMROOT="$BASE/ferramentas/mcp/npm"
mkdir -p "$NPMROOT"
for pkg in \
  @modelcontextprotocol/server-fetch \
  @modelcontextprotocol/server-filesystem \
  @modelcontextprotocol/server-memory \
  @modelcontextprotocol/server-time \
  @modelcontextprotocol/server-git; do
  npm install --prefix "$NPMROOT" "$pkg" || log "Pacote $pkg não pôde ser instalado nesta versão do catálogo; seguindo."
done

log "sherpa-onnx — STT/TTS/VAD e áudio"
mkdir -p "$BASE/voz/sherpa"
latest="$(curl -fsSL https://api.github.com/repos/k2-fsa/sherpa-onnx/releases/latest | jq -r '.tag_name')"
archive="$BASE/voz/sherpa/sherpa-onnx-${latest#v}-android.tar.bz2"
[ -f "$archive" ] || curl -fL "https://github.com/k2-fsa/sherpa-onnx/releases/download/${latest}/sherpa-onnx-${latest#v}-android.tar.bz2" -o "$archive"

if [ "${AURORA_SKIP_SPEECH_MODELS:-0}" != "1" ]; then
  log "Modelos sherpa-onnx de fala: Whisper + VAD + TTS"
  for model in tiny base small medium; do
    f="sherpa-onnx-whisper-$model.tar.bz2"
    [ -f "$BASE/voz/sherpa/$f" ] || curl -fL "https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/$f" -o "$BASE/voz/sherpa/$f" || log "Falha ao baixar $f"
  done
  [ -f "$BASE/voz/sherpa/silero_vad.onnx" ] || curl -fL "https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/silero_vad.onnx" -o "$BASE/voz/sherpa/silero_vad.onnx" || log "Falha ao baixar VAD"
  f="kokoro-multi-lang-v1_1.tar.bz2"
  [ -f "$BASE/voz/sherpa/$f" ] || curl -fL "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/$f" -o "$BASE/voz/sherpa/$f" || log "Falha ao baixar Kokoro"
fi

log "Catálogo local de modelos"
cat > "$BASE/modelo/CATALOGO_MODELOS.txt" <<'CAT'
A Aurora não impõe limite artificial de quantidade ou tamanho.
A interface possui catálogo inicial + pesquisa online no Hugging Face.
GGUF importado e baixado é validado antes de virar modelo utilizável.
CAT

log "Ampliando a biblioteca de modelos"
if [ "${AURORA_SKIP_MODELS:-0}" != "1" ]; then
  bash "$(dirname "$0")/DOWNLOAD_MORE_MODELS.sh" || log "Algum modelo adicional não pôde ser baixado; a biblioteca online continua disponível."
fi

cat > "$BASE/manifesto_instalado.json" <<JSON
{
  "aurora": "0.1",
  "pastas": ["ferramentas","memória","modelo","visão","voz","extensoes"],
  "droid_mcp": "0.11.0",
  "droid_mcp_capabilities": 151,
  "llama_cpp": "https://github.com/ggml-org/llama.cpp",
  "droid_mcp_repo": "https://github.com/stixez/droid-mcp",
  "mcp_servers": "https://github.com/modelcontextprotocol/servers",
  "github_mcp_server": "https://github.com/github/github-mcp-server",
  "sherpa_onnx": "https://github.com/k2-fsa/sherpa-onnx",
  "instalado_em": "$(date -Iseconds)"
}
JSON
log "Pilha instalada em: $BASE"
log "Recursos grandes ficam fora do APK e podem ser apagados do Download depois da importação."
