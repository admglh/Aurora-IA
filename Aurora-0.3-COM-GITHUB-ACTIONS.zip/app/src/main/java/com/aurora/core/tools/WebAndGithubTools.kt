package com.aurora.core.tools

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL

private const val MAX_PAGE_CHARS = 8_000

internal fun htmlToText(html: String): String {
    val prepared = html
        .replace(Regex("(?is)<(script|style|noscript|svg|head)[^>]*>.*?</\\1>"), " ")
        .replace(Regex("(?s)<!--.*?-->"), " ")
        .replace(Regex("(?i)<br\\s*/?>|</(p|div|li|h[1-6]|tr)>"), "\n")
    val text = android.text.Html.fromHtml(prepared, android.text.Html.FROM_HTML_MODE_LEGACY).toString()
    return text.replace('\u00A0', ' ')
        .replace(Regex("[ \\t]+"), " ")
        .replace(Regex("\\n\\s*\\n+"), "\n")
        .trim()
}

class WebFetchTool {
    suspend fun fetch(url: String): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            require(url.startsWith("https://") || url.startsWith("http://")) { "URL inválida" }
            val connection = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 10_000; readTimeout = 20_000; instanceFollowRedirects = true
                setRequestProperty("User-Agent", "Aurora/0.1")
                setRequestProperty("Accept", "text/html,application/json,text/plain;q=0.9,*/*;q=0.8")
            }
            try {
                require(connection.responseCode in 200..299) { "HTTP ${connection.responseCode}" }
                connection.inputStream.bufferedReader().use { it.readText().take(400_000) }.let { raw ->
                    // Antes a página inteira (HTML, scripts, CSS) ia crua para o prompt e estourava o contexto do modelo.
                    val text = if (raw.contains("<html", true) || raw.contains("<body", true)) htmlToText(raw) else raw.trim()
                    text.take(MAX_PAGE_CHARS)
                }
            } finally { connection.disconnect() }
        }
    }
}


class WebSearchTool {
    suspend fun search(query: String): Result<String> = withContext(Dispatchers.IO) { runCatching {
        val q = URLEncoder.encode(query.take(200), "UTF-8")
        val c = (URL("https://html.duckduckgo.com/html/?q=$q").openConnection() as HttpURLConnection).apply {
            connectTimeout=10_000; readTimeout=20_000; instanceFollowRedirects=true
            setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36")
            setRequestProperty("Accept-Language", "pt-BR,pt;q=0.9")
        }
        try {
            require(c.responseCode in 200..299) { "Busca HTTP ${c.responseCode}" }
            val html=c.inputStream.bufferedReader().use { it.readText() }
            val snippets = Regex("class=\"result__snippet\"[^>]*>(.*?)</a>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
                .findAll(html).map { htmlToText(it.groupValues[1]) }.toList()
            val result=Regex("<a[^>]+class=\"result__a\"[^>]*href=\"([^\"]+)\"[^>]*>(.*?)</a>", RegexOption.IGNORE_CASE)
                .findAll(html).take(6).mapIndexed { i, m ->
                    val title=htmlToText(m.groupValues[2])
                    val url=realUrl(m.groupValues[1].replace("&amp;", "&"))
                    val snip=snippets.getOrNull(i).orEmpty()
                    if (snip.isNotBlank()) "$title\n$url\n$snip" else "$title\n$url"
                }.joinToString("\n\n")
            result.ifBlank { "Nenhum resultado encontrado." }
        } finally { c.disconnect() }
    } }
}

/** O DuckDuckGo devolve links de redirecionamento (//duckduckgo.com/l/?uddg=URL_CODIFICADA); extrai o destino real. */
private fun realUrl(href: String): String {
    val m = Regex("[?&]uddg=([^&]+)").find(href) ?: return if (href.startsWith("//")) "https:$href" else href
    return runCatching { java.net.URLDecoder.decode(m.groupValues[1], "UTF-8") }.getOrDefault(href)
}

class GitHubService {
    private fun get(url: String): String {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10_000; readTimeout = 20_000; instanceFollowRedirects = true
            setRequestProperty("Accept", "application/vnd.github+json")
            setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
            setRequestProperty("User-Agent", "Aurora/0.1")
        }
        try { require(c.responseCode in 200..299) { "GitHub HTTP ${c.responseCode}" }; return c.inputStream.bufferedReader().use { it.readText() }.take(160_000) }
        finally { c.disconnect() }
    }

    suspend fun searchRepositories(query: String): Result<String> = withContext(Dispatchers.IO) { runCatching {
        val q = URLEncoder.encode(query, "UTF-8")
        val root = JSONObject(get("https://api.github.com/search/repositories?q=$q&per_page=10"))
        val items = root.optJSONArray("items") ?: JSONArray()
        buildString {
            for (i in 0 until items.length()) {
                val o = items.getJSONObject(i)
                append(o.optString("full_name")).append(" — ").append(o.optString("description")).append("\n")
                append(o.optString("html_url")).append("\n\n")
            }
        }.trim()
    } }

    suspend fun repository(repo: String): Result<String> = withContext(Dispatchers.IO) { runCatching {
        val o = JSONObject(get("https://api.github.com/repos/${repo.trim('/')}"))
        "${o.optString("full_name")}\n${o.optString("description")}\nEstrelas: ${o.optInt("stargazers_count")}\nLinguagem: ${o.optString("language")}\n${o.optString("html_url")}"
    } }

    suspend fun issues(repo: String): Result<String> = withContext(Dispatchers.IO) { runCatching {
        val a = JSONArray(get("https://api.github.com/repos/${repo.trim('/')}/issues?state=open&per_page=10"))
        buildString { for (i in 0 until a.length()) { val o=a.getJSONObject(i); append("#").append(o.optInt("number")).append(" ").append(o.optString("title")).append("\n").append(o.optString("html_url")).append("\n\n") } }.trim()
    } }

    suspend fun releases(repo: String): Result<String> = withContext(Dispatchers.IO) { runCatching {
        val a = JSONArray(get("https://api.github.com/repos/${repo.trim('/')}/releases?per_page=10"))
        buildString { for (i in 0 until a.length()) { val o=a.getJSONObject(i); append(o.optString("tag_name")).append(" — ").append(o.optString("name")).append("\n").append(o.optString("html_url")).append("\n\n") } }.trim()
    } }
}
