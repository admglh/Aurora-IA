# Aurora 0.3 corrigida: notas de auditoria e alterações

## Problemas confirmados na fonte original
- A geração era executada em `AuroraViewModel.viewModelScope`; destruir a Activity podia cancelar a coroutine, embora houvesse um serviço foreground separado.
- `AuroraGenerationService` só exibia a notificação: a geração não era propriedade do serviço.
- A notificação de conversa e a bolha eram acionadas em `MainActivity.onStop()`, portanto não eram publicadas de forma confiável quando a resposta terminava depois que o usuário já havia saído.
- A bolha de sobreposição era um serviço comum, sem foreground notification, e usava o ícone da caneta.
- Perguntas remotas comuns entravam sempre no laço de function-calling e enviavam o conjunto de ferramentas ao Gemini, mesmo quando nenhuma ferramenta era necessária.
- A notificação de conversa usava um canal sem habilitar bolhas e não registrava um atalho de conversa para Android 11+.
- O script `tools/build_apk.sh` copiava o APK com o nome antigo `Aurora-0.1.apk`.

## Alterações aplicadas nesta fonte
- Geração e texto parcial compartilhados pelo `AppContainer`, para sobreviver à recriação da Activity enquanto o processo estiver vivo.
- Controle compartilhado para evitar iniciar duas gerações ao reabrir o app; o botão de parar cancela a geração global.
- Notificação de conclusão emitida quando a resposta termina em segundo plano, com deduplicação por ID da mensagem.
- Serviço da bolha convertido em foreground service `specialUse`, com notificação persistente enquanto a bolha está habilitada.
- Foto circular do rosto da Aurora usada como ícone da bolha e como ícone grande das notificações. O ícone pequeno de status continua monocromático, conforme as regras visuais do Android.
- Canal novo para mensagens, permissão de bolhas e atalho de conversa para Android 11+.
- Chamadas remotas normais deixam de enviar ferramentas desnecessárias; pesquisas e ações explícitas continuam usando o laço de ferramentas.
- Token de autorização normalizado com `trim()`.
- Script e instruções de build atualizados para `Aurora-0.3-CORRIGIDA.apk`.

## Limites de validação
- A auditoria estática do projeto foi executada.
- O XML do Manifest foi validado.
- **O APK corrigido ainda não foi compilado nem testado em um aparelho nesta execução.** O ambiente de análise não conseguiu baixar a distribuição Gradle por falta de acesso à rede. Faça o build no Termux e teste as permissões de notificação/sobreposição no Android.
- O Android pode interromper um processo em caso de encerramento forçado pelo usuário, reinicialização ou restrições do fabricante. Nenhum app consegue garantir continuação após um `Forçar parada`.
