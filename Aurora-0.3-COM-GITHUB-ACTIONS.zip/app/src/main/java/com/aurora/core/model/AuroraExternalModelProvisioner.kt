package com.aurora.core.model

import android.content.ContentUris
import android.content.Context
import android.os.Build
import android.provider.MediaStore
import java.io.File
import java.io.RandomAccessFile

/**
 * Descobre modelos colocados pelo usuário em Download/Aurora sem exigir Termux.
 * Em Android 10+ consulta MediaStore.Downloads; em versões antigas usa o caminho público.
 */
class AuroraExternalModelProvisioner(private val context: Context) {
    data class Candidate(val name: String, val size: Long, val uri: android.net.Uri? = null, val path: File? = null)

    suspend fun importBestChatModel(targetDir: File): File? = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val candidates = discover().filter { isChatCandidate(it) && it.size >= MIN_GGUF_BYTES }
        val best = candidates.maxWithOrNull(compareBy<Candidate> { score(it.name) }.thenByDescending { it.size }) ?: return@withContext null
        val target = File(targetDir, safeName(best.name))
        if (target.exists() && isValidGguf(target)) return@withContext target
        val temp = File(targetDir, ".${target.name}.part")
        runCatching {
            targetDir.mkdirs()
            temp.delete()
            if (best.uri != null) {
                context.contentResolver.openInputStream(best.uri).use { input ->
                    requireNotNull(input) { "Não foi possível ler ${best.name}." }
                    temp.outputStream().use { output -> input.copyTo(output, 1024 * 1024) }
                }
            } else if (best.path != null) {
                best.path.inputStream().use { input -> temp.outputStream().use { output -> input.copyTo(output, 1024 * 1024) } }
            } else error("Fonte do modelo indisponível.")
            require(isValidGguf(temp)) { "${best.name} não é um GGUF válido." }
            check(temp.renameTo(target)) { "Não foi possível instalar ${best.name}." }
            target
        }.onFailure { temp.delete() }.getOrNull()
    }

    fun discover(): List<Candidate> {
        val out = LinkedHashMap<String, Candidate>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            val projection = arrayOf(MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME, MediaStore.Downloads.SIZE, MediaStore.Downloads.RELATIVE_PATH)
            runCatching {
                context.contentResolver.query(collection, projection, null, null, null)?.use { c ->
                    val idCol=c.getColumnIndexOrThrow(MediaStore.Downloads._ID)
                    val nameCol=c.getColumnIndexOrThrow(MediaStore.Downloads.DISPLAY_NAME)
                    val sizeCol=c.getColumnIndexOrThrow(MediaStore.Downloads.SIZE)
                    val pathCol=c.getColumnIndexOrThrow(MediaStore.Downloads.RELATIVE_PATH)
                    while(c.moveToNext()) {
                        val name=c.getString(nameCol).orEmpty()
                        val rel=c.getString(pathCol).orEmpty()
                        if (rel.equals("Download/Aurora/", true) && name.lowercase().endsWith(".gguf")) {
                            val size=c.getLong(sizeCol)
                            val uri=ContentUris.withAppendedId(collection,c.getLong(idCol))
                            out["$rel$name"]=Candidate(name,size,uri=uri)
                        }
                    }
                }
            }
        }
        val publicRoot=File(android.os.Environment.getExternalStorageDirectory(),"Download/Aurora")
        if (publicRoot.exists()) publicRoot.walkTopDown().filter{it.isFile&&it.extension.equals("gguf",true)}.forEach{ out.putIfAbsent(it.absolutePath,Candidate(it.name,it.length(),path=it)) }
        return out.values.toList()
    }

    private fun isChatCandidate(c: Candidate): Boolean {
        val n=c.name.lowercase()
        return n.endsWith(".gguf") && !listOf("mmproj","vision","qwen2.5-vl","rerank","bge","embed").any(n::contains)
    }
    private fun score(name: String): Int {
        val n=name.lowercase()
        var s=0
        if ("qwen3-1.7b" in n) s+=1000
        if ("qwen3" in n) s+=700
        if ("qwen" in n) s+=500
        if ("1.5b" in n || "1.7b" in n || "2b" in n) s+=120
        if ("q4_k_m" in n) s+=60
        if ("q5_k_m" in n) s+=50
        if ("q8_0" in n) s+=30
        if ("instruct" in n) s+=20
        return s
    }
    private fun safeName(n:String)=n.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]"),"_")
    private fun isValidGguf(f:File)=runCatching{if(f.length()<MIN_GGUF_BYTES)return false;RandomAccessFile(f,"r").use{val b=ByteArray(4);it.readFully(b);String(b,Charsets.US_ASCII)=="GGUF"}}.getOrDefault(false)
    companion object { private const val MIN_GGUF_BYTES=4L*1024L*1024L }
}
