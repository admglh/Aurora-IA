# Animação da Aurora

## Estado atual

A presença da Aurora usa animação nativa do Jetpack Compose: escala suave de respiração, pequena flutuação vertical e halo pulsante. Isso é uma animação real de interface, mas não é rigging facial/corporal.

O projeto também inclui `com.airbnb.android:lottie-compose:6.7.1` como runtime de animação vetorial. A dependência está preparada para receber arquivos Lottie locais no futuro.

## Por que Lottie

Lottie renderiza animações exportadas em JSON nativamente no Android. O formato é textual, portanto é um candidato melhor que um formato binário fechado para uma futura camada onde a Aurora possa gerar uma descrição de animação, validar essa descrição e então reproduzi-la localmente.

Isso não significa que a Aurora já gera animações. Nesta versão o runtime está preparado, mas não existe ainda um gerador de animações por IA nem um editor de Lottie dentro do aplicativo.

## Evolução planejada

1. Definir um contrato pequeno e seguro para animações da Aurora.
2. Validar duração, escala, posição, opacidade e limites antes de reproduzir qualquer animação gerada.
3. Permitir apenas animações locais e sem código executável.
4. Conectar o estado NORMAL/OUVINDO/PENSANDO/RESPONDENDO/FALANDO/ERRO ao motor visual.
5. Futuramente permitir que o modelo gere uma animação compatível com esse contrato e, quando apropriado, uma composição Lottie.

A personagem raster continua sendo um recurso visual separado. O runtime não deve fingir que consegue criar rigging de olhos, boca, braços ou cabelo a partir de uma única imagem.
