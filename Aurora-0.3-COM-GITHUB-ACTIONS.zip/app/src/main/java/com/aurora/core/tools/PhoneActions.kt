package com.aurora.core.tools

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.Settings
import android.telephony.SmsManager

/**
 * Ações que ALTERAM o aparelho, executadas por código explícito do app (não pelo modelo): o modelo pequeno
 * não decide nada sozinho. Ligar e enviar SMS exigem confirmação ("sim") na mensagem seguinte.
 * Frases reconhecidas (exemplos): "crie um alarme às 7h30", "timer de 10 minutos", "ligue a lanterna",
 * "volume em 40%", "brilho em 60%", "abra o WhatsApp", "ligue para Maria", "envie uma mensagem para Maria dizendo oi".
 */
class PhoneActions(
    private val context: Context,
    /** Resolve nome -> telefone usando a agenda (droid-mcp). Retorna null se não achar/sem permissão. */
    private val findNumber: suspend (String) -> String?
) {
    private sealed interface Pending {
        data class Sms(val who: String, val number: String, val text: String) : Pending
        data class Call(val who: String, val number: String) : Pending
    }

    @Volatile private var pending: Pending? = null

    /** @return texto de resposta se a mensagem foi tratada aqui; null para seguir o fluxo normal (modelo). */
    suspend fun handle(userText: String): String? {
        val q = userText.trim()
        if (q.isEmpty() || q.length > 600) return null
        val l = q.lowercase()

        pending?.let { p ->
            if (YES.matches(l)) { pending = null; return execute(p) }
            if (NO.matches(l)) { pending = null; return "Certo, cancelei." }
            pending = null // outra conversa: descarta o pedido pendente
        }

        SMS_RE.find(q)?.let { m ->
            val who = m.groupValues[1].trim().trimEnd(',', ':')
            val text = m.groupValues[2].trim()
            if (text.isEmpty()) return "O que devo escrever na mensagem para $who?"
            val number = resolveNumber(who) ?: return "Não achei o número de \"$who\". Diga o número com DDD ou libere o acesso aos contatos em Ferramentas."
            if (context.checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED)
                return "Preciso da permissão de SMS. Toque em Ferramentas → LIBERAR ACESSOS DO CELULAR e permita Mensagens."
            pending = Pending.Sms(who, number, text)
            return "Vou enviar para $who ($number):\n\"$text\"\n\nConfirma? Responda \"sim\" ou \"não\"."
        }

        CALL_RE.find(q)?.let { m ->
            val who = m.groupValues[1].trim().trimEnd('.', '!', '?', ',')
            if (who.isEmpty() || who.split(' ').size > 4) return null
            val number = resolveNumber(who) ?: return "Não achei o número de \"$who\". Diga o número com DDD ou libere o acesso aos contatos em Ferramentas."
            pending = Pending.Call(who, number)
            return "Vou ligar para $who ($number). Confirma? Responda \"sim\" ou \"não\"."
        }

        if (l.contains("alarme") && ALARM_VERB.containsMatchIn(l) || l.contains("me acorde") || l.contains("me desperte")) {
            parseTime(l)?.let { (h, min) -> return setAlarm(h, min, q) }
            return "Para que horas? Diga, por exemplo, \"alarme às 7h30\"."
        }

        TIMER_RE.find(l)?.let { m ->
            val n = m.groupValues[1].toIntOrNull() ?: return null
            val unit = m.groupValues[2]
            val seconds = when {
                unit.startsWith("h") -> n * 3600
                unit.startsWith("min") -> n * 60
                else -> n
            }
            return setTimer(seconds, n, unit)
        }

        if (l.contains("lanterna")) {
            val on = when {
                Regex("\\b(apague|apaga|desligue|desliga|desligar|apagar)\\b").containsMatchIn(l) -> false
                Regex("\\b(acenda|acende|ligue|liga|ligar|acender|ativar|ative)\\b").containsMatchIn(l) -> true
                else -> return null
            }
            return torch(on)
        }

        if (l.contains("volume")) volume(l)?.let { return it }
        if (l.contains("brilho")) brightness(l)?.let { return it }

        APP_RE.find(q)?.let { m -> openApp(m.groupValues[1].trim().trimEnd('.', '!', '?'))?.let { return it } }
        return null
    }

    private suspend fun resolveNumber(who: String): String? {
        val digits = who.filter { it.isDigit() }
        if (digits.length >= 8 && who.all { it.isDigit() || it in " +()-" }) return who.trim()
        return findNumber(who)
    }

    private fun execute(p: Pending): String = when (p) {
        is Pending.Sms -> runCatching {
            val sm = if (Build.VERSION.SDK_INT >= 31) context.getSystemService(SmsManager::class.java) else @Suppress("DEPRECATION") SmsManager.getDefault()
            sm.sendMultipartTextMessage(p.number, null, sm.divideMessage(p.text), null, null)
            "Mensagem enviada para ${p.who}. (O Android aceitou o envio; não consigo confirmar a entrega.)"
        }.getOrElse { "Não consegui enviar: ${it.message ?: it.javaClass.simpleName}" }
        is Pending.Call -> runCatching {
            val granted = context.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
            val i = Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(p.number)))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(i)
            if (granted) "Ligando para ${p.who}…" else "Abri o discador com o número de ${p.who}; toque em ligar. (Libere \"Telefone\" em Ferramentas para eu ligar direto.)"
        }.getOrElse { "Não consegui ligar: ${it.message ?: it.javaClass.simpleName}" }
    }

    private fun parseTime(l: String): Pair<Int, Int>? {
        val m = TIME_RE.find(l) ?: return null
        var h = m.groupValues[1].toIntOrNull() ?: return null
        val min = m.groupValues[2].toIntOrNull() ?: 0
        if ((l.contains("da tarde") || l.contains("da noite")) && h in 1..11) h += 12
        if (h !in 0..23 || min !in 0..59) return null
        return h to min
    }

    private fun setAlarm(h: Int, min: Int, original: String): String = runCatching {
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, min)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "Aurora").putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(i)
        "Alarme criado para %02d:%02d.".format(h, min)
    }.getOrElse { "Não consegui criar o alarme: ${it.message ?: it.javaClass.simpleName}" }

    private fun setTimer(seconds: Int, n: Int, unit: String): String = runCatching {
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, seconds).putExtra(AlarmClock.EXTRA_MESSAGE, "Aurora")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(i)
        "Timer de $n $unit iniciado."
    }.getOrElse { "Não consegui iniciar o timer: ${it.message ?: it.javaClass.simpleName}" }

    private fun torch(on: Boolean): String = runCatching {
        val cm = context.getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            ?: return@runCatching "Este aparelho não tem lanterna acessível."
        cm.setTorchMode(id, on)
        if (on) "Lanterna ligada." else "Lanterna desligada."
    }.getOrElse { "Não consegui mexer na lanterna: ${it.message ?: it.javaClass.simpleName}" }

    private fun volume(l: String): String? = runCatching {
        val am = context.getSystemService(AudioManager::class.java)
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val cur = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val pct = Regex("(\\d{1,3})\\s*%?").find(l)?.groupValues?.get(1)?.toIntOrNull()
        val target = when {
            pct != null -> (pct.coerceIn(0, 100) * max / 100.0).toInt()
            Regex("\\b(aument|sub[ae]|mais alto)").containsMatchIn(l) -> (cur + (max * 0.2).toInt().coerceAtLeast(1)).coerceAtMost(max)
            Regex("\\b(diminu|abaix|baix|menos)").containsMatchIn(l) -> (cur - (max * 0.2).toInt().coerceAtLeast(1)).coerceAtLeast(0)
            Regex("\\b(mut[ea]|silenci)").containsMatchIn(l) -> 0
            else -> return@runCatching null
        }
        am.setStreamVolume(AudioManager.STREAM_MUSIC, target, AudioManager.FLAG_SHOW_UI)
        "Volume de mídia em ${target * 100 / max.coerceAtLeast(1)}%."
    }.getOrElse { "Não consegui ajustar o volume: ${it.message ?: it.javaClass.simpleName}" }

    private fun brightness(l: String): String? {
        val pct = Regex("(\\d{1,3})\\s*%?").find(l)?.groupValues?.get(1)?.toIntOrNull() ?: return null
        if (!Settings.System.canWrite(context)) {
            runCatching {
                context.startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${context.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            return "Para mexer no brilho preciso de \"Modificar configurações do sistema\". Abri a tela: ative para a Aurora e peça de novo."
        }
        return runCatching {
            val v = (pct.coerceIn(1, 100) * 255 / 100)
            Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, v)
            "Brilho em ${pct.coerceIn(1, 100)}%."
        }.getOrElse { "Não consegui ajustar o brilho: ${it.message ?: it.javaClass.simpleName}" }
    }

    /** Só responde se achar o app instalado; senão devolve null e a conversa segue normal. */
    private fun openApp(name: String): String? {
        val wanted = name.lowercase().removePrefix("o ").removePrefix("a ").removePrefix("app ").removePrefix("aplicativo ").trim()
        if (wanted.isEmpty() || wanted.length > 30 || wanted.split(' ').size > 3) return null
        val pm = context.packageManager
        val apps = runCatching {
            pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        }.getOrNull().orEmpty().map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
        val hit = apps.firstOrNull { it.first.equals(wanted, true) }
            ?: apps.firstOrNull { it.first.lowercase().startsWith(wanted) }
            ?: apps.firstOrNull { it.first.lowercase().contains(wanted) }
            ?: return null
        val launch = pm.getLaunchIntentForPackage(hit.second) ?: return null
        return runCatching {
            context.startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "Abrindo ${hit.first}."
        }.getOrElse { "Não consegui abrir ${hit.first}: ${it.message ?: it.javaClass.simpleName}" }
    }

    private companion object {
        val YES = Regex("^(sim|s|confirmo|confirmar|confirma|pode|pode sim|pode enviar|pode ligar|isso|isso mesmo|manda|envie|ok|claro)[.! ]*$")
        val NO = Regex("^(não|nao|n|cancela|cancelar|cancele|deixa|deixa pra lá|esquece)[.! ]*$")
        val SMS_RE = Regex("(?is)\\b(?:envie|enviar|mande|manda|mandar)\\s+(?:uma\\s+)?(?:mensagem|sms|msg|texto)\\s+(?:para|pra|pro|a|ao)\\s+(.+?)\\s*(?:,\\s*)?(?:dizendo|falando|escrevendo|com o texto|:)\\s*:?\\s*(.+)$")
        val CALL_RE = Regex("(?i)\\b(?:ligue|liga|ligar|telefone|chame)\\s+(?:para|pra|pro|a|ao)\\s+(.+)$")
        val ALARM_VERB = Regex("\\b(crie|criar|coloque|colocar|ponha|pôr|defina|definir|configure|programe|agende|acorde|desperte|ative|ativar)\\b")
        val TIME_RE = Regex("(?<![\\p{L}])(?:às|as|para as|pras|para|pra|por volta das)\\s*(\\d{1,2})\\s*(?:[:h]\\s*(\\d{2})?)?\\s*(?:horas?|h)?(?!\\d)")
        val TIMER_RE = Regex("\\b(?:timer|cron[ôo]metro|me avise em|me lembre em)\\s*(?:de|em|para)?\\s*(\\d{1,4})\\s*(horas?|h|minutos?|min|segundos?|seg|s)\\b")
        val APP_RE = Regex("(?i)^\\s*(?:abra|abrir|abre|inicie|iniciar|execute)\\s+(.+)$")
    }
}
