// Aurora · intermediário na nuvem (Cloudflare Workers).
// O app fala com este Worker; a chave do Gemini fica SÓ aqui (nunca dentro do APK).
//
// Variáveis no painel do Cloudflare (Settings > Variables and Secrets):
//   GEMINI_API_KEY (secret)  chave do Google AI Studio
//   APP_TOKEN      (secret)  senha longa que você inventa; é a "chave" que vai no app
//   MODEL          (texto, opcional)  modelo padrão gemini-3.8-flash; body.model tem prioridade
//   MAX_TOKENS     (texto, opcional)  teto de tokens por resposta (padrão 8192)
//   TTS_MODEL      (texto, opcional)  modelo de voz; padrão gemini-3.1-flash-tts-preview (cai para o 2.5 se não existir)
//   IMAGE_MODEL    (texto, opcional)  modelo de imagem; padrão gemini-2.5-flash-image
//
// Rotas:  POST /v1/chat/completions  (chat + ferramentas + imagens de entrada)
//         POST /v1/tts               (voz feminina natural)
//         POST /v1/image             (gera imagem com a mesma chave Gemini)
//         GET  /v1/health

const BASE = "https://generativelanguage.googleapis.com/v1beta";
const UPSTREAM_CHAT = BASE + "/openai/chat/completions";
const MAX_BODY_BYTES = 800_000;
const MIN_TOKENS = 2048; // o "pensamento" do Gemini conta no limite; abaixo disso a resposta pode vir vazia

function json(status, obj) {
  return new Response(JSON.stringify(obj), { status, headers: { "Content-Type": "application/json" } });
}

function safeEqual(a, b) {
  const enc = new TextEncoder();
  const x = enc.encode(a), y = enc.encode(b);
  let diff = x.length ^ y.length;
  for (let i = 0; i < Math.max(x.length, y.length); i++) diff |= (x[i] || 0) ^ (y[i] || 0);
  return diff === 0;
}

async function handleChat(body, env) {
  const cap = parseInt(env.MAX_TOKENS || "8192", 10);
  const asked = typeof body.max_tokens === "number" ? body.max_tokens : cap;
  const out = {
    model: body.model || env.MODEL || "gemini-3.8-flash",
    messages: body.messages,
    stream: body.stream !== false,
    temperature: typeof body.temperature === "number" ? body.temperature : 0.7,
    max_tokens: Math.min(Math.max(asked, MIN_TOKENS), cap),
  };
  if (Array.isArray(body.tools) && body.tools.length > 0) {
    out.tools = body.tools.slice(0, 80);
    out.tool_choice = body.tool_choice || "auto";
  }
  let upstream;
  try {
    upstream = await fetch(UPSTREAM_CHAT, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: "Bearer " + env.GEMINI_API_KEY },
      body: JSON.stringify(out),
    });
  } catch (e) {
    return json(502, { error: "Falha ao falar com o Gemini." });
  }
  return new Response(upstream.body, {
    status: upstream.status,
    headers: {
      "Content-Type": upstream.headers.get("Content-Type") || "application/json",
      "Cache-Control": "no-store",
    },
  });
}

async function callTts(model, text, voice, env) {
  return fetch(BASE + "/models/" + model + ":generateContent", {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-goog-api-key": env.GEMINI_API_KEY },
    body: JSON.stringify({
      contents: [{ parts: [{ text: "Diga em português do Brasil, com voz feminina, natural e calorosa: " + text }] }],
      generationConfig: {
        responseModalities: ["AUDIO"],
        speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: voice } } },
      },
    }),
  });
}

async function handleTts(body, env) {
  const text = String(body.text || "").slice(0, 1500).trim();
  if (!text) return json(400, { error: "Campo 'text' ausente." });
  const voice = String(body.voice || "Kore");
  const models = [env.TTS_MODEL, "gemini-3.1-flash-tts-preview", "gemini-2.5-flash-preview-tts"].filter(Boolean);
  let lastErr = "sem resposta";
  for (const model of models) {
    let r;
    try { r = await callTts(model, text, voice, env); } catch (e) { lastErr = "rede"; continue; }
    if (!r.ok) {
      lastErr = model + " HTTP " + r.status + " " + (await r.text()).slice(0, 200);
      if (r.status === 429) break; // limite: não adianta tentar outro modelo
      continue;
    }
    const data = await r.json();
    const part = data?.candidates?.[0]?.content?.parts?.find((p) => p.inlineData);
    const b64 = part?.inlineData?.data;
    if (b64) return json(200, { pcm: b64, rate: 24000 }); // PCM 16 bits mono 24 kHz
    lastErr = model + " sem áudio";
  }
  return json(502, { error: "Gemini TTS: " + lastErr });
}

async function handleImage(body, env) {
  const prompt = String(body.prompt || "").slice(0, 1500).trim();
  if (!prompt) return json(400, { error: "Campo 'prompt' ausente." });
  const models = [env.IMAGE_MODEL, "gemini-2.5-flash-image", "gemini-3.1-flash-image-preview"].filter(Boolean);
  let lastErr = "sem resposta";
  for (const model of models) {
    let r;
    try {
      r = await fetch(BASE + "/models/" + model + ":generateContent", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-goog-api-key": env.GEMINI_API_KEY },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: { responseModalities: ["IMAGE"] },
        }),
      });
    } catch (e) { lastErr = "rede"; continue; }
    if (!r.ok) {
      lastErr = model + " HTTP " + r.status + " " + (await r.text()).slice(0, 200);
      if (r.status === 429) break;
      continue;
    }
    const data = await r.json();
    const parts = data?.candidates?.[0]?.content?.parts || [];
    const img = parts.find((p) => p.inlineData && String(p.inlineData.mimeType || "").startsWith("image"));
    if (img) return json(200, { image: img.inlineData.data, mime: img.inlineData.mimeType });
    lastErr = model + " sem imagem";
  }
  return json(502, { error: "Gemini imagem: " + lastErr });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname.replace(/\/+$/, "");

    if (request.method === "GET" && (path === "" || path === "/v1/health" || path === "/health")) {
      return json(200, { ok: true, servico: "aurora-nuvem", chave: !!env.GEMINI_API_KEY, token: !!env.APP_TOKEN });
    }
    const isChat = path.endsWith("/chat/completions");
    const isTts = path.endsWith("/tts");
    const isImage = path.endsWith("/image");
    if (request.method !== "POST" || (!isChat && !isTts && !isImage)) {
      return json(404, { error: "Rota não encontrada." });
    }
    if (!env.GEMINI_API_KEY || !env.APP_TOKEN) {
      return json(500, { error: "Servidor sem GEMINI_API_KEY ou APP_TOKEN configurados." });
    }
    const auth = request.headers.get("Authorization") || "";
    const token = auth.startsWith("Bearer ") ? auth.slice(7).trim() : "";
    if (!safeEqual(token, String(env.APP_TOKEN).trim())) {
      return json(401, { error: "Não autorizado." });
    }
    const raw = await request.text();
    if (raw.length > MAX_BODY_BYTES) return json(413, { error: "Pedido grande demais." });
    let body;
    try { body = JSON.parse(raw); } catch { return json(400, { error: "JSON inválido." }); }

    if (isTts) return handleTts(body, env);
    if (isImage) return handleImage(body, env);
    if (!Array.isArray(body.messages) || body.messages.length === 0) {
      return json(400, { error: "Campo 'messages' ausente." });
    }
    return handleChat(body, env);
  },
};
