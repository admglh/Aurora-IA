package com.aurora

import android.app.Application
import android.util.Log
import com.aurora.core.agent.AuroraAgent
import com.aurora.core.agent.MemoryRetriever
import com.aurora.core.agent.PersonaProvider
import com.aurora.core.data.ChatRepository
import com.aurora.core.database.AuroraDatabase
import com.aurora.core.migration.AssetLegacySource
import com.aurora.core.migration.LegacyMigration
import com.aurora.core.model.ModelManager
import com.aurora.core.settings.AuroraSettings
import com.aurora.core.settings.SecretStore
import com.aurora.core.tools.AndroidToolRegistry
import com.aurora.core.tools.BuiltinTools
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow

/** Composição manual das dependências (sem framework de DI). Vive enquanto o processo viver. */
class AppContainer(private val app: Application) {
    init { com.aurora.core.perf.PerfOverrides.init(app) }

    // Sem handler, qualquer exceção em tarefa de segundo plano derruba o app inteiro. Aqui só registramos o erro.
    private val bgErrors = kotlinx.coroutines.CoroutineExceptionHandler { _, t -> Log.e(TAG, "Falha em tarefa de segundo plano", t) }
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default + bgErrors)

    /** Estado da geração vive no processo, para a Activity poder ser recriada sem perder o streaming. */
    val generationText = MutableStateFlow<String?>(null)
    val generationActive = MutableStateFlow(false)
    @Volatile private var activeGenerationJob: Job? = null

    @Synchronized
    fun tryBeginGeneration(): Boolean {
        if (generationActive.value) return false
        generationActive.value = true
        return true
    }

    @Synchronized
    fun attachGenerationJob(job: Job) {
        activeGenerationJob = job
        job.invokeOnCompletion {
            synchronized(this) {
                // Um trabalho antigo não pode apagar o estado de uma geração nova.
                if (activeGenerationJob === job) {
                    activeGenerationJob = null
                    generationText.value = null
                    generationActive.value = false
                }
            }
        }
    }

    @Synchronized
    fun finishGeneration() {
        activeGenerationJob = null
        generationText.value = null
        generationActive.value = false
    }

    fun cancelActiveGeneration() {
        activeGenerationJob?.cancel()
    }

    val settings = AuroraSettings(app)
    val secrets = SecretStore(app)
    val db: AuroraDatabase = AuroraDatabase.get(app)
    val chat = ChatRepository(db)
    val models = ModelManager(app, settings, secrets, appScope)
    val semanticMemory = com.aurora.core.agent.SemanticMemory(app, settings, db.memoryEmbeddings(), appScope)
    val persona = PersonaProvider(app)
    val tools = AndroidToolRegistry(app)
    val files = com.aurora.core.files.FileFinder(app, settings)
    init { tools.builtin = BuiltinTools(app, db.memories(), semanticMemory, settings, secrets, files) }
    init { appScope.launch(Dispatchers.IO) { runCatching { com.aurora.core.routine.Routines.rescheduleAll(app, settings) } } }
    init { appScope.launch(Dispatchers.IO) { runCatching { tools.initDroid() }.onFailure { Log.e(TAG, "droid-mcp falhou ao iniciar", it) } } }
    val agent = AuroraAgent(persona, MemoryRetriever(db.memories(), semanticMemory), models, tools)

    /** Importação da 2.0 + primeira avaliação de modelos. A UI aguarda este Job antes de escolher a conversa inicial. */
    val startup: Job = appScope.launch {
        runCatching { runLegacyImportIfNeeded() }.onFailure { Log.e(TAG, "Importação legada falhou", it) }
        runCatching { models.refresh() }.onFailure { Log.e(TAG, "Carregamento do modelo falhou", it) }
        // Aquece o modelo de embeddings depois do LLM, em segundo plano: a 1ª mensagem não espera por ele.
        runCatching { semanticMemory.warmUp() }.onFailure { Log.e(TAG, "Embeddings falharam", it) }
    }

    private suspend fun runLegacyImportIfNeeded() {
        if (settings.legacyImportDone) return
        val result = LegacyMigration(db, AssetLegacySource(app.assets, "legacy/data")).run()
        settings.lastImportReport = result.summary()
        Log.i(TAG, "Importação Aurora 2.0: ${result.summary()}")
        // Só marca como concluído quando a origem realmente existia e foi processada.
        if (result.fatalError == null && result.filesFound > 0) settings.legacyImportDone = true
    }

    private companion object {
        const val TAG = "AppContainer"
    }
}
