#!/data/data/com.termux/files/usr/bin/bash

A="/storage/emulated/0/Download/Aurora"

echo
echo "=========================================="
echo "       AURORA • DIAGNÓSTICO"
echo "=========================================="
echo

echo "📁 Biblioteca:"
if [ -d "$A" ]; then
    du -sh "$A"
else
    echo "❌ Não encontrada"
fi

echo
echo "🧠 MODELO:"
find "$A/Modelos" -type f 2>/dev/null | head -20

echo
echo "👁️ VISÃO:"
find "$A/Visão" -type f 2>/dev/null | head -20

echo
echo "🧠 MEMÓRIA:"
find "$A/Memória" -type f 2>/dev/null | head -20

echo
echo "🎙️ VOZ:"
find "$A/Voz" -type f 2>/dev/null | head -30

echo
echo "📷 OCR:"
find "$A/Ferramentas/OCR" -type f 2>/dev/null | head -20

echo
echo "🔧 BINÁRIOS:"
command -v llama-cli  >/dev/null && echo "✅ llama-cli"
command -v llama-server >/dev/null && echo "✅ llama-server"
command -v python       >/dev/null && echo "✅ python"
command -v git          >/dev/null && echo "✅ git"
command -v adb          >/dev/null && echo "✅ adb"

echo
echo "=========================================="
echo "Diagnóstico concluído."
echo "=========================================="
