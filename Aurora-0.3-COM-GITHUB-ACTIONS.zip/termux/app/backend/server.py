#!/data/data/com.termux/files/usr/bin/python
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
import json, subprocess, sys, os
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "app"))
from core.config import load, asset
from core.memory import save
C = load()
MODEL = asset(C["models"]["chat"])
FRONT = ROOT / "app" / "frontend"
PERSONALITY = C["personality"]

class Handler(BaseHTTPRequestHandler):
    def send_json(self, obj, code=200):
        b=json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type","application/json; charset=utf-8")
        self.send_header("Content-Length",str(len(b)))
        self.end_headers(); self.wfile.write(b)

    def do_GET(self):
        if self.path == "/api/health":
            self.send_json({"ok": True, "model": str(MODEL), "model_exists": MODEL.exists()})
            return
        if self.path in ("/","/index.html"):
            p=FRONT/"index.html"
            b=p.read_bytes()
            self.send_response(200); self.send_header("Content-Type","text/html; charset=utf-8")
            self.send_header("Content-Length",str(len(b))); self.end_headers(); self.wfile.write(b); return
        self.send_error(404)

    def do_POST(self):
        if self.path != "/api/chat":
            self.send_error(404); return
        try:
            n=int(self.headers.get("Content-Length","0"))
            data=json.loads(self.rfile.read(n))
            msg=str(data.get("message","")).strip()
            if not msg: self.send_json({"error":"Mensagem vazia"},400); return
            if not MODEL.exists():
                self.send_json({"error":f"Modelo não encontrado: {MODEL}"},503); return
            save("Usuário: "+msg)
            prompt=f"{PERSONALITY}\nResponda em português do Brasil. Seja natural, cuidadosa e objetiva.\nUsuário: {msg}\nAurora:"
            cmd=[C["llama_cli"],"-m",str(MODEL),"-c","2048","-n","256",
                 "--reasoning","off","--single-turn","--simple-io","-p",prompt]
            r=subprocess.run(cmd,capture_output=True,text=True,timeout=180)
            raw=(r.stdout or "").strip()
            answer=raw
            if "\nAurora:\n" in raw:
                answer=raw.split("\nAurora:\n",1)[1]
                if "\n[ Prompt:" in answer:
                    answer=answer.split("\n[ Prompt:",1)[0]
                answer=answer.strip()
            if not answer and r.stderr:
                answer=r.stderr.strip()
            save("Aurora: "+answer)
            self.send_json({"reply":answer,"returncode":r.returncode})
        except subprocess.TimeoutExpired:
            self.send_json({"error":"O modelo demorou demais."},504)
        except Exception as e:
            self.send_json({"error":str(e)},500)
    def log_message(self,*args): pass

if __name__=="__main__":
    ThreadingHTTPServer((C["host"],C["port"]),Handler).serve_forever()
