# Runtime de animação de terceiros

## Lottie Android / Lottie Compose

A Aurora usa `com.airbnb.android:lottie-compose:6.7.1` como runtime opcional de animação local.

Projeto: https://github.com/airbnb/lottie-android
Licença do código: Apache License 2.0.

A biblioteca é usada para renderizar animações; ela não concede ao aplicativo um editor After Effects nem um gerador de animações por IA. A camada futura de geração da Aurora deverá produzir somente dados de animação validados pelo próprio aplicativo.
