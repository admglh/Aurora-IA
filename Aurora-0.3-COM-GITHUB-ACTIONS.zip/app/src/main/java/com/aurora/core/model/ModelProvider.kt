package com.aurora.core.model

import com.aurora.core.perf.PerfTrace
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow

/** Estado REAL de um modelo. A UI deve mostrar exatamente isto, nunca um estado inventado. */
sealed class ModelState {
    /** Nada utilizável configurado. [reason] explica por quê, em linguagem para o usuário. */
    data class NotConfigured(val reason: String) : ModelState()
    data class Loading(val detail: String) : ModelState()
    /** Pronto para gerar. [label] descreve a origem (ex.: "Endpoint remoto (modelo X)"). */
    data class Ready(val label: String) : ModelState()
    data object Generating : ModelState()
    /** O modelo não consegue operar (ex.: falha ao carregar). */
    data class Error(val message: String) : ModelState()
}

/** [images]: JPEGs em base64 anexados a esta mensagem (só a nuvem multimodal usa). */
data class ChatMessage(val role: String, val content: String, val images: List<String> = emptyList())

data class GenerationRequest(
    val messages: List<ChatMessage>,
    val maxTokens: Int = ModelLimits.DEFAULT_MAX_TOKENS,
    val temperature: Float = 0.7f,
    /** Medição de latência desta mensagem (no-op quando desligada). Não afeta a geração. */
    val trace: PerfTrace = PerfTrace.NONE
)

interface ModelProvider {
    val id: String
    val label: String
    val state: StateFlow<ModelState>

    /** Prepara o provedor (carregar modelo, validar configuração). Não deve lançar: reporta via [state]. */
    suspend fun load()

    /**
     * Gera a resposta em pedaços de texto (streaming). Lança exceção em caso de falha real.
     * Cancelar a coleta do Flow OU chamar [cancel] interrompe a geração.
     */
    fun generate(request: GenerationRequest): Flow<String>

    fun cancel()
    fun release()
}

/**
 * Limites compartilhados entre o agente (que monta o prompt) e o runtime local (que aloca o contexto).
 *
 * ATENÇÃO — CONTEXT_TOKENS: na rodada 9.2.1 subiu de 2048 para 3072. Consequências:
 *  - RAM: o cache KV cresce linearmente. Para Qwen3-1.7B (28 camadas, 8 cabeças KV, dim 128, KV em f16 — premissas,
 *    o AAR pode usar outro tipo) ≈ 112 KiB/token → ~224 MiB em 2048 vs ~336 MiB em 3072 (+~112 MiB).
 *  - Latência: o custo de prefill depende do tamanho REAL do prompt, não de CONTEXT_TOKENS; mas o buffer maior pode
 *    afetar o tempo de carga/alocação.
 *  - NÃO foi confirmado que o AAR respeita `contextSize` (o log AURORA_PERF api_probe mostra os campos de LlamaConfig).
 */
object ModelLimits {
    const val CONTEXT_TOKENS = 3072
    const val DEFAULT_MAX_TOKENS = 768
    /** Estimativa para pt-BR (~3 caracteres por token em tokenizadores Qwen/Llama). NÃO é contagem real. */
    const val CHARS_PER_TOKEN = 3.0
}
