# Arquitetura Aurora 0.1

```text
Compose UI
   ↓
AuroraViewModel
   ↓
AuroraAgent
   ├── PersonaProvider (asset + arquivo editável)
   ├── MemoryRetriever (Room)
   └── ModelManager
         ├── LocalGgufProvider → llama-android / llama.cpp
         └── OpenAICompatibleProvider → opcional

Room → conversas / mensagens / memórias
AuroraVoice → Android TTS
AuroraSpeechRecognizer → Whisper offline opcional / SpeechRecognizer Android fallback
```

O código nativo próprio da aplicação foi removido porque era um stub que não executava inferência. O runtime llama.cpp é fornecido pelo AAR.

A regra de manutenção é manter UI, agente, persistência e providers desacoplados. Trocar o runtime local não deve exigir reescrever o histórico, memória ou Compose.
