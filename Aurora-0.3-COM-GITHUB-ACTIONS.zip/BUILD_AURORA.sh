#!/bin/sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cd "$ROOT"

if [ ! -f "settings.gradle.kts" ] || [ ! -d "app" ]; then
  echo "ERRO: execute este script na raiz do projeto Aurora."
  exit 2
fi

if [ -x "./gradlew" ]; then
  ./gradlew --no-daemon :app:assembleDebug
else
  echo "ERRO: gradlew nao esta disponivel/executavel."
  echo "No Termux: chmod +x ./gradlew"
  exit 3
fi

APK="$ROOT/app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK" ]; then
  echo "APK GERADO: $APK"
else
  echo "Build terminou sem encontrar o APK esperado."
  exit 4
fi
