package com.aurora.ui

import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aurora.core.database.MemoryEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val P_BLACK = Color(0xFF000000)
private val P_BLUE = Color(0xFF1E5EFF)
private val P_GOLD = Color(0xFFD7B45A)
private val P_WHITE = Color(0xFFF2F2F2)
private val P_MUTED = Color(0xFF8A8A8A)
private val P_RED = Color(0xFFD85A5A)

/** Botão de texto com área de toque confortável (48dp) para ações pequenas como ✕. */
@Composable
private fun TapText(text: String, color: Color, onClick: () -> Unit) {
    Box(Modifier.size(48.dp).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(text, color = color, fontWeight = FontWeight.Bold)
    }
}

/** Resumo matinal + lembretes. */
@Composable
fun RoutinesCard(vm: AuroraViewModel) {
    val cfg by vm.brief.collectAsState()
    val reminders by vm.reminders.collectAsState()
    val context = LocalContext.current
    LaunchedEffect(Unit) { vm.refreshReminders() }
    var city by remember(cfg.city) { mutableStateOf(cfg.city) }
    var topics by remember(cfg.topics) { mutableStateOf(cfg.topics) }

    Column {
        StudioCard("RESUMO DA MANHÃ") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Todo dia", color = P_WHITE, modifier = Modifier.weight(1f))
                Switch(checked = cfg.enabled, onCheckedChange = { vm.updateBrief(cfg.copy(enabled = it, city = city, topics = topics)) })
            }
            Spacer(Modifier.height(8.dp))
            StudioButton("HORÁRIO  %02d:%02d".format(cfg.hour, cfg.minute), P_GOLD) {
                TimePickerDialog(context, { _, h, m -> vm.updateBrief(cfg.copy(hour = h, minute = m, city = city, topics = topics)) }, cfg.hour, cfg.minute, true).show()
            }
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(city, { city = it }, label = { Text("Cidade (clima)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(topics, { topics = it }, label = { Text("Notícias de (ex.: tecnologia, futebol)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            StudioButton("SALVAR") { vm.updateBrief(cfg.copy(city = city, topics = topics)) }
            Spacer(Modifier.height(6.dp))
            StudioButton("VER AGORA", P_GOLD) { vm.updateBrief(cfg.copy(city = city, topics = topics)); vm.briefNow() }
            if (Build.VERSION.SDK_INT >= 31) {
                val am = context.getSystemService(android.app.AlarmManager::class.java)
                if (!am.canScheduleExactAlarms()) {
                    Spacer(Modifier.height(6.dp))
                    StudioButton("ALARMES PRECISOS (hora exata)", P_RED) {
                        runCatching {
                            context.startActivity(
                                Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${context.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        StudioCard("LEMBRETES") {
            if (reminders.isEmpty()) Text("Nenhum. Peça: \"me lembra de ligar pro João em 30 minutos\".", color = P_MUTED)
            val f = remember { SimpleDateFormat("dd/MM HH:mm", Locale("pt", "BR")) }
            reminders.sortedBy { it.at }.forEach { r ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(r.text, color = P_WHITE, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(f.format(Date(r.at)), color = P_GOLD)
                    }
                    TapText("✕", P_RED) { vm.cancelReminder(r.id) }
                }
            }
        }
    }
}

/** Pastas que a Aurora pode vasculhar para achar arquivos. */
@Composable
fun FilesCard(vm: AuroraViewModel) {
    val folders by vm.folders.collectAsState()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { it?.let(vm::addFolder) }
    StudioCard("PASTAS DA AURORA") {
        Text("Ela só lê o que estiver nas pastas que você escolher.", color = P_MUTED)
        Spacer(Modifier.height(8.dp))
        folders.forEach { u ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("📁 " + vm.folderLabel(u), color = P_WHITE, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                TapText("✕", P_RED) { vm.removeFolder(u) }
            }
        }
        Spacer(Modifier.height(8.dp))
        StudioButton("ADICIONAR PASTA", P_GOLD) { picker.launch(null) }
        Spacer(Modifier.height(4.dp))
        Text("Dica: escolha Download e Documentos.", color = P_MUTED)
    }
}

/** Memória: busca, toque para editar, ✕ para apagar. */
@Composable
fun MemoryScreenV2(memories: List<MemoryEntity>, onBack: () -> Unit, onDelete: (MemoryEntity) -> Unit, onEdit: (MemoryEntity) -> Unit, onAdd: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val shown = remember(memories, query) {
        val q = query.trim().lowercase(Locale.ROOT)
        if (q.isEmpty()) memories else memories.filter { it.content.lowercase(Locale.ROOT).contains(q) || it.kind.lowercase(Locale.ROOT).contains(q) }
    }
    Column(Modifier.fillMaxSize().background(P_BLACK)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(52.dp).clickable(onClick = onBack), contentAlignment = Alignment.Center) { Text("‹", color = P_BLUE, style = androidx.compose.material3.MaterialTheme.typography.headlineMedium) }
            Text("MEMÓRIA", color = P_WHITE, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Box(Modifier.size(52.dp).clickable(onClick = onAdd), contentAlignment = Alignment.Center) { Text("+", color = P_GOLD, style = androidx.compose.material3.MaterialTheme.typography.headlineMedium) }
        }
        OutlinedTextField(query, { query = it }, placeholder = { Text("Buscar") }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp))
        Spacer(Modifier.height(8.dp))
        if (shown.isEmpty()) {
            Text(if (memories.isEmpty()) "Ainda vazia. Conforme conversamos, eu vou aprendendo." else "Nada encontrado.", color = P_MUTED, modifier = Modifier.padding(20.dp))
        }
        LazyColumn(Modifier.fillMaxSize().padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(shown, key = { it.id }) { m ->
                Row(
                    Modifier.fillMaxWidth().border(1.dp, P_BLUE.copy(alpha = .45f), RoundedCornerShape(14.dp)).clickable { onEdit(m) }.padding(start = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f).padding(vertical = 10.dp)) {
                        Text(m.content, color = P_WHITE, maxLines = 4, overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.height(3.dp))
                        Text(m.kind, color = P_GOLD, style = androidx.compose.material3.MaterialTheme.typography.labelSmall)
                    }
                    Spacer(Modifier.width(4.dp))
                    TapText("✕", P_RED) { onDelete(m) }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}
