from pathlib import Path
from datetime import datetime
from .config import ROOT
FILE = ROOT / "data" / "memory" / "memory.txt"
def save(text):
    FILE.parent.mkdir(parents=True, exist_ok=True)
    with FILE.open("a", encoding="utf-8") as f:
        f.write(f"[{datetime.now().isoformat(timespec='seconds')}] {text}\n")
def search(term):
    if not FILE.exists(): return []
    return [x.rstrip() for x in FILE.read_text(encoding="utf-8").splitlines() if term.lower() in x.lower()]
