#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
BASE="${AURORA_ASSET_ROOT:-/storage/emulated/0/Download/Aurora}"
mkdir -p "$BASE"/{Modelos,Visão,Memória,Ferramentas/OCR,Voz/Whisper,Voz/TTS,Voz/VAD,Voz/ASR}
move_if_exists(){ src="$1"; dst="$2"; if [ -f "$src" ]; then mkdir -p "$(dirname "$dst")"; mv -n "$src" "$dst"; fi; }
# Migra recursos antigos soltos sem tocar nos arquivos já organizados.
for f in "$BASE"/*.gguf "$BASE"/*.onnx "$BASE"/*.bin "$BASE"/*.zip; do [ -f "$f" ] || continue; n="$(basename "$f")"; l="${n,,}";
  case "$l" in
    *qwen*vl*|*mmproj*|*vision*|*ocr*) move_if_exists "$f" "$BASE/Visão/$n" ;;
    *bge*|*reranker*|*embedding*|*memory*) move_if_exists "$f" "$BASE/Memória/$n" ;;
    *whisper*) move_if_exists "$f" "$BASE/Voz/Whisper/$n" ;;
    *vad*|*silero*) move_if_exists "$f" "$BASE/Voz/VAD/$n" ;;
    *kokoro*|*tts*) move_if_exists "$f" "$BASE/Voz/TTS/$n" ;;
    *.gguf) move_if_exists "$f" "$BASE/Modelos/$n" ;;
    *) move_if_exists "$f" "$BASE/Voz/ASR/$n" ;;
  esac
done
# OCR ONNX espalhado em Ferramentas vai para a pasta canônica.
find "$BASE/Ferramentas" -maxdepth 1 -type f -iname '*.onnx' -exec mv -n {} "$BASE/Ferramentas/OCR/" \; 2>/dev/null || true
# Silero VAD fora da pasta canônica.
find "$BASE" -maxdepth 2 -type f -iname '*silero*v*.onnx' -exec mv -n {} "$BASE/Voz/VAD/" \; 2>/dev/null || true
printf '\n[AURORA] Recursos organizados em:\n%s\n' "$BASE"
find "$BASE" -type f | sort
