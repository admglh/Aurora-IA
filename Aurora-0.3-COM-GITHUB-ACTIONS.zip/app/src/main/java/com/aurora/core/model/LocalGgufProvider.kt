package com.aurora.core.model

import com.aurora.core.perf.ApiProbe
import com.aurora.core.perf.PerfLog
import com.aurora.core.perf.PerfOverrides
import com.aurora.core.perf.PerfTrace
import dev.ffmpegkit.llama.Llama
import dev.ffmpegkit.llama.LlamaConfig
import dev.ffmpegkit.llama.LlamaModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.io.RandomAccessFile

/**
 * Runtime local GGUF usando o AAR llama.cpp (`dev.ffmpegkit-maintained:llama-android`).
 *
 * ── O QUE ESTE PROVIDER FAZ E NÃO FAZ (leia antes de confiar) ──────────────────────────────────────────────
 *  • STREAMING: NÃO existe. `Llama.complete` devolve o texto inteiro no fim. O Flow emite UMA vez. Nada aqui
 *    simula chegada gradual. (Streaming real exige outro runtime/JNI — ver docs/LATENCIA_MEDICAO.md.)
 *  • STOP SEQUENCE: NÃO existe. Nenhuma sequência de parada é enviada ao motor. [sanitize] apenas CORTA o texto
 *    depois que a geração terminou. Se o modelo "continuar o diálogo", o tempo dessa continuação já foi gasto.
 *    A métrica `post_cut_chars` (AURORA_PERF) mostra quanto texto foi gerado e descartado.
 *  • BOTÃO PARAR: NÃO interrompe a inferência nativa. A API do AAR usada aqui não oferece cancelamento. "Parar"
 *    libera a UI na hora, mas a chamada nativa continua até terminar (o resultado é descartado) e a próxima
 *    mensagem espera por ela (`queue_wait`). Enquanto isso o estado fica "Generating".
 *  • "/no_think" (Qwen3): é apenas um texto acrescentado ao `systemPrompt`. NÃO está confirmado que o AAR aplica
 *    template de chat ao systemPrompt, nem que isso desliga o raciocínio. A métrica `think_tag_in_raw` diz, no
 *    aparelho, se ainda aparece <think> na saída crua. É uma HIPÓTESE até medir.
 *  • PRÉ-CARREGAMENTO: [load] carrega os pesos na inicialização do app (AppContainer.startup → ModelManager.refresh).
 *    O custo some da 1ª mensagem SE o modelo ficar residente; `model_load` na 1ª mensagem deve ser ~0ms.
 *    Se o AAR usa mmap, parte do custo pode migrar para a 1ª inferência (paginação): compare inferência #1 e #2.
 */
class LocalGgufProvider(private val modelFile: File) : ModelProvider {
    override val id = "local-gguf"
    override val label = "Modelo local · GGUF / llama.cpp"
    val modelPath: String = modelFile.absolutePath

    private val _state = MutableStateFlow<ModelState>(ModelState.Loading("Verificando modelo local…"))
    override val state: StateFlow<ModelState> = _state.asStateFlow()

    private val generationMutex = Mutex()
    private val worker = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /** Cancelamento POR REQUISIÇÃO: uma flag global deixava uma geração nova "reviver" uma cancelada. */
    private class Ticket { @Volatile var cancelled = false }
    @Volatile private var current: Ticket? = null

    @Volatile private var loadedModel: LlamaModel? = null

    /** Valida e já carrega os pesos na memória, para que a primeira resposta não pague esse custo. */
    override suspend fun load() {
        val validation = validateModel()
        if (validation !is ModelState.Ready) {
            _state.value = validation
            return
        }
        _state.value = ModelState.Loading("Carregando o modelo na memória…")
        val start = System.nanoTime()
        _state.value = try {
            val reused = loadedModel != null
            generationMutex.withLock { withContext(Dispatchers.IO) { ensureLoaded() } }
            PerfLog.line("model_preload=${(System.nanoTime() - start) / 1_000_000}ms already_resident=$reused file_mb=${modelFile.length() / 1_048_576}")
            ModelState.Ready(label)
        } catch (c: CancellationException) {
            throw c
        } catch (t: Throwable) {
            loadError(t)
        }
    }

    override fun generate(request: GenerationRequest): Flow<String> = flow {
        val ticket = Ticket()
        current = ticket
        val job = worker.async { runGeneration(request, ticket) }
        val text = try {
            job.await()
        } catch (c: CancellationException) {
            ticket.cancelled = true // coleta cancelada: a chamada nativa segue, mas o resultado será descartado
            throw c
        }
        if (!ticket.cancelled && text.isNotBlank()) emit(text)
    }

    private suspend fun runGeneration(request: GenerationRequest, ticket: Ticket): String {
        val trace = request.trace
        val queuedAt = System.nanoTime()
        return generationMutex.withLock {
            trace.ms("queue_wait", (System.nanoTime() - queuedAt) / 1_000_000) // >0 = chamada nativa anterior ainda rodando
            if (ticket.cancelled) return@withLock ""
            if (loadedModel == null) {
                val validation = validateModel()
                if (validation !is ModelState.Ready) {
                    _state.value = validation
                    throw IllegalStateException(stateMessage(validation))
                }
            }
            _state.value = ModelState.Generating
            try {
                val wasResident = loadedModel != null
                val model = trace.measure("model_load") { ensureLoaded() }
                trace.note("model_resident", wasResident)

                val noThink = isQwen3 && (PerfOverrides.bool("no_think") ?: true)
                val (system, prompt) = trace.measure("prompt_format") { formatPrompt(request, noThink) }
                trace.note("native_prompt_chars", system.length + prompt.length)

                val startNative = System.nanoTime()
                val result = Llama.complete(model, prompt = prompt, systemPrompt = system, maxTokens = request.maxTokens)
                val inferenceMs = (System.nanoTime() - startNative) / 1_000_000
                trace.ms("inference", inferenceMs)
                ApiProbe.describeResult(trace, result)

                if (ticket.cancelled) return@withLock ""
                val raw = result.text
                val cleaned = trace.measure("postprocess") { sanitize(raw, trace) }
                reportThroughput(trace, raw.length, cleaned.length, inferenceMs, request.maxTokens)
                cleaned
            } catch (t: Throwable) {
                if (ticket.cancelled) return@withLock ""
                _state.value = loadError(t)
                throw t
            } finally {
                if (_state.value is ModelState.Generating) _state.value = ModelState.Ready(label)
            }
        }
    }

    /** Sem API de tokens: números abaixo são ESTIMATIVAS (chars / [ModelLimits.CHARS_PER_TOKEN]), rotuladas como tal. */
    private fun reportThroughput(trace: PerfTrace, rawChars: Int, cleanChars: Int, inferenceMs: Long, maxTokens: Int) {
        if (!trace.enabled) return
        val estTokens = (rawChars / ModelLimits.CHARS_PER_TOKEN).toInt()
        trace.note("raw_out_chars", rawChars)
        trace.note("est_out_tokens", "$estTokens (estimativa; max_tokens=$maxTokens)")
        if (inferenceMs > 0) trace.note("est_tok_per_s", "%.1f (estimativa; inclui prefill)".format(java.util.Locale.US, estTokens * 1000.0 / inferenceMs))
        trace.note("est_hit_max_tokens", estTokens >= maxTokens * 0.9) // true = provavelmente rodou até o limite (sem EOS/stop)
        trace.note("clean_out_chars", cleanChars)
    }

    private fun formatPrompt(request: GenerationRequest, noThink: Boolean): Pair<String, String> {
        val system = request.messages.firstOrNull { it.role == "system" }?.content.orEmpty()
            .let { if (noThink) "$it\n\n/no_think" else it }
        val rendered = request.messages
            .filter { it.role != "system" }
            .joinToString("\n\n") { message ->
                when (message.role) {
                    "user" -> "Usuário: ${message.content}"
                    "assistant" -> "Aurora: ${message.content}"
                    else -> message.content
                }
            }

        val promptBody = if (rendered.length > MAX_PROMPT_CHARS) {
            rendered.takeLast(MAX_PROMPT_CHARS)
        } else {
            rendered
        }

        return system to "$promptBody\n\nAurora:"
    }

    override fun cancel() { current?.cancelled = true }

    /**
     * Libera os pesos SOMENTE quando nenhuma chamada nativa está em andamento (antes, release() podia liberar o
     * modelo no meio de `Llama.complete`). A liberação acontece em segundo plano, após o mutex ficar livre.
     */
    override fun release() {
        current?.cancelled = true
        worker.launch {
            generationMutex.withLock {
                synchronized(this@LocalGgufProvider) {
                    loadedModel?.let { runCatching { Llama.releaseModel(it) } }
                    loadedModel = null
                }
            }
        }
        _state.value = ModelState.NotConfigured("Modelo local descarregado.")
    }

    private val isQwen3: Boolean get() = modelFile.name.lowercase().contains("qwen3")

    private suspend fun ensureLoaded(): LlamaModel {
        loadedModel?.let { return it }
        val threads = performanceThreads()
        ApiProbe.dumpOnce(Llama::class.java, LlamaConfig::class.java)
        PerfLog.line("model_load_begin threads=$threads ctx=${ModelLimits.CONTEXT_TOKENS} cpus=${Runtime.getRuntime().availableProcessors()}")
        val start = System.nanoTime()
        val model = Llama.loadModel(
            modelFile.absolutePath,
            LlamaConfig(contextSize = ModelLimits.CONTEXT_TOKENS, threads = threads)
        )
        PerfLog.line("model_load_native=${(System.nanoTime() - start) / 1_000_000}ms")
        loadedModel = model
        return model
    }

    /**
     * HEURÍSTICA (não validada em aparelho): conta só núcleos de maior frequência máxima, porque em big.LITTLE os
     * núcleos eficientes podem atrasar cada camada. O sysfs pode ser ilegível em alguns aparelhos → fallback cpus/2.
     * Teste alternativas com `threads=N` em aurora-config/perf.cfg (ver docs/LATENCIA_MEDICAO.md).
     */
    private fun performanceThreads(): Int {
        PerfOverrides.int("threads")?.let { return it.coerceIn(1, 12) }
        val cpus = Runtime.getRuntime().availableProcessors()
        val fallback = (cpus / 2).coerceIn(2, 4)
        val freqs = (0 until cpus).mapNotNull {
            runCatching { File("/sys/devices/system/cpu/cpu$it/cpufreq/cpuinfo_max_freq").readText().trim().toLong() }.getOrNull()
        }
        if (freqs.size < cpus || cpus < 2) {
            PerfLog.line("cpu_freq_unreadable → threads fallback=$fallback")
            return fallback
        }
        val top = freqs.max()
        val chosen = freqs.count { it >= top * 0.7 }.coerceIn(2, 6)
        PerfLog.line("cpu_max_freq_khz=${freqs.joinToString(",")} → threads=$chosen")
        return chosen
    }

    private fun loadError(t: Throwable): ModelState.Error = ModelState.Error(
        if (t is OutOfMemoryError) "Memória insuficiente para este modelo. Tente um GGUF menor ou uma quantização mais leve."
        else t.message?.takeIf { it.isNotBlank() } ?: "Falha ao executar o modelo GGUF."
    )

    private fun validateModel(): ModelState {
        if (!modelFile.exists()) return ModelState.NotConfigured("Modelo não encontrado: ${modelFile.name}")
        val size = modelFile.length()
        if (size < MIN_MODEL_BYTES) return ModelState.Error("O arquivo ${modelFile.name} é pequeno demais para um GGUF válido.")
        return try {
            RandomAccessFile(modelFile, "r").use { raf ->
                val magic = ByteArray(4)
                raf.readFully(magic)
                check(String(magic, Charsets.US_ASCII) == "GGUF") { "Cabeçalho GGUF não encontrado." }
            }
            ModelState.Ready(label)
        } catch (t: Throwable) {
            ModelState.Error("GGUF inválido: ${t.message ?: "cabeçalho não reconhecido"}")
        }
    }

    private fun stateMessage(state: ModelState): String = when (state) {
        is ModelState.NotConfigured -> state.reason
        is ModelState.Error -> state.message
        else -> "Modelo local indisponível."
    }

    /**
     * PÓS-PROCESSAMENTO (não é stop sequence): remove <think>…</think> (inclusive truncado) e corta no primeiro turno
     * falso "Usuário:/User:" que NÃO esteja no início do texto. Um prefixo "Aurora:" inicial é apenas removido.
     */
    private fun sanitize(text: String, trace: PerfTrace): String {
        val trimmed = text.trim()
        trace.note("think_tag_in_raw", trimmed.contains("<think>")) // true = /no_think não impediu o raciocínio
        var out = trimmed.replace(THINK_CLOSED, "").replace(THINK_OPEN, "")
        val beforeCut = out.length
        val fake = FAKE_USER_TURN.findAll(out).firstOrNull { it.range.first > 0 }
        if (fake != null) out = out.substring(0, fake.range.first)
        trace.note("post_cut_chars", beforeCut - out.length) // texto gerado e descartado = tempo desperdiçado
        out = out.replace(LEADING_ROLE, "")
        return out.replace(LEADING_USER, "").trim()
    }

    private companion object {
        const val MIN_MODEL_BYTES = 4L * 1024L * 1024L
        const val MAX_PROMPT_CHARS = 12000
        val THINK_CLOSED = Regex("<think>(?s:.*?)</think>")
        val THINK_OPEN = Regex("<think>(?s:.*)$")
        val FAKE_USER_TURN = Regex("(?m)^\\s*(Usuário|User)\\s*:")
        val LEADING_ROLE = Regex("^\\s*(Aurora|Assistant)\\s*:\\s*")
        val LEADING_USER = Regex("^\\s*(Usuário|User)\\s*:\\s*")
    }
}
