package com.aurora.core.theme

import java.time.LocalDate

/** Identidade visual aplicada à presença da Aurora. */
enum class AuroraTheme(val key: String, val label: String) {
    BASE("base", "Aurora"),
    BIRTHDAY("birthday", "Aniversário"),
    FORMAL("formal", "Modo formal"),
    SUMMER("summer", "Dia quente"),
    WINTER("winter", "Dia frio"),
    EASTER("easter", "Páscoa"),
    SEPTEMBER_7("september_7", "7 de Setembro"),
    HALLOWEEN("halloween", "Halloween")
}

data class AuroraThemeSelection(
    val theme: AuroraTheme,
    val reason: String,
    val temporary: Boolean
)

object AuroraThemeResolver {
    fun automatic(date: LocalDate = LocalDate.now()): AuroraThemeSelection {
        val easter = easterSunday(date.year)
        return when (date) {
            date.withMonth(3).withDayOfMonth(29) -> AuroraThemeSelection(AuroraTheme.BIRTHDAY, "Aniversário", false)
            easter.minusDays(2), easter.minusDays(1), easter -> AuroraThemeSelection(AuroraTheme.EASTER, "Páscoa", false)
            date.withMonth(9).withDayOfMonth(7) -> AuroraThemeSelection(AuroraTheme.SEPTEMBER_7, "7 de Setembro", false)
            date.withMonth(10).withDayOfMonth(31) -> AuroraThemeSelection(AuroraTheme.HALLOWEEN, "Halloween", false)
            else -> AuroraThemeSelection(AuroraTheme.BASE, "Identidade principal", false)
        }
    }

    fun intent(text: String): AuroraTheme? {
        val t = text.lowercase()
        if (listOf("aurora normal", "roupa normal", "voltar ao normal", "volta ao normal", "sem tema", "tirar o tema").any(t::contains)) {
            return AuroraTheme.BASE
        }
        val formal = listOf("entrevista", "reunião", "reuniao", "prova", "apresentação", "apresentacao", "trabalho formal")
        if (formal.any(t::contains)) return AuroraTheme.FORMAL

        val outdoor = listOf("parque", "shopping", "passear", "sair", "vou sair")
        if (outdoor.any(t::contains)) {
            val hot = listOf("calor", "quente", "muito quente", "sol forte", "dia quente")
            val cold = listOf("frio", "fria", "gelado", "gelada", "muito frio", "dia frio")
            if (hot.any(t::contains)) return AuroraTheme.SUMMER
            if (cold.any(t::contains)) return AuroraTheme.WINTER
        }
        return null
    }

    /** Algoritmo gregoriano de Meeus/Jones/Butcher para Domingo de Páscoa. */
    fun easterSunday(year: Int): LocalDate {
        val a = year % 19
        val b = year / 100
        val c = year % 100
        val d = b / 4
        val e = b % 4
        val f = (b + 8) / 25
        val g = (b - f + 1) / 3
        val h = (19 * a + b - d - g + 15) % 30
        val i = c / 4
        val k = c % 4
        val l = (32 + 2 * e + 2 * i - h - k) % 7
        val m = (a + 11 * h + 22 * l) / 451
        val month = (h + l - 7 * m + 114) / 31
        val day = ((h + l - 7 * m + 114) % 31) + 1
        return LocalDate.of(year, month, day)
    }
}
