#!/data/data/com.termux/files/usr/bin/bash
set -u
ROOT="${AURORA_ASSET_ROOT:-/storage/emulated/0/Download/Aurora}"
echo "=== INVENTÁRIO AURORA ==="
echo "Raiz: $ROOT"
[ -d "$ROOT" ] || { echo "[FALHA] raiz não encontrada"; exit 1; }
find "$ROOT" -type f -printf '%s\t%p\n' 2>/dev/null | sort -n | awk -F '\t' '{printf "%-10s %s\n", $1, $2}'
echo
echo "=== TOTAIS ==="
du -h -d 2 "$ROOT" 2>/dev/null | sort -h
