package com.aurora.core.tools

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.StatFs
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject

/** Ferramentas locais seguras, executadas somente por código explícito da aplicação. */
interface Tool {
    val name: String
    suspend fun run(args: Map<String, Any?>): String
}

class DeviceInfoTool(private val c: Context) : Tool {
    override val name = "get_device_info"
    override suspend fun run(args: Map<String, Any?>): String =
        "${Build.MANUFACTURER} ${Build.MODEL} — Android ${Build.VERSION.RELEASE} — SDK ${Build.VERSION.SDK_INT}"
}

class StorageInfoTool(private val c: Context) : Tool {
    override val name = "get_storage_info"
    override suspend fun run(args: Map<String, Any?>): String {
        val stats = StatFs(c.filesDir.path)
        val freeGb = stats.availableBytes / 1_000_000_000.0
        return "Armazenamento livre acessível ao app: %.2f GB".format(java.util.Locale.US, freeGb)
    }
}

/** Resultado de uma ferramenta pedida pelo modelo (function calling). */
sealed interface ModelToolResult {
    data class Output(val text: String) : ModelToolResult
    /** Ação sensível: o app pergunta ao usuário antes de executar. */
    data class Confirm(val prompt: String) : ModelToolResult
}

private val CONFIRM_YES = Regex("^(sim|s|confirmo|confirmar|confirma|pode|pode sim|pode enviar|pode fazer|isso|isso mesmo|manda|faça|faca|ok|claro)[.! ]*$")
private val CONFIRM_NO = Regex("^(não|nao|n|cancela|cancelar|cancele|deixa|deixa pra lá|esquece)[.! ]*$")

class AndroidToolRegistry(private val context: Context) {
    val droidMcp = DroidMcpRuntime(context)

    /** Ferramentas próprias (internet, aprender, imagem). Ligadas pelo AppContainer depois que o banco existe. */
    @Volatile var builtin: BuiltinTools? = null

    @Volatile private var permSig: String? = null
    private fun currentPermSig(): String = WATCHED_PERMISSIONS.joinToString("") {
        if (context.checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED) "1" else "0"
    }

    /** Primeira inicialização do droid-mcp (chamada no início do app). */
    fun initDroid() { permSig = currentPermSig(); droidMcp.initialize() }

    /**
     * O droid-mcp só registra módulos cujas permissões já foram concedidas NO MOMENTO da inicialização.
     * Se o usuário liberou algo depois, reinicializa sozinho antes de usar as ferramentas
     * (antes, a Aurora ficava "sem acesso a nada" até reabrir a tela de Ferramentas).
     */
    fun ensureFresh() {
        val now = currentPermSig()
        if (permSig != now) { permSig = now; runCatching { droidMcp.reinitialize() } }
    }

    fun ownToolNames(): Set<String> = builtin?.names ?: emptySet()
    fun takePendingImages(): List<String> = builtin?.takePendingImages() ?: emptyList()

    fun refreshDroidMcp() { permSig = currentPermSig(); droidMcp.reinitialize() }
    private val device = DeviceInfoTool(context)
    private val storage = StorageInfoTool(context)

    /**
     * Leituras do celular que a Aurora faz de verdade quando o usuário pede (somente leitura).
     * [tool] é o nome real da ferramenta do droid-mcp; se ela não estiver registrada (permissão não concedida),
     * a Aurora explica isso em vez de inventar. Argumentos extras desconhecidos são ignorados pelo droid-mcp.
     */
    private class Read(
        val label: String,
        val tool: String,
        val triggers: List<String>,
        val args: (String) -> Map<String, Any?> = { emptyMap() }
    )

    private val reads = listOf(
        Read("bateria", "get_battery_info", listOf("bateria", "carga do celular", "carga do aparelho")),
        Read("wifi", "get_wifi_info", listOf("wifi", "wi-fi")),
        Read("conexão", "get_connectivity", listOf("estou online", "tenho internet", "dados móveis", "dados moveis", "rede móvel", "rede movel", "minha conexão", "minha conexao")),
        Read("próximo alarme", "get_next_alarm", listOf("próximo alarme", "proximo alarme", "meu alarme", "meus alarmes")),
        Read("agenda", "read_calendar", listOf("minha agenda", "meus compromissos", "meu calendário", "meu calendario", "tenho compromisso", "o que tenho hoje", "o que tenho amanhã", "o que tenho amanha")) { mapOf("days" to 7, "limit" to 15) },
        Read("contato", "search_contacts", listOf("telefone do", "telefone da", "número do", "numero do", "número da", "numero da", "contato do", "contato da", "e-mail do", "email do")) { mapOf("query" to extractName(it), "limit" to 5) },
        Read("contatos", "list_contacts", listOf("meus contatos", "lista de contatos")) { mapOf("limit" to 20) },
        Read("localização", "get_current_location", listOf("minha localização", "minha localizacao", "onde estou", "onde eu estou")),
        Read("área de transferência", "read_clipboard", listOf("área de transferência", "area de transferencia", "o que copiei", "o que eu copiei")),
        Read("apps instalados", "list_installed_apps", listOf("apps instalados", "aplicativos instalados", "quais apps eu tenho", "quais aplicativos eu tenho")) { mapOf("limit" to 40) },
        Read("passos", "get_step_count", listOf("quantos passos", "meus passos")),
        Read("tocando agora", "get_now_playing", listOf("o que está tocando", "o que esta tocando", "música tocando", "musica tocando")),
        Read("notificações", "get_active_notifications", listOf("minhas notificações", "minhas notificacoes", "notificações pendentes", "notificacoes pendentes")) { mapOf("limit" to 15) },
        Read("não perturbe", "get_dnd_status", listOf("não perturbe", "nao perturbe")),
        Read("bluetooth", "get_bluetooth_status", listOf("bluetooth")),
        Read("chamadas", "read_call_log", listOf("ligações perdidas", "ligacoes perdidas", "chamadas perdidas", "histórico de chamadas", "historico de chamadas", "últimas ligações", "ultimas ligacoes")) { mapOf("limit" to 10 ) },
        Read("mensagens", "read_messages", listOf("minhas mensagens", "mensagens recebidas", "últimas mensagens", "ultimas mensagens", "meus sms")) { mapOf("limit" to 10) }
    )

    private fun extractName(text: String): String {
        val m = Regex("(?i)(?:telefone|n[úu]mero|contato|e-?mail)\\s+d[oa]s?\\s+(.+)$").find(text.trim())
        return (m?.groupValues?.getOrNull(1) ?: text).trim().trimEnd('?', '.', '!').take(60)
    }

    private val aliases = mapOf(
        "query" to listOf("query", "name", "search", "text", "keyword"),
        "limit" to listOf("limit", "max_results", "max", "count"),
        "days" to listOf("days", "days_ahead", "range_days"),
        "number" to listOf("phone_number", "phoneNumber", "number", "to", "recipient", "address", "phone"),
        "message" to listOf("message", "body", "text", "content")
    )

    /** Propriedades de entrada de cada ferramenta registrada (lidas do próprio droid-mcp em tempo de execução). */
    private fun toolSchemas(): Map<String, Set<String>> = runCatching {
        val raw = droidMcp.listToolsJson().trim()
        val arr = if (raw.startsWith("[")) JSONArray(raw) else JSONObject(raw).optJSONArray("tools") ?: JSONArray()
        val out = LinkedHashMap<String, Set<String>>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val name = o.optString("name")
            if (name.isBlank()) continue
            val schema = o.optJSONObject("inputSchema") ?: o.optJSONObject("input_schema") ?: o.optJSONObject("parameters")
            val keys = schema?.optJSONObject("properties")?.keys()?.asSequence()?.toSet().orEmpty()
            out[name] = keys
        }
        out
    }.getOrDefault(emptyMap())

    /** Traduz argumentos semânticos (query, limit, number…) para os nomes reais que a ferramenta aceita. */
    private fun adapt(tool: String, semantic: Map<String, Any?>): Map<String, Any?> {
        val props = toolSchemas()[tool].orEmpty()
        if (props.isEmpty()) return semantic
        val out = LinkedHashMap<String, Any?>()
        val used = mutableSetOf<String>()
        for ((k, v) in semantic) {
            val target = (aliases[k] ?: listOf(k)).firstNotNullOfOrNull { a -> props.firstOrNull { it.equals(a, true) && it !in used } }
            if (target != null) { out[target] = v; used += target }
        }
        return out
    }

    private suspend fun findContactNumber(name: String): String? {
        if ("search_contacts" !in registeredTools()) return null
        val out = withTimeoutOrNull(8_000) { droidMcp.callTool("search_contacts", adapt("search_contacts", mapOf("query" to name, "limit" to 3))) }
            ?.getOrNull() ?: return null
        return Regex("\\+?\\d[\\d\\s().-]{6,}\\d").find(out)?.value?.trim()
    }

    private val actions = PhoneActions(context) { findContactNumber(it) }

    /** Ações que alteram o aparelho (ligar, SMS, alarme, timer, lanterna, volume, brilho, abrir app). Null = não é uma ação. */
    suspend fun handleAction(userText: String): String? = resolvePending(userText) ?: actions.handle(userText)

    /** Nomes das ferramentas do droid-mcp realmente registradas agora (vazio se ainda não iniciou). */
    private fun registeredTools(): Set<String> =
        Regex("\"name\"\\s*:\\s*\"([^\"]+)\"").findAll(droidMcp.listToolsJson()).map { it.groupValues[1] }.toSet()

    private fun isAskingCapabilities(q: String): Boolean = listOf(
        "o que você consegue", "o que voce consegue", "o que você pode fazer", "o que voce pode fazer",
        "quais suas funções", "quais as suas funções", "quais são suas funções", "suas funcoes", "suas funções",
        "o que você faz", "o que voce faz", "para que você serve", "pra que você serve", "pra que voce serve",
        "o que você acessa", "o que voce acessa", "você acessa meu", "voce acessa meu", "suas capacidades",
        "o que você sabe fazer", "o que voce sabe fazer", "como você pode me ajudar", "como voce pode me ajudar"
    ).any(q::contains)

    /**
     * Resposta FIXA e verdadeira sobre as funções da Aurora (sem passar pelo modelo: instantânea e sem inventar).
     * Retorna null se a mensagem não for essa pergunta.
     */
    fun capabilityAnswer(userText: String): String? {
        val q = userText.lowercase().trim()
        if (q.length > 160 || !isAskingCapabilities(q)) return null
        val tools = registeredTools()
        val ready = reads.filter { it.tool in tools }.map { it.label }.distinct()
        val missing = reads.filter { it.tool !in tools }.map { it.label }.distinct()
        return buildString {
            append("Aqui está o que eu faço de verdade nesta versão:\n\n")
            append("• Conversar, lembrar de você e responder em português, em voz feminina (Configurações → Voz).\n")
            append("• Internet: pesquiso e leio páginas sozinha quando precisar. É consulta, não preciso de autorização.\n")
            append("• Aprender: guardo na memória o que descubro sobre você e o que aprendo na internet (Configurações → Memória; você apaga quando quiser).\n")
            append("• Clima, câmbio, notícias, Wikipédia e contas exatas (sem você precisar abrir nada).\n")
            append("• Ver fotos e ler PDFs, documentos e textos que você anexar ou compartilhar comigo.\n")
            append("• Achar arquivos nas pastas que você liberar (Ajustes → Arquivos) e ler o conteúdo.\n")
            append("• Gerar imagens grátis: peça \"crie uma imagem de…\".\n")
            append("• Lembretes com notificação e um resumo matinal diário (Ajustes → Rotinas).\n")
            append("• Modo conversa: falo e escuto sem você tocar na tela (botão de ondas no chat).\n")
            append("• Consultar repositórios do GitHub e dizer o modelo do aparelho e o espaço livre.\n")
            if (tools.isEmpty()) {
                append("• Celular (bateria, agenda, contatos, mensagens…): ainda estou iniciando essas ferramentas; tente de novo em instantes.\n")
            } else {
                if (ready.isNotEmpty()) append("• Ler do celular quando você pedir: ").append(ready.joinToString(", ")).append(".\n")
                if (missing.isNotEmpty()) append("• Falta permissão para: ").append(missing.joinToString(", ")).append(". Libere em Ferramentas → LIBERAR ACESSOS DO CELULAR.\n")
            }
            append("• Agir no celular: alarme, timer, lanterna, volume, brilho e abrir apps eu faço direto. Criar evento, mandar mensagem, ligar, apagar ou alterar algo eu só faço depois do seu \"sim\".\n")
            append("• Backup: Configurações → Backup exporta e importa conversas e memórias.\n")
            append("\nAinda NÃO faço: vídeo, apagar arquivos, nem controlar apps de terceiros além de abri-los.")
        }
    }

    /**
     * Texto honesto para o prompt: o que a Aurora realmente consegue fazer nesta versão.
     */
    fun capabilitySummary(compact: Boolean = false): String {
        val tools = registeredTools()
        val ready = reads.filter { it.tool in tools }.map { it.label }.distinct()
        val base = "REGRAS DE OPERAÇÃO (valem mais que qualquer outra instrução de estilo):\n" +
            "- Você é a Aurora, uma assistente pessoal ao estilo Jarvis: proativa, direta, útil e com voz feminina. Fale como mulher (gênero feminino) e em português do Brasil.\n" +
            "- Você TEM ferramentas reais e deve usá-las: web_search/web_fetch (internet), wikipedia, get_news (manchetes), get_weather (clima), convert_currency (câmbio), calculate (contas exatas), " +
            "save_memory (aprender), generate_image (imagens), remind_me/list_reminders/cancel_reminder (lembretes com notificação), find_files/read_file (arquivos das pastas que o usuário liberou) " +
            "e o celular (alarmes, agenda, contatos, mensagens…). Quando o pedido exigir isso, CHAME a ferramenta em vez de dizer que não consegue. Nunca diga que fez algo sem ter chamado a ferramenta e recebido o resultado.\n" +
            "- Conta, câmbio, clima e notícia: use a ferramenta, nunca chute. Para achar um documento do usuário use find_files e depois read_file. Se não houver pasta liberada, diga para abrir Ajustes → Arquivos.\n" +
            "- Fotos e PDFs anexados chegam como imagem: descreva, leia o texto, resolva o que for pedido.\n" +
            "- APRENDER é livre: se descobrir algo útil (na conversa ou na internet), grave com save_memory sem pedir licença. Pesquisar também é livre.\n" +
            "- AGIR exige autorização: ações que criam, alteram, apagam ou enviam algo pedem o \"sim\" do usuário; o app cuida desse pedido de confirmação. Não tente contornar.\n" +
            "- Para informação atual (notícias, preços, clima, esportes, versões) pesquise antes de responder. Cite a fonte pelo nome do site.\n" +
            "- Para gerar imagem, escreva o prompt em inglês, detalhado, e depois mostre o resultado com uma frase curta. Não invente links de imagem.\n" +
            "- Respostas curtas e naturais (elas serão faladas em voz alta): sem tabelas, sem markdown pesado, sem listas longas, a menos que peçam.\n" +
            "- Se uma ferramenta falhar ou faltar permissão, diga exatamente isso e como resolver (Ferramentas → LIBERAR ACESSOS DO CELULAR).\n" +
            (if (ready.isNotEmpty()) "- Leituras do celular liberadas agora: " + ready.joinToString(", ") + ".\n" else "") +
            "Os dados lidos por ferramentas locais aparecem em \"Resultados de ferramentas locais\"; use-os para responder."
        if (compact) return base
        val st = droidMcp.status()
        return if (st.unavailableModules.isNotEmpty()) base + "\nAguardando permissão ou indisponíveis: " + st.unavailableModules.joinToString(", ") + "." else base
    }

    // ---- Function calling (nuvem): o modelo escolhe a ferramenta; o app decide se executa, pede confirmação ou bloqueia ----

    private val readTools = setOf(
        "get_battery_info", "get_connectivity", "get_wifi_info", "get_current_location", "get_location_address", "get_next_alarm",
        "get_now_playing", "get_step_count", "get_device_info", "get_storage_info", "get_display_info", "get_bluetooth_status",
        "get_dnd_status", "get_screen_state", "get_data_usage", "get_network_operator", "list_contacts", "search_contacts",
        "read_contact", "read_calendar", "search_events", "read_call_log", "search_call_log", "read_messages", "search_messages",
        "read_clipboard", "list_installed_apps", "get_app_info", "get_active_notifications", "list_downloads", "search_downloads",
        "search_files", "search_media", "list_albums", "list_paired_devices"
    )
    /** Executam direto: reversíveis e de baixo risco. */
    private val directTools = setOf(
        "create_alarm", "create_timer", "toggle_flashlight", "set_volume", "set_brightness", "launch_app",
        "speak_text", "write_clipboard", "vibrate_pattern"
    )
    /** Pedem "sim" do usuário antes: criam/alteram/apagam dados, saem do aparelho ou mexem no que outros veem. */
    private val confirmTools = setOf(
        "create_event", "create_reminder", "create_contact", "set_dnd_mode",
        "send_message", "delete_event", "update_event", "reply_to_notification", "toggle_wifi", "lock_screen",
        "dismiss_notification", "set_wallpaper", "set_ringtone", "take_photo", "share_content", "open_deep_link"
    )

    private class PendingTool(val name: String, val args: Map<String, Any?>)
    @Volatile private var pendingTool: PendingTool? = null

    /** Pedido que parece exigir agir no celular: só então usamos function calling (não streaming). */
    fun looksActionable(userText: String): Boolean = ACTIONABLE.containsMatchIn(userText.lowercase())

    private val VALID_TYPES = setOf("string", "number", "integer", "boolean", "array")

    /**
     * Esquema compatível com o Gemini: tipos válidos, sem "object" aninhado, sem "properties" vazio
     * (o Gemini recusa o pedido inteiro com HTTP 400 nesses casos — era a causa de "não tem acesso a nada").
     * Devolve null quando a ferramenta não tem parâmetros (aí o campo "parameters" é omitido).
     */
    private fun cleanSchema(s: JSONObject?): JSONObject? {
        val props = s?.optJSONObject("properties") ?: return null
        val out = JSONObject()
        val keys = props.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val v = props.optJSONObject(k)
            var type = v?.optString("type").orEmpty()
            if (type !in VALID_TYPES) type = "string"
            val c = JSONObject().put("type", type)
            if (type == "string") v?.optJSONArray("enum")?.let { e ->
                if ((0 until e.length()).all { i -> e.opt(i) is String }) c.put("enum", e)
            }
            if (type == "array") c.put("items", JSONObject().put("type", "string"))
            v?.optString("description")?.take(90)?.takeIf { it.isNotBlank() }?.let { c.put("description", it) }
            out.put(k, c)
        }
        if (out.length() == 0) return null
        val result = JSONObject().put("type", "object").put("properties", out)
        s?.optJSONArray("required")?.let { req ->
            val keep = JSONArray()
            for (i in 0 until req.length()) { val n = req.optString(i); if (out.has(n)) keep.put(n) }
            if (keep.length() > 0) result.put("required", keep)
        }
        return result
    }

    /** Definições (formato OpenAI): ferramentas próprias + as do droid-mcp permitidas e realmente registradas. */
    fun toolSpecs(): JSONArray {
        ensureFresh()
        val allowed = readTools + directTools + confirmTools
        val out = JSONArray()
        builtin?.specs()?.forEach { out.put(it) }
        runCatching {
            val raw = droidMcp.listToolsJson().trim()
            val arr = if (raw.startsWith("[")) JSONArray(raw) else JSONObject(raw).optJSONArray("tools") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val name = o.optString("name")
                if (name !in allowed) continue
                val schema = o.optJSONObject("inputSchema") ?: o.optJSONObject("input_schema") ?: o.optJSONObject("parameters")
                val fnObj = JSONObject().put("name", name).put("description", o.optString("description").take(160))
                cleanSchema(schema)?.let { fnObj.put("parameters", it) }
                out.put(JSONObject().put("type", "function").put("function", fnObj))
            }
        }
        return out
    }

    private fun parseArgs(json: String): Map<String, Any?> = runCatching {
        val o = JSONObject(json.ifBlank { "{}" })
        val m = LinkedHashMap<String, Any?>()
        val keys = o.keys()
        while (keys.hasNext()) { val k = keys.next(); val v = o.opt(k); m[k] = if (v == null || v == JSONObject.NULL) "" else v }
        m
    }.getOrDefault(emptyMap())

    private fun describe(name: String, args: Map<String, Any?>): String =
        name.replace('_', ' ') + if (args.isEmpty()) "" else " " + args.entries.joinToString(", ") { "${it.key}=${it.value.toString().take(120)}" }

    private suspend fun runTool(name: String, args: Map<String, Any?>): String {
        val out = withTimeoutOrNull(10_000) { droidMcp.callTool(name, args) } ?: return "falhou: demorou demais para responder."
        return if (out.isSuccess) out.getOrNull().orEmpty().ifBlank { "feito." } else "falhou: ${out.exceptionOrNull()?.message ?: "erro desconhecido"}"
    }

    /** Executa (ou pede confirmação para) uma ferramenta que o MODELO pediu. */
    suspend fun executeModelTool(name: String, argsJson: String): ModelToolResult {
        val b = builtin
        if (b != null && name in b.names) return ModelToolResult.Output(b.run(name, parseArgs(argsJson)).take(24000))
        if (name !in registeredTools()) return ModelToolResult.Output("indisponível: ferramenta \"$name\" não está liberada (falta permissão em Ferramentas).")
        val args = parseArgs(argsJson)
        return when (name) {
            in readTools, in directTools -> ModelToolResult.Output(runTool(name, args))
            in confirmTools -> {
                pendingTool = PendingTool(name, args)
                ModelToolResult.Confirm("Vou executar: ${describe(name, args)}\n\nConfirma? Responda \"sim\" ou \"não\".")
            }
            else -> ModelToolResult.Output("bloqueada por segurança: ${name}.")
        }
    }

    private suspend fun resolvePending(userText: String): String? {
        val p = pendingTool ?: return null
        val l = userText.trim().lowercase()
        pendingTool = null
        return when {
            CONFIRM_YES.matches(l) -> {
                val r = runTool(p.name, p.args)
                if (r.startsWith("falhou")) "Não consegui: ${r.removePrefix("falhou: ")}" else "Feito. ${r.take(300)}".trim()
            }
            CONFIRM_NO.matches(l) -> "Certo, cancelei."
            else -> null // outra conversa: descarta o pedido e segue
        }
    }

    suspend fun contextualResults(userText: String): List<Pair<String, String>> {
        val q = userText.lowercase()
        val result = mutableListOf<Pair<String, String>>()
        if (listOf("qual meu celular", "qual é meu celular", "qual e meu celular", "modelo do celular", "modelo do aparelho", "qual android", "versão do android", "versao do android", "informações do aparelho", "informacoes do aparelho").any(q::contains)) {
            result += device.name to device.run(emptyMap())
        }
        if (listOf("quanto espaço", "quanto espaco", "armazenamento livre", "espaço livre", "espaco livre", "quanto de memória", "quanto de memoria").any(q::contains)) {
            result += storage.name to storage.run(emptyMap())
        }
        // Leituras do celular via droid-mcp (só quando o usuário pede; no máx. 3 por mensagem para não pesar o prompt).
        val wanted = reads.filter { r -> r.triggers.any(q::contains) }.take(3)
        if (wanted.isNotEmpty()) {
            val tools = registeredTools()
            if (tools.isEmpty()) {
                result += "ferramentas_do_celular" to "ainda estão iniciando; peça ao usuário para tentar de novo em alguns segundos."
                return result
            }
            for (r in wanted) {
                if (r.tool !in tools) {
                    result += r.label to "indisponível: a permissão/ferramenta \"${r.tool}\" não está liberada. Peça ao usuário para tocar em Ferramentas → LIBERAR ACESSOS DO CELULAR."
                    continue
                }
                val out = withTimeoutOrNull(8_000) { droidMcp.callTool(r.tool, adapt(r.tool, r.args(userText))) }
                result += r.label to when {
                    out == null -> "falhou: demorou demais para responder."
                    out.isSuccess -> out.getOrNull().orEmpty().ifBlank { "sem dados." }
                    else -> "falhou: ${out.exceptionOrNull()?.message ?: "erro desconhecido"}"
                }
            }
        }
        return result
    }
}

private val ACTIONABLE = Regex(
    "\\b(alarme|alarmes|timer|cron[ôo]metro|lembrete|lembrar de|me lembre|agenda|agende|agendar|compromisso|evento|reuni[ãa]o|contato|contatos|" +
    "telefone|ligar|ligue|mensagem|mensagens|sms|whatsapp|abrir|abra|bateria|wifi|wi-fi|bluetooth|notifica[çc][ãa]o|notifica[çc][õo]es|" +
    "localiza[çc][ãa]o|onde estou|volume|brilho|lanterna|m[úu]sica|tocando|passos|copiei|copiar|[áa]rea de transfer[êe]ncia|" +
    "n[ãa]o perturbe|apps|aplicativos|downloads|liga[çc][ãa]o|liga[çc][õo]es|chamadas|tirar foto|bloquear|papel de parede|fale|diga em voz)\\b"
)

private val WATCHED_PERMISSIONS = listOf(
    "android.permission.READ_CONTACTS", "android.permission.READ_CALENDAR", "android.permission.WRITE_CALENDAR",
    "android.permission.SEND_SMS", "android.permission.READ_SMS", "android.permission.READ_CALL_LOG",
    "android.permission.ACCESS_FINE_LOCATION", "android.permission.ACTIVITY_RECOGNITION", "android.permission.CAMERA",
    "android.permission.BLUETOOTH_CONNECT", "android.permission.READ_MEDIA_IMAGES", "android.permission.READ_PHONE_STATE"
)
