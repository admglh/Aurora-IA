#!/data/data/com.termux/files/usr/bin/bash
set -u
BASE="${AURORA_BASE:-$HOME/Aurora Projeto}"
fail=0
ok(){ printf '[OK] %s\n' "$1"; }
bad(){ printf '[FALHA] %s\n' "$1"; fail=1; }
for d in ferramentas memória modelo visão voz extensoes; do [ -d "$BASE/$d" ] && ok "Pasta $d" || bad "Pasta $d"; done
[ -x "$BASE/ferramentas/bin/llama-cli" ] && ok "llama-cli" || bad "llama-cli"
[ -x "$BASE/ferramentas/bin/llama-server" ] && ok "llama-server" || bad "llama-server"
[ -x "$BASE/ferramentas/bin/github-mcp-server" ] && ok "GitHub MCP Server compilado" || bad "GitHub MCP Server compilado"
[ -d "$BASE/ferramentas/mcp/droid-mcp" ] && ok "droid-mcp fonte" || bad "droid-mcp fonte"
[ -d "$BASE/ferramentas/mcp/servers" ] && ok "MCP servers" || bad "MCP servers"
[ -d "$BASE/ferramentas/mcp/npm/node_modules" ] && ok "MCP npm" || bad "MCP npm"
[ -f "$BASE/manifesto_instalado.json" ] && ok "manifesto" || bad "manifesto"
shopt -s nullglob
sherpa=("$BASE/voz/sherpa/"sherpa-onnx-*-android.tar.bz2)
((${#sherpa[@]} > 0)) && ok "sherpa-onnx Android" || bad "sherpa-onnx Android"
[ -f "$BASE/modelo/CATALOGO_MODELOS.txt" ] && ok "catálogo de modelos" || bad "catálogo de modelos"
[ -f "$BASE/voz/sherpa/silero_vad.onnx" ] && ok "VAD Silero" || bad "VAD Silero"
shopt -s nullglob
whispers=("$BASE/voz/sherpa/"sherpa-onnx-whisper-*.tar.bz2)
((${#whispers[@]} >= 1)) && ok "modelos Whisper sherpa" || bad "modelos Whisper sherpa"
kokoro=("$BASE/voz/sherpa/"kokoro-*.tar.bz2)
((${#kokoro[@]} >= 1)) && ok "modelo TTS Kokoro" || bad "modelo TTS Kokoro"
if [ -f "$BASE/manifesto_instalado.json" ]; then grep -q '"droid_mcp_capabilities": 151' "$BASE/manifesto_instalado.json" && ok "manifesto declara 151 capacidades" || bad "manifesto sem 151 capacidades"; fi
printf '\nResultado da pilha Termux: %s\n' "$([ "$fail" -eq 0 ] && echo OK || echo FALHA)"
exit "$fail"
