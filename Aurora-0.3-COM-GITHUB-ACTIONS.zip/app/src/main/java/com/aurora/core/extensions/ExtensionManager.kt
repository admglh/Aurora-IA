package com.aurora.core.extensions

import android.content.Context
import android.net.Uri
import java.io.File
import java.util.zip.ZipInputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * Gerenciador universal de recursos da Aurora. Importa modelos, voz, visão, memória, plugins,
 * MCP e pacotes diretamente pelo seletor de arquivos do Android. O arquivo original permanece
 * em Downloads até o usuário decidir apagá-lo.
 */
class ExtensionManager(private val context: Context) {
    private val root = File(context.filesDir, "aurora_extensions").apply { mkdirs() }
    private val registry = File(root, "registry.json")
    private val models = File(context.filesDir, "models").apply { mkdirs() }
    private val vision = File(context.filesDir, "vision").apply { mkdirs() }
    private val voice = File(context.filesDir, "voice").apply { mkdirs() }
    private val memory = File(context.filesDir, "memory_resources").apply { mkdirs() }

    data class InstallPlan(val name: String, val type: String, val destination: String, val size: Long)
    data class Installed(val id: String, val name: String, val type: String, val file: String, val size: Long, val pluginId: String? = null, val capabilities: List<String> = emptyList())

    fun inspect(uri: Uri): InstallPlan {
        val name = uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':')?.ifBlank { "recurso" } ?: "recurso"
        val type = detectTypeName(name)
        val destination = when {
            type.startsWith("cérebro") -> "modelo"
            type.startsWith("voz") -> "voz"
            type.startsWith("visão") -> "visão"
            type.startsWith("memória") -> "memória"
            type.startsWith("plugin") -> "extensões"
            else -> "extensões"
        }
        val size = runCatching { context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L }.getOrDefault(-1L)
        return InstallPlan(name, type, destination, size)
    }

    suspend fun installDownloaded(file: File, nameHint: String? = null): Result<Installed> = withContext(Dispatchers.IO) {
        runCatching {
            require(file.exists()) { "Download não encontrado." }
            val rawName = nameHint ?: file.name
            val safe = rawName.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "recurso" }
            val type = detectTypeName(safe)
            val targetDir = when {
                type.startsWith("cérebro") -> models
                type.startsWith("voz") -> voice
                type.startsWith("visão") -> vision
                type.startsWith("memória") -> memory
                else -> root
            }.apply { mkdirs() }
            val installedPath = if (safe.endsWith(".zip", true)) {
                val dir = File(root, safe.substringBeforeLast('.')).apply { mkdirs() }
                extractZipFile(file, dir)
                dir
            } else {
                val target = unique(File(targetDir, safe))
                file.inputStream().use { input -> target.outputStream().use { output -> input.copyTo(output, 1024 * 1024) } }
                target
            }
            val size=installedPath.walkTopDown().filter{it.isFile}.sumOf{it.length()}
            val meta = readPluginManifest(installedPath)
            val item=Installed(installedPath.name+"-"+size,installedPath.name,type,installedPath.absolutePath,size,meta?.first,meta?.second ?: emptyList())
            writeRegistry(item)
            installedPath
            item
        }
    }

    suspend fun import(uri: Uri, nameHint: String? = null): Result<Installed> = withContext(Dispatchers.IO) {
        runCatching {
            val rawName = nameHint ?: uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':') ?: "recurso"
            val safe = rawName.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "recurso" }
            val type = detectTypeName(safe)
            val targetDir = when {
                type.startsWith("cérebro") -> models
                type.startsWith("voz") -> voice
                type.startsWith("visão") -> vision
                type.startsWith("memória") -> memory
                else -> root
            }.apply { mkdirs() }

            val installedPath = if (safe.endsWith(".zip", true)) {
                val dir = File(root, safe.substringBeforeLast('.')).apply { mkdirs() }
                extractZip(uri, dir)
                dir
            } else {
                val target = unique(File(targetDir, safe))
                context.contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "Não foi possível abrir o arquivo." }
                    target.outputStream().use { output -> input.copyTo(output, 1024 * 1024) }
                }
                target
            }
            val size = installedPath.walkTopDown().filter { it.isFile }.sumOf { it.length() }
            val meta = readPluginManifest(installedPath)
            val item = Installed(installedPath.name + "-" + size, installedPath.name, type, installedPath.absolutePath, size, meta?.first, meta?.second ?: emptyList())
            writeRegistry(item)
            item
        }
    }

    suspend fun delete(item: Installed): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val file = File(item.file).canonicalFile
            require(file.path.startsWith(root.canonicalPath + File.separator) ||
                file.path.startsWith(models.canonicalPath + File.separator) ||
                file.path.startsWith(vision.canonicalPath + File.separator) ||
                file.path.startsWith(voice.canonicalPath + File.separator) ||
                file.path.startsWith(memory.canonicalPath + File.separator)) {
                "Arquivo fora do armazenamento privado da Aurora."
            }
            require(file.exists()) { "Recurso não encontrado." }
            file.deleteRecursively()
            writeAll(installed().filterNot { it.id == item.id })
        }
    }

    fun installed(): List<Installed> {
        if (!registry.exists()) return emptyList()
        return runCatching {
            val a = JSONArray(registry.readText())
            buildList {
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    val path = o.getString("file")
                    if (File(path).exists()) add(Installed(o.getString("id"), o.getString("name"), o.getString("type"), path, o.getLong("size"), o.optString("pluginId").ifBlank { null }, buildList { val a=o.optJSONArray("capabilities") ?: return@buildList; for(j in 0 until a.length()) add(a.optString(j)) }))
                }
            }
        }.getOrDefault(emptyList())
    }

    private fun detectTypeName(name: String): String {
        val n = name.lowercase()
        return when {
            n.endsWith(".gguf") -> "cérebro / modelo GGUF"
            n.endsWith(".onnx") || n.endsWith(".pt") || n.endsWith(".pth") || n.contains("mmproj") -> "visão / modelo"
            n.endsWith(".bin") && (n.contains("whisper") || n.contains("speech") || n.contains("vits")) -> "voz / modelo"
            n.endsWith(".zip") -> "plugin / pacote"
            n.endsWith(".apk") -> "pacote Android"
            n.endsWith(".json") && (n.contains("memory") || n.contains("memoria") || n.contains("embedding")) -> "memória / dados"
            n.endsWith(".mp3") || n.endsWith(".wav") || n.endsWith(".flac") || n.endsWith(".ogg") -> "voz / áudio"
            n.endsWith(".png") || n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".webp") -> "visão / imagem"
            n.endsWith(".json") || n.endsWith(".yaml") || n.endsWith(".yml") -> "plugin / configuração"
            else -> "recurso / arquivo"
        }
    }

    private fun extractZipFile(file: File, destination: File): File {
        file.inputStream().use { input ->
            ZipInputStream(input.buffered()).use { zip ->
                var entry=zip.nextEntry
                while(entry!=null){
                    val target=File(destination,entry.name).canonicalFile
                    require(target.path.startsWith(destination.canonicalPath+File.separator) || target==destination.canonicalFile){"ZIP inseguro: ${entry.name}"}
                    if(entry.isDirectory) target.mkdirs() else { target.parentFile?.mkdirs(); target.outputStream().use{out->zip.copyTo(out,1024*1024)} }
                    zip.closeEntry(); entry=zip.nextEntry
                }
            }
        }
        return destination
    }

    private fun extractZip(uri: Uri, destination: File): File {
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Não foi possível abrir o ZIP." }
            ZipInputStream(input.buffered()).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    val target = File(destination, entry.name).canonicalFile
                    require(target.path.startsWith(destination.canonicalPath + File.separator) || target == destination.canonicalFile) { "ZIP inseguro: ${entry.name}" }
                    if (entry.isDirectory) target.mkdirs() else {
                        target.parentFile?.mkdirs()
                        target.outputStream().use { out -> zip.copyTo(out, 1024 * 1024) }
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
        }
        return destination
    }

    private fun writeRegistry(item: Installed) = writeAll(installed().filterNot { it.file == item.file } + item)
    private fun writeAll(items: List<Installed>) {
        val a = JSONArray()
        items.forEach { a.put(JSONObject().apply { put("id", it.id); put("name", it.name); put("type", it.type); put("file", it.file); put("size", it.size); put("pluginId", it.pluginId ?: ""); put("capabilities", JSONArray(it.capabilities)) }) }
        registry.writeText(a.toString())
    }

    private fun readPluginManifest(installedPath: File): Pair<String, List<String>>? {
        if (!installedPath.isDirectory) return null
        val manifest = File(installedPath, "aurora-extension.json")
        if (!manifest.isFile) return null
        return runCatching {
            val o = JSONObject(manifest.readText().take(200_000))
            val id = o.optString("id").trim().ifBlank { error("Plugin sem id") }
            val caps = buildList { val a=o.optJSONArray("capabilities") ?: return@buildList; for(i in 0 until a.length()) add(a.optString(i)) }
            id to caps
        }.getOrNull()
    }

    private fun unique(initial: File): File {
        if (!initial.exists()) return initial
        var i = 2
        while (true) {
            val suffix = if (initial.extension.isBlank()) "${initial.name}-$i" else "${initial.nameWithoutExtension}-$i.${initial.extension}"
            val f = File(initial.parentFile, suffix)
            if (!f.exists()) return f
            i++
        }
    }
}
