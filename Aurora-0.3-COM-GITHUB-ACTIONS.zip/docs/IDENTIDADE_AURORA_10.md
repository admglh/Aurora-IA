# Identidade visual da Aurora

Esta etapa adiciona a identidade visual criada pelo usuário sem alterar o motor local.

## Referências preservadas

As imagens originais fornecidas nesta etapa ficam em `app/src/main/res/drawable-nodpi/` sem redimensionamento ou recompressão adicional:

- `aurora_identity_reference.jpg` — Aurora principal.
- `aurora_theme_birthday.jpg` — aniversário, 29 de março.
- `aurora_theme_formal.jpg` — entrevista, reunião ou prova.
- `aurora_theme_summer.jpg` — saída em dia quente.
- `aurora_theme_winter.jpg` — saída em dia frio.
- `aurora_theme_easter.jpg` — sexta, sábado e domingo da Páscoa.
- `aurora_theme_september7.jpg` — 7 de setembro.
- `aurora_theme_halloween.jpg` — 31 de outubro.
- `aurora_app_icon.jpg` — ícone oficial fornecido pelo usuário.

O ícone do APK usa `aurora_app_icon.jpg`. O desenho anterior em XML não é mais usado.

## Temas automáticos

A Aurora calcula a Páscoa para o ano corrente e aplica o tema de Páscoa nos três dias definidos. Aniversário, 7 de setembro e Halloween usam suas respectivas datas anuais.

## Temas por intenção

Mensagens contendo contexto explícito de entrevista/reunião/prova ativam o modo formal. Mensagens que associem saída (por exemplo parque/shopping) a calor ou frio ativam o tema correspondente até o início do dia seguinte.

Isso é uma heurística determinística; não é uma alegação de que o modelo entendeu a intenção.

## Movimento

A presença atual usa animação nativa do Jetpack Compose para respiração, flutuação e halo do núcleo. Isso movimenta a presença como um conjunto e não cria falsa animação facial/corporal.

O projeto também passa a incluir `lottie-compose` 6.7.1 como motor de renderização preparado para animações futuras. Lottie é um runtime/renderizador; ele não transforma automaticamente uma imagem raster em uma personagem rigada.

A ideia para a próxima etapa é permitir que uma futura Aurora gere/edite descrições de animação validadas e que o aplicativo renderize os resultados localmente, mantendo o núcleo separado do modelo GGUF.
