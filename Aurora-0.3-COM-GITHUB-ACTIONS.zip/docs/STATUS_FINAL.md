# Aurora Nova, estado real do pacote

Este pacote usa `Aurora-0_1-MEGA-CORRIGIDA-2.zip` como base.

## Incluído no ZIP
- projeto Android/Compose e Gradle
- Room e migrações
- agente, persona e memória semântica
- provedor GGUF local
- catálogo de modelos e extensões
- camada droid-mcp e módulos Android
- voz local/híbrida e integração Whisper
- visão/MediaPipe
- MCP HTTP autenticado
- GitHub/Web
- animações e identidade visual
- scripts de build, auditoria, migração, diagnóstico e instalação
- organizador automático dos recursos externos
- catálogo online de até 500 resultados GGUF por pesquisa no Hugging Face

## Recursos pesados
Os modelos não são duplicados dentro do ZIP. O instalador usa a pasta compartilhada:
`/storage/emulated/0/Download/Aurora`

O organizador reconhece automaticamente os recursos já baixados, incluindo Qwen, Qwen-VL/mmproj, BGE, reranker, Whisper, Silero VAD, Kokoro e OCR.

## O que não deve ser tratado como já testado
A presença do código, SDK ou dependência não significa que cada recurso foi executado com sucesso no aparelho. O `DIAGNOSTICO_FINAL.sh` separa presença de runtime. O mesmo vale para permissões opcionais, Shizuku/root e servidores MCP externos.
