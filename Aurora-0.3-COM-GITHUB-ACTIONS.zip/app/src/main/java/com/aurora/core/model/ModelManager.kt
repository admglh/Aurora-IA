package com.aurora.core.model

import android.content.Context
import android.net.Uri
import android.os.StatFs
import com.aurora.core.settings.AuroraSettings
import com.aurora.core.settings.SecretStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File
import java.io.RandomAccessFile

/** Biblioteca e seleção dos motores disponíveis para a Aurora. */
data class LocalModelInfo(
    val fileName: String,
    val sizeBytes: Long,
    val selected: Boolean,
    val valid: Boolean
)

class ModelManager(
    context: Context,
    private val settings: AuroraSettings,
    private val secrets: SecretStore,
    private val scope: CoroutineScope
) {
    private val modelsDir = File(context.filesDir, "models").apply { mkdirs() }
    private val appContext = context.applicationContext
    private val mutex = Mutex()
    private val externalProvisioner = AuroraExternalModelProvisioner(appContext)

    private val _state = MutableStateFlow<ModelState>(ModelState.Loading("Inicializando…"))
    val state: StateFlow<ModelState> = _state.asStateFlow()
    private val _library = MutableStateFlow<List<LocalModelInfo>>(emptyList())
    val library: StateFlow<List<LocalModelInfo>> = _library.asStateFlow()

    @Volatile private var provider: ModelProvider? = null
    private var localProvider: LocalGgufProvider? = null
    private var stateJob: Job? = null

    suspend fun refresh() {
        mutex.withLock {
            stateJob?.cancel()
            stateJob = null
            // O provider local é REAPROVEITADO quando o arquivo é o mesmo: salvar/limpar o endpoint remoto não pode
            // descarregar e recarregar vários GB de pesos (nem liberá-los no meio de uma geração).
            if (provider !== localProvider) provider?.release()
            provider = null
            _library.value = scanLibrary()
            _state.value = ModelState.Loading("Carregando o modelo… (só na inicialização)")

            // Nuvem primeiro: com endpoint configurado ela é o motor ativo IMEDIATAMENTE. Não varre Download/Aurora,
            // não copia GGUF de vários GB e não carrega pesos locais (isso travava o app em "Carregando" e bloqueava o envio).
            val remote = OpenAICompatibleProvider(
                endpoint = settings.remoteEndpoint,
                model = settings.remoteModel,
                apiKey = secrets.get(SecretStore.KEY_REMOTE_API)
            )
            if (settings.remoteEndpoint.isNotBlank()) {
                if (provider !== localProvider) provider?.release()
                provider = remote
                _state.value = remote.state.value
                stateJob = scope.launch { remote.state.collect { _state.value = it } }
                return@withLock
            }
            var localFile = File(modelsDir, settings.localModelFileName)
            // Sem nuvem: procura GGUF em Download/Aurora e instala o melhor cérebro compatível.
            if (!localFile.exists() || !isGguf(localFile)) {
                val imported = externalProvisioner.importBestChatModel(modelsDir)
                if (imported != null) {
                    settings.localModelFileName = imported.name
                    localFile = imported
                }
            }
            val local = localProvider?.takeIf { it.modelPath == localFile.absolutePath }
                ?: LocalGgufProvider(localFile).also {
                    localProvider?.release() // arquivo mudou (importação/seleção): descarrega o anterior
                    localProvider = it
                }
            withContext(Dispatchers.IO) {
                remote.load()
                if (remote.state.value !is ModelState.Ready) local.load()
            }

            val candidates = listOf(remote, local)
            val chosen = candidates.firstOrNull { it.state.value is ModelState.Ready }
            if (chosen == null) {
                // Lê os estados ANTES de liberar: release() sobrescreve o estado e mascarava o erro real do GGUF.
                val states = candidates.map { it.label to it.state.value }
                candidates.forEach { it.release() }
                val firstError = states.firstNotNullOfOrNull { (_, state) -> (state as? ModelState.Error)?.message }
                _state.value = if (firstError != null) ModelState.Error(firstError) else {
                    val lines = states.mapNotNull { (label, state) ->
                        (state as? ModelState.NotConfigured)?.let { "$label: ${it.reason}" }
                    }
                    ModelState.NotConfigured(lines.joinToString("\n").ifBlank { "Nenhum modelo configurado." })
                }
            } else {
                candidates.filter { it !== chosen }.forEach { it.release() }
                provider = chosen
                _state.value = chosen.state.value
                stateJob = scope.launch { chosen.state.collect { _state.value = it } }
            }
        }
    }

    fun refreshAsync() = scope.launch { refresh() }

    /** Importa primeiro para arquivo temporário e só seleciona o modelo depois da validação. */
    suspend fun importLocalModel(uri: Uri, displayName: String): Result<File> = runCatching {
        val safeName = displayName.substringAfterLast('/')
            .replace(Regex("[^A-Za-z0-9._-]"), "_")
            .ifBlank { AuroraSettings.DEFAULT_LOCAL_MODEL_FILE }
            .let { if (it.lowercase().endsWith(".gguf")) it else "$it.gguf" }
        val target = uniqueTarget(File(modelsDir, safeName))
        val temp = File(modelsDir, ".${target.name}.part")

        withContext(Dispatchers.IO) {
            appContext.contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "Não foi possível abrir o arquivo escolhido." }
                val expectedMin = 4L * 1024L * 1024L
                require(freeBytes(modelsDir) > expectedMin) { "Não há espaço livre suficiente para iniciar a importação." }
                temp.outputStream().use { output -> input.copyTo(output, 1024 * 1024) }
            }
            validateGguf(temp)
            temp.copyTo(target, overwrite = true)
            check(target.exists() && target.length() == temp.length()) {
                "Não foi possível finalizar a importação do modelo."
            }
            check(temp.delete()) {
                "Modelo importado, mas não foi possível limpar o arquivo temporário."
            }
        }
        settings.localModelFileName = target.name
        refresh()
        target
    }.onFailure {
        modelsDir.listFiles()?.filter { it.name.endsWith(".part") }?.forEach { it.delete() }
    }

    suspend fun deleteLocalModel(fileName: String): Result<Unit> = runCatching {
        require(fileName == safeName(fileName)) { "Nome de modelo inválido." }
        require(fileName != settings.localModelFileName) { "Não é possível apagar o modelo selecionado. Selecione outro primeiro." }
        File(modelsDir, fileName).delete()
        _library.value = scanLibrary()
    }

    fun localModelFile(): File = File(modelsDir, settings.localModelFileName)
    fun embeddingModelFile(): File = File(modelsDir, settings.embeddingModelFileName)

    suspend fun deleteEmbeddingModel(): Result<Unit> = runCatching {
        val name = settings.embeddingModelFileName
        if (name.isBlank()) return@runCatching
        File(modelsDir, name).delete()
        settings.embeddingModelFileName = ""
        _library.value = scanLibrary()
    }

    suspend fun importEmbeddingModel(uri: Uri, displayName: String): Result<File> = runCatching {
        val safeName = displayName.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "bge-m3.gguf" }.let { if (it.lowercase().endsWith(".gguf")) it else "$it.gguf" }
        val target = uniqueTarget(File(modelsDir, safeName))
        val temp = File(modelsDir, ".${target.name}.part")
        withContext(Dispatchers.IO) {
            appContext.contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "Não foi possível abrir o modelo de memória." }
                temp.outputStream().use { output -> input.copyTo(output, 1024 * 1024) }
            }
            validateGguf(temp)
            check(temp.renameTo(target)) { "Não foi possível finalizar a importação do modelo de memória." }
        }
        settings.embeddingModelFileName = target.name
        target
    }.onFailure { modelsDir.listFiles()?.filter { it.name.endsWith(".part") }?.forEach { it.delete() } }
    fun modelsDirectory(): File = modelsDir

    fun generate(request: GenerationRequest): Flow<String> = flow {
        val active = provider ?: throw IllegalStateException("Nenhum cérebro disponível. Configure a nuvem ou coloque um GGUF em Download/Aurora.")
        var emittedAny = false
        try {
            active.generate(request).collect { emittedAny = true; emit(it) }
        } catch (t: Throwable) {
            // Nuvem é o caminho principal quando configurada, mas uma falha de rede não pode deixar
            // a Aurora inutilizável se existir um cérebro local válido.
            if (active.id != "openai-compatible") throw t
            // Já mostrou texto: cair para o local repetiria a resposta do zero (e carregaria GBs). Erros de chave,
            // endereço ou limite (401/403/404/429) também são mostrados como são, em vez de esconder o motivo real.
            if (emittedAny || (t.message?.let { Regex("HTTP (401|403|404|429)").containsMatchIn(it) } == true)) throw t
            val fallback = withContext(Dispatchers.IO) { loadLocalFallback() }
            if (fallback == null) throw t
            _state.value = fallback.state.value
            emitAll(fallback.generate(request))
        }
    }.flowOn(Dispatchers.IO)

    private suspend fun loadLocalFallback(): ModelProvider? {
        mutex.withLock {
            // Só usa um GGUF que JÁ está instalado: não copia GBs de Download/Aurora por causa de uma falha de rede.
            val file = File(modelsDir, settings.localModelFileName)
            if (!file.exists() || !isGguf(file)) return null
            val local = localProvider?.takeIf { it.modelPath == file.absolutePath }
                ?: LocalGgufProvider(file).also { localProvider?.release(); localProvider = it }
            local.load()
            return local
        }
    }

    fun cancel() { provider?.cancel(); localProvider?.cancel() }

    /** true quando o motor ativo é o GGUF local (contexto pequeno e prefill caro → prompt enxuto). */
    fun isLocalActive(): Boolean = provider?.id == "local-gguf"

    /** O provedor de nuvem, se for o motor ativo (usado para function calling). */
    fun remoteProvider(): OpenAICompatibleProvider? = provider as? OpenAICompatibleProvider

    private fun scanLibrary(): List<LocalModelInfo> = modelsDir.listFiles()
        ?.filter { it.isFile && it.extension.equals("gguf", true) }
        ?.map { file ->
            LocalModelInfo(file.name, file.length(), file.name == settings.localModelFileName, isGguf(file))
        }
        ?.sortedBy { it.fileName.lowercase() }
        ?: emptyList()

    private fun validateGguf(file: File) {
        require(file.length() >= 4L * 1024L * 1024L) { "O arquivo é pequeno demais para um GGUF válido." }
        RandomAccessFile(file, "r").use { raf ->
            val magic = ByteArray(4)
            raf.readFully(magic)
            require(String(magic, Charsets.US_ASCII) == "GGUF") { "O arquivo escolhido não tem cabeçalho GGUF." }
        }
    }

    private fun isGguf(file: File): Boolean = runCatching {
        RandomAccessFile(file, "r").use { raf ->
            val magic = ByteArray(4)
            raf.readFully(magic)
            String(magic, Charsets.US_ASCII) == "GGUF"
        }
    }.getOrDefault(false)

    private fun uniqueTarget(initial: File): File {
        if (!initial.exists()) return initial
        val base = initial.nameWithoutExtension
        var i = 2
        while (true) {
            val candidate = File(initial.parentFile, "$base-$i.gguf")
            if (!candidate.exists()) return candidate
            i++
        }
    }

    private fun safeName(name: String): String = name.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]"), "_")
    private fun freeBytes(dir: File): Long = runCatching { StatFs(dir.path).availableBytes }.getOrDefault(Long.MAX_VALUE)
}
