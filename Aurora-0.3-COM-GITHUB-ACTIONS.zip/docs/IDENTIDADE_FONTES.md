# Fontes da identidade

As referências desta etapa foram fornecidas diretamente pelo usuário e são armazenadas no projeto para manter a continuidade visual.

Não substituir a arte oficial por imagens de terceiros sem decisão explícita. Bibliotecas de animação são infraestrutura, não referências visuais da Aurora.
