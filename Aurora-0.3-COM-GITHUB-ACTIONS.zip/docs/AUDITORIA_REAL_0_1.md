# Aurora 0.1 — Auditoria da fonte

Esta versão não marca runtime como verde apenas porque uma dependência foi declarada.

Estados usados na auditoria:

- **Fonte integrada:** código chama a API real.
- **Preparado:** dependência/arquivo existe, mas depende de permissão, modelo ou ambiente.
- **Runtime validado:** executado e comprovado no Android/Termux.

## Integrações desta fonte

- droid-mcp 0.11.0: API oficial `DroidMcp.builder()`; módulos all + root/Shizuku opt-in.
- MCP HTTP: configurado com token gerado pelo SDK.
- GitHub API: pesquisa pública de repositórios/issues/releases.
- GitHub MCP Server: fonte + build pelo Termux.
- MCP Node: servidores oficiais instalados pelo Termux quando disponíveis no registry.
- Hugging Face: pesquisa online de modelos GGUF e download direto.
- llama.cpp Android: AAR local para GGUF.
- Whisper Android: AAR local para STT.
- sherpa-onnx: AAR + pacote Android no Termux para STT/TTS/VAD.
- MediaPipe Tasks Vision: AAR para tarefas de visão.
- Sistema universal de recursos: importação, validação, armazenamento privado, manifesto de plugin e exclusão protegida.

## O que depende do aparelho

Permissões Android, Shizuku/root, modelos baixados, ferramentas Termux, acesso à rede e execução do build precisam ser validados no próprio aparelho. A fonte não chama isso de “testado” antecipadamente.
