# Aurora — Mega Stack 0.1

Esta fase não impõe limite de tamanho ao projeto. Modelos podem ficar fora do APK e ser importados para o armazenamento privado/gerenciado da Aurora.

## Componentes pesquisados

- llama.cpp: runtime GGUF e servidor local; possui documentação específica para Android e Termux.
- droid-mcp: SDK Android com 151 capacidades expostas como ferramentas para LLMs.
- MCP servers: implementações de referência para fetch web, filesystem, Git, memory, time e outras ferramentas.
- sherpa-onnx: STT, TTS, VAD, identificação de voz, keyword spotting e outros modelos de áudio.
- MediaPipe: visão local, rosto e tarefas de imagem/vídeo.

## Modelos iniciais

Qwen3 0.6B, 1.7B, 4B e 8B; SmolLM2 360M e 1.7B; InternVL3 1B para visão.

## Instalação

No Termux:

```bash
cd ~/aurora-0.1
chmod +x tools/INSTALL_AURORA_MEGA.sh
./tools/INSTALL_AURORA_MEGA.sh
```

Mais modelos:

```bash
./tools/DOWNLOAD_MORE_MODELS.sh
```

A instalação cria `~/Aurora Projeto/` com as pastas `ferramentas`, `memória`, `modelo`, `visão` e `voz`.

## Importação para o aplicativo

A arquitetura da Aurora deve permitir importar um arquivo/modelo usando o seletor de arquivos Android, copiar para o armazenamento privado e, depois, perguntar ao usuário se o original em Download pode ser apagado.

## Extensões

O catálogo inicial inclui droid-mcp, MCP Fetch, Filesystem, Git, Memory, Time, llama.cpp, sherpa-onnx, MediaPipe e GitHub. O droid-mcp deve ser tratado como um pacote de 151 capacidades, não reduzido a uma lista pequena de ferramentas.
