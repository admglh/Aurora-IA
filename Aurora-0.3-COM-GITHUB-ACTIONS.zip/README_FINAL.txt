AURORA NOVA FINAL

Este pacote unifica os dois pacotes anteriores:
1) o Aurora_Nova.zip pequeno, que continha o backend/frontend Termux básico;
2) o Aurora-Nova-FINAL-COMPLETA.zip de ~9 MB, que continha o projeto Android/Compose.

O código não é duplicado em ZIPs internos. O runtime Termux foi incorporado em /termux.

Os modelos e recursos pesados continuam fora do ZIP, em:
 /storage/emulated/0/Download/Aurora

O script principal é:
 tools/INSTALAR_TUDO_AURORA.sh

Ele faz backup das instalações antigas, instala a árvore nova e executa o organizador dos recursos.
